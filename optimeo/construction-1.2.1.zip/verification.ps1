﻿$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
Set-Location Optimeo-1.2.1
$script:cases = 0
function Check($ok,$message) { if(-not $ok){ throw $message }; $script:cases++; Write-Output "OK $message" }
$funcs=@{}
$files = @(Get-ChildItem -Recurse -File -Filter *.ps1)
foreach($file in $files) {
    $errors=$null
    $ast=[System.Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$null,[ref]$errors)
    Check ($errors.Count -eq 0) "PS5.1 $($file.Name)"
    foreach ($func in $ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst]},$true)) { $funcs[$func.Name]=$func.Extent.Text }
}
foreach($name in @('Add-ActionAnnulable','Set-RegValeur','Get-FichiersSansLiens','Get-MisesAJourLogiciels','ConvertFrom-TableauWinget','New-MiseAJour','Uninstall-Element','Undo-Sauvegarde','Invoke-RechercheMisesAJour','Assert-FichierProtege','Get-Sauvegardes')) { . ([ScriptBlock]::Create($funcs[$name])) }
Add-Type -AssemblyName PresentationFramework
[xml]$xml=Get-Content interface\Fenetre.xaml -Raw -Encoding UTF8
$win=[Windows.Markup.XamlReader]::Load((New-Object Xml.XmlNodeReader $xml))
Check ($win.FindName('Onglets').Items.Count -eq 8) '8 pages WPF'
$main=Get-Content OptimiseurPC.ps1 -Raw -Encoding UTF8
$names=[regex]::Matches($main,'\$C\.(\w+)') | ForEach-Object {$_.Groups[1].Value} | Sort-Object -Unique
Check (@($names | Where-Object {-not $win.FindName($_)}).Count -eq 0) "$($names.Count) controles WPF"
$script:DossierSauvegardes=Join-Path $PSScriptRoot ('audit-'+[guid]::NewGuid())
$null=New-Item -Type Directory -Path $script:DossierSauvegardes
$script:ActionsEnCours=New-Object Collections.ArrayList
$script:TacheEnCours=@{Id='TEST';Titre='Test'}
$script:FichierAction=Join-Path $script:DossierSauvegardes 'essai.json'
$record=[ordered]@{Type='Registre';Nom='A';Existait=$false}
Add-ActionAnnulable $record
Check ((Get-Content -Raw $script:FichierAction | ConvertFrom-Json).Actions.Count -eq 1) 'premiere sauvegarde sur disque'
Add-ActionAnnulable ([ordered]@{Type='Registre';Nom='B'})
Check ((Get-Content -Raw $script:FichierAction | ConvertFrom-Json).Actions.Count -eq 2) 'deuxieme sauvegarde atomique'
$old=$script:FichierAction
$script:FichierAction=Join-Path $script:DossierSauvegardes 'inexistant\test.json'
$script:mutations=0
function New-ItemProperty { $script:mutations++; throw 'mutation appelee' }
function New-Item { $script:mutations++; throw 'creation appelee' }
$failed=$false
try {Set-RegValeur 'HKCU:\Software\Optimeo-Audit-Fixture-Inexistante' 'Test' 1} catch {$failed=$_.Exception.Message -like '*historique impossible*'}
Check ($failed -and $script:mutations -eq 0) 'sauvegarde impossible bloque la modification'
Check ($script:ActionsEnCours.Count -eq 2) 'lot partiel conserve'
Check ((Get-Content -Raw $old | ConvertFrom-Json).Actions.Count -eq 2) 'historique precedent intact'
Remove-Item -Path Function:\New-Item,Function:\New-ItemProperty
$script:trace=@()
function Restore-Action($Action){$script:trace+=$Action.Nom}
function Write-Journal {}
$unsafe=$false
try {Undo-Sauvegarde (Join-Path $PSScriptRoot 'ailleurs.json')} catch {$unsafe=$true}
Check ($unsafe -and $script:trace.Count -eq 0) 'refus des sauvegardes hors historique'
# Only bypass the ACL check on our own temporary test file to exercise undo ordering.
function Assert-FichierProtege($Chemin) {}
$err=Undo-Sauvegarde $old
Check ($err -eq 0 -and ($script:trace -join ',') -eq 'B,A' -and (Test-Path ([IO.Path]::ChangeExtension($old,'annule')))) 'annulation inverse et archivage'
Check ((Uninstall-Element @{Source='Epic';Nom='Jeu'}) -like 'MANUEL:*') 'desinstallation Epic confiee au lanceur'
Check ((Uninstall-Element @{Source='Registre';Nom='Fixture';Cle='Microsoft.PowerShell.Core\Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall\Test'}) -like 'MANUEL:*') 'desinstallation utilisateur sans execution elevee'
function Set-Occupe($flag,$message) { $script:statut=$message }
function Set-Statut {}
function Show-Message {}
function Get-MisesAJourLogiciels {throw 'indisponible'}
function Get-MisesAJourWindows {}
function Get-InfosMisesAJourMateriel {}
function Update-TableMaj {}
$script:Diagnostic=@{Donnees=@{}}
Invoke-RechercheMisesAJour
Check ($script:statut -like 'Recherche incompl*') 'recherche incomplete visible'
function Get-MisesAJourLogiciels {}
Invoke-RechercheMisesAJour
Check ($script:statut -like 'Tout est *') 'recherche vide reussie'
$dir=Join-Path $script:DossierSauvegardes 'temoin'
[IO.Directory]::CreateDirectory($dir) | Out-Null
[IO.File]::WriteAllText((Join-Path $dir 'normal.txt'),'test')
Check (@(Get-FichiersSansLiens $dir).Count -eq 1) 'nettoyage repertorie un fichier normal'
if ($env:GITHUB_ACTIONS) {
    $link=New-Item -ItemType Junction -Path (Join-Path $script:DossierSauvegardes 'jonction') -Target (Get-Location).Path -ErrorAction Stop
} else {
    $link=Get-Item (Join-Path (Split-Path $PSScriptRoot) 'Optimeo')
}
Check (($link.Attributes -band [IO.FileAttributes]::ReparsePoint) -and @(Get-FichiersSansLiens $link.FullName).Count -eq 0) 'nettoyage ignore la jonction racine'
Check (@(Get-FichiersSansLiens (Join-Path $link.FullName 'modules')).Count -eq 0) 'nettoyage ignore un parent en jonction'
"TOTAL $script:cases"


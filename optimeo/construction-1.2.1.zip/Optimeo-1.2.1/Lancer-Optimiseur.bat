@echo off
rem =====================================================================
rem  Lancer-Optimiseur.bat
rem  Lance OptimiseurPC.ps1 avec Windows PowerShell 5.1.
rem  -ExecutionPolicy Bypass : autorise ce script uniquement, sans changer
rem  la politique de securite de Windows.
rem  Le script demande lui-meme les droits administrateur (fenetre UAC).
rem =====================================================================
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0OptimiseurPC.ps1"
if errorlevel 1 pause

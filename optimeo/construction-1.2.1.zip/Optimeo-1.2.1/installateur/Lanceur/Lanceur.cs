﻿// =====================================================================
//  Lanceur.cs — Optimeo.exe
//  ---------------------------------------------------------------------
//  Petit exécutable qui démarre l'interface d'Optimeo (OptimiseurPC.ps1)
//  directement dans le processus, sans fenêtre de console :
//    - droits administrateur demandés par le manifeste (fenêtre UAC)
//    - PowerShell 5.1 de Windows hébergé en mode STA (requis par WPF)
//    - politique d'exécution « Bypass » limitée à ce processus
//  Compilé en x64 : les modules Windows (Appx, DnsClient…) et le registre
//  64 bits doivent être accessibles.
//  Compilation : installateur\construire.ps1 (compilateur C# fourni avec Windows)
// =====================================================================
using System;
using System.IO;
using System.Reflection;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Threading;
using System.Windows.Forms;

// Informations visibles dans Propriétés > Détails du fichier
[assembly: AssemblyTitle("Optimeo")]
[assembly: AssemblyProduct("Optimeo")]
[assembly: AssemblyDescription("Optimeo - optimisation et entretien du PC")]
[assembly: AssemblyCompany("Franck")]
[assembly: AssemblyCopyright("© 2026 Franck")]
[assembly: AssemblyVersion("1.2.1.0")]
[assembly: AssemblyFileVersion("1.2.1.0")]

namespace Optimeo
{
    internal static class Programme
    {
        [STAThread]
        private static int Main()
        {
            string dossier = AppDomain.CurrentDomain.BaseDirectory;
            string script = Path.Combine(dossier, "OptimiseurPC.ps1");
            if (!File.Exists(script))
            {
                MessageBox.Show("Fichier introuvable :\n" + script + "\n\nRéinstalle Optimeo.", "Optimeo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }

            try
            {
                // Session PowerShell : exécution des scripts d'Optimeo autorisée pour ce processus uniquement
                InitialSessionState session = InitialSessionState.CreateDefault();
                session.ExecutionPolicy = Microsoft.PowerShell.ExecutionPolicy.Bypass;
                session.ApartmentState = ApartmentState.STA;
                session.ThreadOptions = PSThreadOptions.UseCurrentThread;   // thread principal STA : fenêtre WPF

                using (Runspace espace = RunspaceFactory.CreateRunspace(session))
                {
                    espace.ApartmentState = ApartmentState.STA;
                    espace.ThreadOptions = PSThreadOptions.UseCurrentThread;
                    espace.Open();
                    using (PowerShell ps = PowerShell.Create())
                    {
                        ps.Runspace = espace;
                        ps.AddCommand(script);     // $PSCommandPath est renseigné comme en lancement normal
                        ps.Invoke();                // bloque jusqu'à la fermeture de la fenêtre

                        // Les erreurs non bloquantes du script seraient perdues sans console :
                        // on les écrit dans le journal d'Optimeo pour pouvoir les retrouver.
                        if (ps.HadErrors && ps.Streams.Error.Count > 0)
                        {
                            MessageBox.Show("Optimeo a signalé une erreur :\n" + ps.Streams.Error[0].ToString(),
                                "Optimeo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return 1;
                        }
                    }
                }
                return 0;
            }
            catch (Exception erreur)
            {
                MessageBox.Show("Optimeo n'a pas pu démarrer :\n\n" + erreur.Message, "Optimeo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
    }
}

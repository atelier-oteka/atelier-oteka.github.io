﻿# =====================================================================
#  construire.ps1 — fabrique Optimeo.exe puis l'installateur
#  ---------------------------------------------------------------------
#  1. Compile le lanceur installateur\Lanceur\Optimeo.exe avec le
#     compilateur C# fourni avec Windows (.NET Framework 4.8) : rien à installer.
#  2. Si NSIS est installé (winget install NSIS.NSIS), crée
#     dist\Optimeo-Installation-<version>.exe à partir de Optimeo.nsi.
#  Utilisation : clic droit > Exécuter avec PowerShell, ou
#     powershell -ExecutionPolicy Bypass -File installateur\construire.ps1
# =====================================================================
$ErrorActionPreference = 'Stop'
$ici = Split-Path -Parent $PSCommandPath
$racine = Split-Path -Parent $ici

# --- 1. Lanceur ---
$csc = "$env:windir\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$sma = [PSObject].Assembly.Location          # System.Management.Automation.dll de Windows PowerShell 5.1
$sortie = Join-Path $ici 'Lanceur\Optimeo.exe'
& $csc /nologo /target:winexe /platform:x64 /optimize+ /codepage:65001 `
    "/out:$sortie" "/win32icon:$racine\interface\logo.ico" "/win32manifest:$ici\Lanceur\app.manifest" `
    "/reference:$sma" /reference:System.Windows.Forms.dll "$ici\Lanceur\Lanceur.cs"
if ($LASTEXITCODE -ne 0) { throw "Échec de la compilation du lanceur (code $LASTEXITCODE)" }
Write-Host "Lanceur créé : $sortie" -ForegroundColor Green

# --- 2. Installateur (NSIS) ---
$makensis = @((Get-Command makensis -ErrorAction SilentlyContinue).Source, "${env:ProgramFiles(x86)}\NSIS\makensis.exe", "$env:ProgramFiles\NSIS\makensis.exe") |
    Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $makensis) { Write-Host "NSIS absent : installe-le (winget install NSIS.NSIS) pour créer l'installateur." -ForegroundColor Yellow; return }
& $makensis /V2 "$ici\Optimeo.nsi"
if ($LASTEXITCODE -ne 0) { throw "Échec de la création de l'installateur (code $LASTEXITCODE)" }
Write-Host "Installateur créé dans $racine\dist" -ForegroundColor Green

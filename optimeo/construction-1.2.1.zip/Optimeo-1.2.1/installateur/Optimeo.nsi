﻿; =====================================================================
;  Optimeo.nsi — installateur d'Optimeo (NSIS 3, Unicode)
;  ---------------------------------------------------------------------
;  - installe dans C:\Program Files\Optimeo (dossier protégé)
;  - raccourcis menu Démarrer (+ bureau en option)
;  - inscrit Optimeo dans « Applications installées » avec son désinstalleur
;  - la désinstallation propose de garder l'historique et les sauvegardes
;  Construction : installateur\construire.ps1 (Windows) ou makensis Optimeo.nsi
; =====================================================================
Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
!include "LogicLib.nsh"

!define NOM      "Optimeo"
!define VERSION  "1.2.1"
!define EDITEUR  "Franck"
!define CLE_DESINSTALLATION "Software\Microsoft\Windows\CurrentVersion\Uninstall\${NOM}"

Name "${NOM}"
OutFile "..\dist\Optimeo-Installation-${VERSION}.exe"
InstallDir "$PROGRAMFILES64\${NOM}"
; Réutilise le dossier d'une installation précédente lors d'une mise à jour
InstallDirRegKey HKLM "${CLE_DESINSTALLATION}" "InstallLocation"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
BrandingText "${NOM} ${VERSION}"

VIProductVersion "${VERSION}.0"
VIAddVersionKey /LANG=1036 "ProductName" "${NOM}"
VIAddVersionKey /LANG=1036 "FileDescription" "Installation d'${NOM}"
VIAddVersionKey /LANG=1036 "CompanyName" "${EDITEUR}"
VIAddVersionKey /LANG=1036 "LegalCopyright" "© 2026 ${EDITEUR}"
VIAddVersionKey /LANG=1036 "FileVersion" "${VERSION}"
VIAddVersionKey /LANG=1036 "ProductVersion" "${VERSION}"

; --- Apparence ---
!define MUI_ICON   "..\interface\logo.ico"
!define MUI_UNICON "..\interface\logo.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP   "assistant.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "assistant.bmp"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_RIGHT
!define MUI_HEADERIMAGE_BITMAP "entete.bmp"
!define MUI_ABORTWARNING

!define MUI_WELCOMEPAGE_TITLE "Bienvenue dans l'installation d'${NOM}"
!define MUI_WELCOMEPAGE_TEXT "${NOM} analyse ton PC, corrige automatiquement ce qui peut l'être et vérifie chaque correction.$\r$\n$\r$\nIl gère aussi les mises à jour, les programmes au démarrage et les logiciels installés.$\r$\n$\r$\nClique sur Suivant pour continuer."
!define MUI_FINISHPAGE_RUN "$INSTDIR\Optimeo.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Lancer ${NOM}"

; --- Pages ---
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "French"

; --- Contrôles avant installation ---
Function VerifierPrerequis
    ${IfNot} ${RunningX64}
        MessageBox MB_OK|MB_ICONSTOP "${NOM} nécessite une version 64 bits de Windows."
        Abort
    ${EndIf}
    ; Optimeo ouvert : ses fichiers sont verrouillés. On le détecte en tentant de
    ; renommer son exécutable (aucun plugin NSIS supplémentaire nécessaire).
    ${If} ${FileExists} "$INSTDIR\Optimeo.exe"
        ClearErrors
        Rename "$INSTDIR\Optimeo.exe" "$INSTDIR\Optimeo.exe.verrou"
        ${If} ${Errors}
            MessageBox MB_OK|MB_ICONSTOP "${NOM} est ouvert : ferme-le puis relance l'installation."
            Abort
        ${Else}
            Rename "$INSTDIR\Optimeo.exe.verrou" "$INSTDIR\Optimeo.exe"
        ${EndIf}
    ${EndIf}
FunctionEnd

Function .onInit
    SetRegView 64
    Call VerifierPrerequis
FunctionEnd

Function un.onInit
    SetRegView 64
    ${If} ${FileExists} "$INSTDIR\Optimeo.exe"
        ClearErrors
        Rename "$INSTDIR\Optimeo.exe" "$INSTDIR\Optimeo.exe.verrou"
        ${If} ${Errors}
            MessageBox MB_OK|MB_ICONSTOP "${NOM} est ouvert : ferme-le puis relance la désinstallation."
            Abort
        ${Else}
            Rename "$INSTDIR\Optimeo.exe.verrou" "$INSTDIR\Optimeo.exe"
        ${EndIf}
    ${EndIf}
FunctionEnd

; --- Installation ---
Section "${NOM} (obligatoire)" SecApplication
    SectionIn RO
    SetShellVarContext all
    SetRegView 64

    SetOutPath "$INSTDIR"
    File "..\OptimiseurPC.ps1"
    File "..\LISEZMOI.md"
    File "Lanceur\Optimeo.exe"
    SetOutPath "$INSTDIR\modules"
    File "..\modules\*.ps1"
    SetOutPath "$INSTDIR\interface"
    ; Tout le dossier interface sauf le logo haute résolution (fichier source)
    File /x "logo-1024.png" "..\interface\*.*"

    WriteUninstaller "$INSTDIR\Desinstaller.exe"
    SetOutPath "$INSTDIR"
    CreateShortcut "$SMPROGRAMS\${NOM}.lnk" "$INSTDIR\Optimeo.exe" "" "$INSTDIR\Optimeo.exe" 0 SW_SHOWNORMAL "" "Optimisation et entretien du PC"

    ; Inscription dans « Applications installées »
    WriteRegStr   HKLM "${CLE_DESINSTALLATION}" "DisplayName"          "${NOM}"
    WriteRegStr   HKLM "${CLE_DESINSTALLATION}" "DisplayVersion"       "${VERSION}"
    WriteRegStr   HKLM "${CLE_DESINSTALLATION}" "Publisher"            "${EDITEUR}"
    WriteRegStr   HKLM "${CLE_DESINSTALLATION}" "DisplayIcon"          "$INSTDIR\Optimeo.exe"
    WriteRegStr   HKLM "${CLE_DESINSTALLATION}" "InstallLocation"      "$INSTDIR"
    WriteRegStr   HKLM "${CLE_DESINSTALLATION}" "UninstallString"      '"$INSTDIR\Desinstaller.exe"'
    WriteRegStr   HKLM "${CLE_DESINSTALLATION}" "QuietUninstallString" '"$INSTDIR\Desinstaller.exe" /S'
    WriteRegDWORD HKLM "${CLE_DESINSTALLATION}" "NoModify" 1
    WriteRegDWORD HKLM "${CLE_DESINSTALLATION}" "NoRepair" 1
    SectionGetSize ${SecApplication} $0
    WriteRegDWORD HKLM "${CLE_DESINSTALLATION}" "EstimatedSize" $0
SectionEnd

Section "Raccourci sur le bureau" SecBureau
    SetShellVarContext all
    SetOutPath "$INSTDIR"
    CreateShortcut "$DESKTOP\${NOM}.lnk" "$INSTDIR\Optimeo.exe" "" "$INSTDIR\Optimeo.exe" 0
SectionEnd

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
    !insertmacro MUI_DESCRIPTION_TEXT ${SecApplication} "Le logiciel ${NOM} et son raccourci dans le menu Démarrer."
    !insertmacro MUI_DESCRIPTION_TEXT ${SecBureau} "Ajoute une icône ${NOM} sur le bureau."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

; --- Désinstallation ---
Section "Uninstall"
    SetShellVarContext all
    SetRegView 64

    Delete "$INSTDIR\Optimeo.exe"
    Delete "$INSTDIR\OptimiseurPC.ps1"
    Delete "$INSTDIR\LISEZMOI.md"
    Delete "$INSTDIR\modules\*.ps1"
    RMDir  "$INSTDIR\modules"
    Delete "$INSTDIR\interface\*.*"
    RMDir  "$INSTDIR\interface"
    Delete "$INSTDIR\Desinstaller.exe"
    RMDir  "$INSTDIR"

    Delete "$SMPROGRAMS\${NOM}.lnk"
    Delete "$DESKTOP\${NOM}.lnk"
    DeleteRegKey HKLM "${CLE_DESINSTALLATION}"

    ; Historique, journal et sauvegardes : %ProgramData%\Optimeo depuis la 1.2.0,
    ; %LOCALAPPDATA%\OptimiseurPC pour les versions précédentes
    MessageBox MB_YESNO|MB_ICONQUESTION "Supprimer aussi l'historique, le journal et les sauvegardes d'${NOM} ?$\r$\n(Sans eux, les optimisations déjà appliquées ne pourront plus être annulées depuis ${NOM}.)" /SD IDNO IDNO fin
    ; SetShellVarContext all (plus haut) : $APPDATA vaut C:\ProgramData
    RMDir /r "$APPDATA\${NOM}"
    SetShellVarContext current
    RMDir /r "$LOCALAPPDATA\OptimiseurPC"
fin:
SectionEnd

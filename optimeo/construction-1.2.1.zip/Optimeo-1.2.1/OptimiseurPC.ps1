﻿# =====================================================================
#  OptimiseurPC.ps1 — Point d'entrée d'Optimeo
#  ---------------------------------------------------------------------
#  Rôle de ce fichier :
#    1. se relancer en administrateur si nécessaire
#    2. charger les modules (dossier « modules ») et la fenêtre (XAML)
#    3. relier les boutons de l'interface aux fonctions
#
#  Version : 1.2.1 ($script:Version, à incrémenter à chaque modification du logiciel,
#            avec installateur\Optimeo.nsi, Lanceur.cs et LISEZMOI.md)
#
#  Interface : menu latéral + pages ; la page d'accueil « Tableau de bord »
#              affiche la note de santé, les gains possibles, le matériel et
#              les principales recommandations (analyse lancée à l'ouverture).
#
#  Fonctionnement général :
#    Analyser        -> diagnostic en lecture seule + vérification de chaque tâche
#    Tout optimiser  -> applique en un clic toutes les corrections automatiques
#                       nécessaires (gain réel, sans risque)
#    Appliquer       -> applique uniquement les tâches cochées
#    Mises à jour    -> logiciels (winget), pilotes et Windows (Windows Update)
#    Logiciels & jeux-> inventaire, explication, désinstallation vérifiée
#    Dans les deux cas : point de restauration, sauvegarde JSON de chaque
#    modification, puis NOUVELLE analyse pour vérifier que chaque correction
#    a vraiment corrigé le problème (onglet Rapport : avant / après)
#    Historique -> annulation d'une optimisation à partir de sa sauvegarde
#
#  Lancement : double-clic sur « Lancer-Optimiseur.bat ».
#  Compatible Windows 10 / 11 — Windows PowerShell 5.1.
# =====================================================================

# ---------------------------------------------------------------------
#  1. Droits administrateur
# ---------------------------------------------------------------------
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ErrorAction Stop `
            -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$PSCommandPath`""
    }
    catch {
        Write-Host "Les droits administrateur sont nécessaires pour optimiser le PC." -ForegroundColor Yellow
        Start-Sleep -Seconds 4
    }
    exit
}

# ---------------------------------------------------------------------
#  2. Chargement des bibliothèques, modules et de la fenêtre
# ---------------------------------------------------------------------
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

$script:Racine = Split-Path -Parent $PSCommandPath
$script:Version = '1.2.1'   # numéro affiché dans le menu ; même valeur que l'installateur
try {
    . (Join-Path $script:Racine 'modules\Utilitaires.ps1')
    . (Join-Path $script:Racine 'modules\Demarrage.ps1')
    . (Join-Path $script:Racine 'modules\Ecran.ps1')
    . (Join-Path $script:Racine 'modules\MisesAJour.ps1')
    . (Join-Path $script:Racine 'modules\Logiciels.ps1')
    . (Join-Path $script:Racine 'modules\Diagnostic.ps1')
    . (Join-Path $script:Racine 'modules\Taches.ps1')

    [xml]$xaml = Get-Content -Path (Join-Path $script:Racine 'interface\Fenetre.xaml') -Raw -Encoding UTF8
    $script:Fenetre = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
}
catch {
    # La console est cachée : on affiche l'erreur dans une boîte de dialogue
    [System.Windows.MessageBox]::Show("Impossible de démarrer Optimeo :`n$($_.Exception.Message)", 'Optimeo') | Out-Null
    exit 1
}

Write-Journal '===== Démarrage d''Optimeo ====='

# Récupère tous les éléments nommés (x:Name) dans $script:Controles
$script:Controles = @{}
foreach ($noeud in $xaml.SelectNodes("//*[@*[local-name()='Name']]")) {
    $nom = $noeud.Attributes | Where-Object { $_.LocalName -eq 'Name' } | Select-Object -First 1 -ExpandProperty Value
    $script:Controles[$nom] = $script:Fenetre.FindName($nom)
}
$C = $script:Controles   # alias court

# Logo et icône de la fenêtre (facultatifs : l'application fonctionne sans)
try {
    $logo = Join-Path $script:Racine 'interface\logo.png'
    $icone = Join-Path $script:Racine 'interface\logo.ico'
    if (Test-Path $logo) { $C.ImgLogo.Source = New-Object Windows.Media.Imaging.BitmapImage ([uri]$logo) }
    if (Test-Path $icone) { $script:Fenetre.Icon = [Windows.Media.Imaging.BitmapFrame]::Create([uri]$icone) }
}
catch { Write-Journal "Logo non chargé : $($_.Exception.Message)" 'ATTENTION' }
$C.TxtVersion.Text = "Version $script:Version"

# ---------------------------------------------------------------------
#  3. Données affichées (DataTable = liaison WPF fiable et modifiable)
# ---------------------------------------------------------------------
function New-Table([string[]]$Colonnes, [string[]]$ColonnesBool = @(), [string[]]$ColonnesEntier = @()) {
    <# Colonnes texte, puis booléennes, puis entiers 64 bits (tri numérique, ex. taille) #>
    $table = New-Object System.Data.DataTable
    foreach ($c in $Colonnes)       { [void]$table.Columns.Add($c, [string]) }
    foreach ($c in $ColonnesBool)   { [void]$table.Columns.Add($c, [bool]) }
    foreach ($c in $ColonnesEntier) { [void]$table.Columns.Add($c, [int64]) }
    return , $table
}

$script:TableTaches     = New-Table @('Id', 'Auto', 'Categorie', 'Titre', 'Impact', 'Risque', 'Etat', 'Detail') @('Selection', 'Modifiable')
$script:TableRapport    = New-Table @('Tache', 'Avant', 'Apres', 'Resultat', 'Etat')
$script:TableMaj        = New-Table @('Type', 'Nom', 'Actuelle', 'Disponible', 'Source', 'Etat', 'Detail', 'Cle') @('Selection', 'Modifiable')
$script:TableLogiciels  = New-Table @('Nom', 'Categorie', 'Description', 'Editeur', 'Version', 'Taille', 'Date', 'Source', 'Etat', 'Detail', 'Avertissement', 'Cle', 'Dossier') @('Selection', 'Modifiable') @('Octets')
$script:TableDiagnostic = New-Table @('Categorie', 'Element', 'Valeur', 'Etat')
$script:TableDemarrage  = New-Table @('Nom', 'Etat', 'Emplacement', 'Commande', 'Type', 'Cible', 'Avertissement') @('Selection', 'Modifiable')
$script:TableHistorique = New-Table @('Date', 'Titre', 'NbActions', 'Fichier')
$script:TableRecos      = New-Table @('Categorie', 'Titre', 'Detail', 'Etat')   # tableau de bord : 5 recommandations

$C.GrilleTaches.ItemsSource     = $script:TableTaches.DefaultView
$C.GrilleDiagnostic.ItemsSource = $script:TableDiagnostic.DefaultView
$C.GrilleRapport.ItemsSource    = $script:TableRapport.DefaultView
$C.GrilleMaj.ItemsSource        = $script:TableMaj.DefaultView
$C.GrilleLogiciels.ItemsSource  = $script:TableLogiciels.DefaultView
$C.GrilleDemarrage.ItemsSource  = $script:TableDemarrage.DefaultView
$C.GrilleHistorique.ItemsSource = $script:TableHistorique.DefaultView
$C.ListeRecommandations.ItemsSource = $script:TableRecos.DefaultView

# Index des tâches par Id pour retrouver les scriptblocks
$script:TachesParId = @{}
foreach ($t in $script:CatalogueTaches) { $script:TachesParId[$t.Id] = $t }

$script:Diagnostic = $null
$script:Occupe = $false

# Position des pages dans Fenetre.xaml (même ordre que le menu latéral MenuNavigation)
$script:Onglets = @{ Accueil = 0; Taches = 1; Rapport = 2; MisesAJour = 3; Logiciels = 4; Diagnostic = 5; Demarrage = 6; Historique = 7 }

# ---------------------------------------------------------------------
#  4. Fonctions d'interface
# ---------------------------------------------------------------------
function Set-Statut([string]$Texte) {
    <# Met à jour la barre d'état et rafraîchit la fenêtre #>
    $C.TxtStatut.Text = $Texte
    Update-Interface
}
# Les modules affichent leur avancement via Write-Progression -> Set-Statut
$script:CallbackStatut = { param($texte) Set-Statut $texte }

function Set-Occupe([bool]$Occupe, [string]$Texte = '') {
    <# Bloque les boutons pendant un traitement et affiche la progression #>
    $script:Occupe = $Occupe
    foreach ($bouton in @('BtnAnalyser', 'BtnToutOptimiser', 'BtnAppliquer', 'BtnAnnuler', 'BtnDesactiverDemarrage', 'BtnActiverDemarrage',
            'BtnActualiserDemarrage', 'BtnOuvrir', 'BtnCocherRecommandes', 'BtnToutDecocher', 'BtnRechercherMaj', 'BtnCocherMaj', 'BtnListerLogiciels', 'BtnDesinstaller')) {
        $C[$bouton].IsEnabled = -not $Occupe
    }
    $C.BtnInstallerMaj.IsEnabled = (-not $Occupe) -and ($script:TableMaj.Rows.Count -gt 0)
    if (-not $Occupe) { $C.BtnAppliquer.IsEnabled = ($null -ne $script:Diagnostic) }
    Update-BoutonsLogiciel   # évite de lancer une 2e opération pendant la première
    $C.Progression.IsIndeterminate = $Occupe
    $C.Progression.Visibility = if ($Occupe) { 'Visible' } else { 'Hidden' }
    if ($Texte) { Set-Statut $Texte }
}

function Update-BoutonsLogiciel {
    <# Active les boutons du panneau « Logiciels & jeux » : seulement si une ligne
       est sélectionnée et qu'aucun traitement n'est en cours. #>
    $ligne = Get-LogicielSelectionne
    $actif = [bool]$ligne -and (-not $script:Occupe)
    $C.BtnEnSavoirPlus.IsEnabled = $actif
    $C.BtnWebLogiciel.IsEnabled = $actif
    $C.BtnDossierLogiciel.IsEnabled = $actif -and $ligne.Dossier -and (Test-Path -LiteralPath $ligne.Dossier -ErrorAction SilentlyContinue)
}

function Test-SecuriteDemarrage {
    <# Deux contrôles au lancement, sans rien bloquer :
       1. le dossier du logiciel ne doit pas être modifiable par un compte sans
          droits : sinon n'importe quel programme pourrait modifier le code qui,
          lui, s'exécute en administrateur ;
       2. si l'élévation a été faite avec un AUTRE compte administrateur, tous les
          réglages « par utilisateur » (nettoyage, démarrage, jeux) viseraient ce
          compte-là et non celui de la session. #>
    $avertissements = New-Object System.Collections.ArrayList
    try {
        $droits = (Get-Acl -LiteralPath $script:Racine).Access
        $comptesLarges = @('S-1-5-32-545', 'S-1-5-11', 'S-1-1-0')   # Utilisateurs, Utilisateurs authentifiés, Tout le monde
        $modifiable = @($droits | Where-Object {
                $_.AccessControlType -eq 'Allow' -and
                ($_.FileSystemRights -band [Security.AccessControl.FileSystemRights]::Write) -and
                (try { $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value } catch { '' }) -in $comptesLarges
            })
        if ($modifiable.Count -gt 0) {
            [void]$avertissements.Add("Le dossier « $script:Racine » est modifiable par n'importe quel compte de ce PC. Comme Optimeo s'exécute en administrateur, installe-le plutôt dans C:\Program Files (installateur fourni).")
        }
    }
    catch { }
    try {
        $explorateur = @(Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" -ErrorAction Stop)[0]
        if ($explorateur) {
            $proprietaire = Invoke-CimMethod -InputObject $explorateur -MethodName GetOwner -ErrorAction Stop
            $sessionUtilisateur = '{0}\{1}' -f $proprietaire.Domain, $proprietaire.User
            $courant = [Security.Principal.WindowsIdentity]::GetCurrent().Name
            if ($proprietaire.User -and $sessionUtilisateur -ne $courant) {
                [void]$avertissements.Add("Optimeo tourne sous le compte « $courant » alors que la session Windows est ouverte avec « $sessionUtilisateur ». Les réglages personnels (nettoyage, démarrage, jeux) s'appliqueront au compte « $courant ». Pour agir sur ta session, connecte-toi avec un compte administrateur.")
            }
        }
    }
    catch { }
    foreach ($a in $avertissements) { Write-Journal $a 'ATTENTION' }
    if ($avertissements.Count -gt 0) { Show-Message (($avertissements -join "`n`n")) 'OK' 'Warning' | Out-Null }
}

function Show-Message([string]$Texte, [string]$Boutons = 'OK', [string]$Icone = 'Information') {
    <# Boîte de dialogue ; renvoie 'OK', 'Yes', 'No'… #>
    return [System.Windows.MessageBox]::Show($script:Fenetre, $Texte, 'Optimeo', [System.Windows.MessageBoxButton]$Boutons, [System.Windows.MessageBoxImage]$Icone).ToString()
}

function Update-Compteur {
    <# Affiche le nombre de tâches cochées #>
    $nb = @($script:TableTaches.Rows | Where-Object { $_.Selection }).Count
    $C.TxtCompteur.Text = "$nb tâche(s) sélectionnée(s)"
}

function Initialize-TableTaches {
    <# Remplit la liste des tâches avant la première analyse #>
    $script:TableTaches.Rows.Clear()
    foreach ($t in $script:CatalogueTaches) {
        [void]$script:TableTaches.Rows.Add($t.Id, $(if ($t.Auto) { '⚡' } else { '' }), $t.Categorie, $t.Titre, $t.Impact, $t.Risque, 'Non analysé', '', $false, $false)
    }
    Update-Compteur
}

function Reset-Grille($Grille, $Table, [scriptblock]$Remplir) {
    <# Recharge une grille sans risque : termine l'édition en cours (case
       cochée) et détache la grille le temps de vider / remplir la table.
       Évite l'erreur WPF « DeferRefresh non autorisé pendant une édition ». #>
    try { [void]$Grille.CommitEdit([System.Windows.Controls.DataGridEditingUnit]::Row, $true) } catch { }
    $Grille.ItemsSource = $null
    try {
        foreach ($ligne in $Table.Rows) { $ligne.EndEdit() }
        $Table.Rows.Clear()
        & $Remplir
    }
    finally { $Grille.ItemsSource = $Table.DefaultView }
}

function Update-TableDemarrage($Programmes = $null) {
    <# Recharge la liste des programmes au démarrage (relue si non fournie) #>
    if ($null -eq $Programmes) { $Programmes = @(Get-ProgrammesDemarrage) }
    Reset-Grille $C.GrilleDemarrage $script:TableDemarrage {
        foreach ($p in ($Programmes | Sort-Object @{ e = { -not $_.Actif } }, Nom)) {
            $alerte = if (-not $p.Modifiable) { 'Imposé par une stratégie : non modifiable' } else { $p.Avertissement }
            [void]$script:TableDemarrage.Rows.Add($p.Nom, $(if ($p.Actif) { 'Actif' } else { 'Désactivé' }), $p.Emplacement,
                $p.Commande, $p.Type, $p.Cible, $alerte, $false, $p.Modifiable)
        }
    }
    Set-Badge $C.BadgeDemarrage $C.TxtBadgeDemarrage @($Programmes | Where-Object { $_.Actif }).Count
}

function Update-TableHistorique {
    <# Recharge la liste des sauvegardes annulables #>
    Reset-Grille $C.GrilleHistorique $script:TableHistorique {
        foreach ($s in (Get-Sauvegardes)) {
            [void]$script:TableHistorique.Rows.Add($s.Date, $s.Titre, "$($s.NbActions)", $s.Fichier)
        }
    }
    Update-EtatsVides
}

# ---------------------------------------------------------------------
#  4 bis. Tableau de bord, badges du menu et pages vides
# ---------------------------------------------------------------------
function Set-Badge($Badge, $Texte, [int]$Nombre) {
    <# Affiche un compteur dans le menu latéral (masqué s'il vaut 0) #>
    $Texte.Text = "$Nombre"
    $Badge.Visibility = if ($Nombre -gt 0) { 'Visible' } else { 'Collapsed' }
}

function Update-EtatsVides {
    <# Affiche un message d'aide à la place d'une liste vide #>
    $vides = @(
        @($C.TxtRapportVide, $script:TableRapport),
        @($C.TxtMajVide, $script:TableMaj),
        @($C.TxtDiagnosticVide, $script:TableDiagnostic),
        @($C.TxtHistoriqueVide, $script:TableHistorique),
        @($C.TxtAucuneReco, $script:TableRecos)
    )
    foreach ($v in $vides) { $v[0].Visibility = if ($v[1].Rows.Count -eq 0) { 'Visible' } else { 'Collapsed' } }
}

function Get-OctetsDansTexte([string]$Texte) {
    <# Additionne les tailles écrites par Format-Taille dans un texte
       (ex. « Chrome 300 Mo ; Edge 1,2 Go » -> octets). Sert au total « Gains possibles ». #>
    [double]$total = 0
    $unites = @{ 'Ko' = 1KB; 'Mo' = 1MB; 'Go' = 1GB }
    foreach ($m in [regex]::Matches($Texte, '(\d[\d\u00A0\u202F ]*(?:,\d+)?)\s(Go|Mo|Ko)\b')) {
        $nombre = ($m.Groups[1].Value -replace '[\s\u00A0\u202F]', '') -replace ',', '.'
        $total += [double]$nombre * $unites[$m.Groups[2].Value]
    }
    return [int64]$total
}

function Get-ScoreSante {
    <# Note de santé de 0 à 100 : on part de 100 et on retire des points
       pour chaque point à améliorer trouvé par l'analyse :
         tâche « Recommandé » -6, « Manuel » -8, « Optionnel » -1
         ligne de diagnostic « Problème » -12, « Attention » -4 #>
    $score = 100
    foreach ($ligne in $script:TableTaches.Rows) {
        switch ($ligne.Etat) { 'Recommandé' { $score -= 6 } 'Manuel' { $score -= 8 } 'Optionnel' { $score -= 1 } }
    }
    foreach ($ligne in $script:TableDiagnostic.Rows) {
        switch ($ligne.Etat) { 'Problème' { $score -= 12 } 'Attention' { $score -= 4 } }
    }
    return [math]::Max(0, [math]::Min(100, $score))
}

function Update-TableauDeBord {
    <# Remplit la page d'accueil à partir de la dernière analyse #>
    if (-not $script:Diagnostic) { return }
    $D = $script:Diagnostic.Donnees

    # --- Note de santé et anneau (longueur d'arc en épaisseurs de trait : périmètre / épaisseur) ---
    $score = Get-ScoreSante
    $C.TxtScore.Text = "$score"
    $perimetre = [math]::PI * ($C.ArcScore.Parent.Width - $C.ArcScore.StrokeThickness) / $C.ArcScore.StrokeThickness
    $longueurArc = [math]::Round([math]::Max(0.01, $perimetre * $score / 100), 2)
    $C.ArcScore.StrokeDashArray = [Windows.Media.DoubleCollection]::Parse("$longueurArc 1000")   # interpolation = point décimal
    $C.ArcScore.Visibility = if ($score -gt 0) { 'Visible' } else { 'Hidden' }   # évite un point isolé à 0
    $niveau = if ($score -ge 85) { @('excellente', '#22C55E') } elseif ($score -ge 65) { @('correcte', '#F97316') } else { @('à améliorer', '#EF4444') }
    $C.TxtEtatSante.Text = "Santé du PC : $($niveau[0])"
    $C.ArcScore.Stroke = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($niveau[1]))

    $automatiques = @(Get-LignesAutomatiques)
    $nbManuel = @($script:TableTaches.Rows | Where-Object { $_.Etat -eq 'Manuel' }).Count
    $C.TxtConseilSante.Text = if ($automatiques.Count -gt 0) {
        "$($automatiques.Count) optimisation(s) sûre(s) peuvent être appliquées automatiquement. Optimeo tente de créer un point de restauration."
    }
    elseif ($nbManuel -gt 0) { "Rien à corriger automatiquement. $nbManuel action(s) à faire toi-même : voir la page Tâches." }
    else { 'Tout est optimisé : rien à corriger pour le moment.' }

    # --- Gains possibles ---
    [int64]$espace = 0
    foreach ($ligne in @($automatiques | Where-Object { $_.Categorie -eq 'Nettoyage' })) { $espace += Get-OctetsDansTexte $ligne.Detail }
    $C.TxtGainEspace.Text = if ($espace -gt 0) { "≈ $(Format-Taille $espace)" } else { '0' }
    $C.TxtGainAuto.Text = "$($automatiques.Count)"
    Set-Badge $C.BadgeTaches $C.TxtBadgeTaches ($automatiques.Count + $nbManuel)

    # --- Cartes matériel ---
    $C.TxtCarteCpu.Text = ($D.CpuNom -replace '\s+\d+-Core Processor$', '' -replace '\(R\)|\(TM\)', '')
    $C.TxtCarteCpuInfo.Text = "$($D.CpuCoeurs) cœurs · $($D.CpuThreads) threads"
    $C.TxtCarteRam.Text = "$($D.RamGo) Go"
    $C.TxtCarteRamInfo.Text = if (-not $D.RamVitesse) { 'Vitesse inconnue' }
    elseif ($D.XmpSuspect) { "⚠ $($D.RamType) à $($D.RamVitesse) MT/s : XMP / EXPO probablement inactif" }
    elseif ($D.XmpAVerifier) { "$($D.RamType) à $($D.RamVitesse) MT/s : profil XMP / EXPO à vérifier" }
    else { "✔ $($D.RamType) à $($D.RamVitesse) MT/s" }
    $gpu = @($D.Gpus | Where-Object { $_.Marque -in @('NVIDIA', 'AMD', 'Intel') } | Select-Object -First 1)
    if ($gpu) {
        $C.TxtCarteGpu.Text = $gpu[0].Nom -replace '^(NVIDIA GeForce|AMD Radeon\(TM\)|AMD Radeon|Intel\(R\))\s+', ''
        $C.TxtCarteGpuInfo.Text = "Pilote $($gpu[0].Version)" + $(if ($null -ne $gpu[0].AgePilote) { " · il y a $($gpu[0].AgePilote) j" } else { '' })
    }
    else { $C.TxtCarteGpu.Text = 'Non détectée'; $C.TxtCarteGpuInfo.Text = '' }
    $lettreSysteme = $env:SystemDrive.TrimEnd(':')
    $volume = @($D.Volumes | Where-Object { $_.Lettre -eq $lettreSysteme } | Select-Object -First 1)
    if ($volume) {
        $C.TxtCarteDisque.Text = "$($volume[0].LibreGo) Go libres / $($volume[0].TotalGo) Go"
        $C.BarreDisque.Value = 100 - $volume[0].LibrePct
        $C.BarreDisque.Foreground = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($(if ($volume[0].LibrePct -lt 10) { '#EF4444' } else { '#FBBF24' })))
    }

    # --- 5 recommandations : « Recommandé », « Manuel », puis les « Optionnel » que Tout optimiser corrigera ---
    $ordre = @{ 'Recommandé' = 0; 'Manuel' = 1; 'Optionnel' = 2 }
    $choix = @($script:TableTaches.Rows | Where-Object { ($_.Etat -in @('Recommandé', 'Manuel')) -or ($automatiques -contains $_) } |
            Sort-Object @{ e = { $ordre[$_.Etat] } }, @{ e = { -not $script:TachesParId[$_.Id].Auto } } | Select-Object -First 5)
    $script:TableRecos.Rows.Clear()
    foreach ($ligne in $choix) { [void]$script:TableRecos.Rows.Add($ligne.Categorie, $ligne.Titre, $ligne.Detail, $ligne.Etat) }
    $C.TxtAucuneReco.Text = 'Rien d''important à corriger : les réglages facultatifs restent visibles dans la page Tâches.'
    Update-EtatsVides
}

function Update-GainMisesAJour {
    <# Nombre de mises à jour disponibles : tableau de bord + badge du menu #>
    $nb = @($script:TableMaj.Rows | Where-Object { $_.Etat -eq 'Disponible' }).Count
    $C.TxtGainMaj.Text = "$nb"
    $C.TxtGainMajLibelle.Text = 'mises à jour disponibles'
    Set-Badge $C.BadgeMaj $C.TxtBadgeMaj $nb
}

# ---------------------------------------------------------------------
#  5. Actions principales
# ---------------------------------------------------------------------
function Invoke-Analyse {
    <# Diagnostic complet + vérification de chaque tâche (aucune modification) #>
    Set-Occupe $true 'Analyse en cours…'
    try {
        $script:Diagnostic = Get-DiagnosticSysteme
        $D = $script:Diagnostic.Donnees

        # Onglet Diagnostic
        $script:TableDiagnostic.Rows.Clear()
        foreach ($l in $script:Diagnostic.Lignes) { [void]$script:TableDiagnostic.Rows.Add($l.Categorie, $l.Element, $l.Valeur, $l.Etat) }

        # Sous-titre du tableau de bord
        $C.TxtResume.Text = 'Dernière analyse : aujourd''hui à {0}  ·  {1}  ·  allumé depuis {2} jour(s)' -f (Get-Date -Format 'HH:mm'), $D.NomSysteme, $D.JoursAllume

        # Onglet Tâches : vérification une par une
        foreach ($ligne in $script:TableTaches.Rows) {
            $tache = $script:TachesParId[$ligne.Id]
            Set-Statut "Vérification : $($tache.Titre)"
            try { $resultat = & $tache.Verifier $D }
            catch { $resultat = New-Resultat 'Non applicable' "Vérification impossible : $($_.Exception.Message)"; Write-Journal "Vérification $($tache.Id) : $($_.Exception.Message)" 'ERREUR' }
            $resultat = @($resultat)[-1]
            $modifiable = (-not $tache.Manuel) -and ($resultat.Etat -ne 'Non applicable')
            $ligne.Etat       = $resultat.Etat
            $ligne.Detail     = $resultat.Detail
            $ligne.Modifiable = $modifiable
            $ligne.Selection  = $modifiable -and ($resultat.Etat -eq 'Recommandé')
        }

        Update-TableDemarrage $D.ProgrammesDemarrage   # déjà lue par le diagnostic
        Update-TableHistorique
        Update-Compteur
        Update-TableauDeBord

        $nbReco   = @($script:TableTaches.Rows | Where-Object { $_.Etat -eq 'Recommandé' }).Count
        $nbManuel = @($script:TableTaches.Rows | Where-Object { $_.Etat -eq 'Manuel' }).Count
        Write-Journal "Analyse terminée : $nbReco recommandée(s), $nbManuel manuelle(s)"
        $nbAuto   = @(Get-LignesAutomatiques).Count
        Set-Occupe $false "Analyse terminée : $nbAuto correction(s) automatique(s) disponible(s) (bouton « Tout optimiser »), $nbManuel action(s) manuelle(s)."
    }
    catch {
        Write-Journal "Erreur d'analyse : $($_.Exception.Message)" 'ERREUR'
        Set-Occupe $false 'Erreur pendant l''analyse (voir le journal).'
        Show-Message "Erreur pendant l'analyse :`n$($_.Exception.Message)" 'OK' 'Error' | Out-Null
    }
}

function Get-LignesAutomatiques {
    <# Tâches « ⚡ » qui ont réellement quelque chose à corriger #>
    return @($script:TableTaches.Rows | Where-Object {
            $script:TachesParId[$_.Id].Auto -and $_.Modifiable -and ($_.Etat -in @('Recommandé', 'Optionnel'))
        })
}

function Invoke-Corrections {
    <# Cœur commun à « Tout optimiser » et « Appliquer la sélection » :
         1. point de restauration
         2. application de chaque tâche (erreurs strictes, sauvegarde JSON)
         3. nouvelle analyse complète
         4. contrôle : la correction n'est « vérifiée » que si l'état est devenu OK
         5. onglet Rapport (avant / après) et proposition de redémarrage #>
    param([object[]]$Lignes)

    $suivis = New-Object System.Collections.ArrayList
    $annule = $false
    Set-Occupe $true 'Création du point de restauration (peut prendre une minute)…'
    try {
        if (-not (New-PointRestauration)) {
            $suite = Show-Message "Le point de restauration n'a pas pu être créé (voir le journal).`n`nContinuer quand même ? Les réglages modifiés restent annulables depuis la page Historique." 'YesNo' 'Warning'
            if ($suite -ne 'Yes') { $annule = $true; return }
        }

        # --- Application ---
        $donnees = $script:Diagnostic.Donnees
        $numero = 0
        foreach ($ligne in $Lignes) {
            $numero++
            $tache = $script:TachesParId[$ligne.Id]
            Set-Statut "[$numero/$($Lignes.Count)] $($tache.Titre)…"
            $suivi = [pscustomobject]@{ Id = $tache.Id; Titre = $tache.Titre; Avant = $ligne.Detail; Succes = $false; Message = '' }
            $script:ActionsEnCours.Clear()
            $script:TacheEnCours = $tache
            $script:FichierAction = Join-Path $script:DossierSauvegardes ('{0}_{1}_{2}.json' -f (Get-Date -Format 'yyyyMMdd-HHmmss-fff'), $tache.Id, [guid]::NewGuid())
            try {
                $suivi.Message = [string]@(& { $ErrorActionPreference = 'Stop'; & $tache.Appliquer $donnees })[-1]
                $suivi.Succes = $true
                Write-Journal "Tâche appliquée : $($tache.Id) — $($suivi.Message)"
            }
            catch {
                $suivi.Message = $_.Exception.Message
                Write-Journal "Échec tâche $($tache.Id) : $($suivi.Message)" 'ERREUR'
            }
            finally {
                $script:TacheEnCours = $null
                $script:FichierAction = $null
            }
            [void]$suivis.Add($suivi)
        }
    }
    catch {
        Write-Journal "Erreur pendant l'application : $($_.Exception.Message)" 'ERREUR'
        Show-Message "Application interrompue : $($_.Exception.Message)" 'OK' 'Error' | Out-Null
    }
    finally {
        Set-Occupe $false $(if ($annule) { 'Application annulée.' } else { 'Contrôle des corrections…' })
    }
    if ($annule -or $suivis.Count -eq 0) { return }

    # --- Contrôle : nouvelle analyse, puis lecture du nouvel état de chaque tâche ---
    Invoke-Analyse
    # (compteurs calculés ici : un scriptblock passé à Reset-Grille s'exécute
    #  dans une portée enfant et ne pourrait pas les modifier)
    $nbVerifiees = 0; $nbPartielles = 0; $nbEchecs = 0; $redemarrer = $false
    $lignesRapport = New-Object System.Collections.ArrayList
    foreach ($suivi in $suivis) {
        $ligne = @($script:TableTaches.Rows | Where-Object { $_.Id -eq $suivi.Id })[0]
        if (-not $suivi.Succes) {
            $nbEchecs++
            [void]$lignesRapport.Add(@($suivi.Titre, $suivi.Avant, $suivi.Message, '✖ Échec', 'Problème'))
        }
        elseif ($ligne.Etat -eq 'OK') {
            $nbVerifiees++
            if ($script:TachesParId[$suivi.Id].Redemarrage) { $redemarrer = $true }
            [void]$lignesRapport.Add(@($suivi.Titre, $suivi.Avant, "$($ligne.Detail) — $($suivi.Message)", '✔ Corrigé et vérifié', 'OK'))
        }
        else {
            $nbPartielles++
            [void]$lignesRapport.Add(@($suivi.Titre, $suivi.Avant, "$($ligne.Detail) — $($suivi.Message)", '⚠ Pas entièrement corrigé', 'Attention'))
        }
    }
    # Rappel de ce qui ne peut pas être fait automatiquement
    foreach ($ligne in @($script:TableTaches.Rows | Where-Object { $_.Etat -eq 'Manuel' })) {
        [void]$lignesRapport.Add(@($ligne.Titre, $ligne.Detail, "Non automatisable : explications et bouton « Ouvrir » dans la page Tâches", '👉 À faire toi-même', 'Manuel'))
    }
    Reset-Grille $C.GrilleRapport $script:TableRapport {
        foreach ($valeurs in $lignesRapport) { [void]$script:TableRapport.Rows.Add([object[]]$valeurs) }
    }
    Update-EtatsVides

    $resume = "$nbVerifiees corrigée(s) et vérifiée(s), $nbPartielles partielle(s), $nbEchecs échec(s)."
    Write-Journal "Corrections : $resume"
    Set-Statut "Terminé : $resume Détails dans la page Rapport."
    $C.Onglets.SelectedIndex = $script:Onglets.Rapport

    if ($redemarrer) {
        if ((Show-Message "$resume`n`nCertaines corrections ne prennent effet qu'après un redémarrage.`nRedémarrer maintenant ?" 'YesNo' 'Question') -eq 'Yes') {
            Write-Journal 'Redémarrage demandé par l''utilisateur'
            Start-Process -FilePath 'shutdown.exe' -ArgumentList '/r /t 5' -WindowStyle Hidden
        }
    }
    else {
        Show-Message "$resume`n`nLe détail avant / après est dans la page Rapport." | Out-Null
    }
}

function Invoke-ToutOptimiser {
    <# Un clic : analyse si nécessaire, puis toutes les corrections automatiques utiles #>
    if (-not $script:Diagnostic) { Invoke-Analyse }
    if (-not $script:Diagnostic) { return }   # analyse en échec

    $lignes = Get-LignesAutomatiques
    if ($lignes.Count -eq 0) {
        Show-Message "Rien à corriger automatiquement : tout est déjà optimisé.`n`nConsulte les actions manuelles (pastilles bleues « Manuel ») dans la page Tâches." | Out-Null
        return
    }
    $liste = ($lignes | ForEach-Object { "  ⚡ $($_.Titre)" }) -join "`n"
    $question = "Tout optimiser va corriger automatiquement :`n`n$liste`n`nOptimeo tente de créer un point de restauration. Les réglages réversibles sont sauvegardés avant modification. Les fichiers nettoyés sont supprimés définitivement."
    if ((Show-Message $question 'YesNo' 'Question') -ne 'Yes') { return }
    Invoke-Corrections -Lignes $lignes
}

function Invoke-Application {
    <# Applique uniquement les tâches cochées (même contrôle que Tout optimiser) #>
    $selection = @($script:TableTaches.Rows | Where-Object { $_.Selection -and $_.Modifiable })
    if ($selection.Count -eq 0) { Show-Message 'Aucune tâche cochée.' | Out-Null; return }
    $liste = ($selection | ForEach-Object { "  • $($_.Titre)" }) -join "`n"
    if ((Show-Message "Appliquer ces $($selection.Count) optimisation(s) ?`n`n$liste`n`nOptimeo tentera de créer un point de restauration Windows." 'YesNo' 'Question') -ne 'Yes') { return }
    Invoke-Corrections -Lignes $selection
}

function Invoke-Annulation {
    <# Annule l'optimisation sélectionnée dans l'onglet Historique #>
    $ligne = $C.GrilleHistorique.SelectedItem
    if (-not $ligne) { Show-Message "Sélectionne d'abord une optimisation dans la liste." | Out-Null; return }
    $titre = $ligne.Row.Titre; $date = $ligne.Row.Date; $fichier = $ligne.Row.Fichier
    if ((Show-Message "Annuler « $titre » du $date ?`n`nConseil : annule les optimisations de la plus récente à la plus ancienne." 'YesNo' 'Question') -ne 'Yes') { return }

    $message = $null; $icone = 'Information'
    Set-Occupe $true 'Annulation en cours…'
    try {
        $erreurs = Undo-Sauvegarde $fichier
        if ($erreurs -gt 0) {
            $message = "Annulation incomplète : $erreurs réglage(s) non restauré(s) (voir le journal).`nL'optimisation reste dans l'historique pour réessayer."
            $icone = 'Warning'
        }
        else { $message = 'Optimisation annulée. Certains réglages nécessitent une déconnexion ou un redémarrage.' }
    }
    catch {
        Write-Journal "Annulation impossible ($fichier) : $($_.Exception.Message)" 'ERREUR'
        $message = "Annulation impossible : $($_.Exception.Message)"; $icone = 'Error'
    }
    finally { Set-Occupe $false 'Annulation terminée.' }

    Show-Message $message 'OK' $icone | Out-Null
    if ($script:Diagnostic) { Invoke-Analyse } else { Update-TableHistorique }
}

function Set-DemarrageSelection([bool]$Actif) {
    <# Active / désactive les programmes cochés dans l'onglet Démarrage.
       Demande confirmation pour les entrées sensibles (audio, sécurité…). #>
    $selection = @($script:TableDemarrage.Rows | Where-Object { $_.Selection -and $_.Modifiable })
    if ($selection.Count -eq 0) { Show-Message 'Coche au moins un programme modifiable.' | Out-Null; return }

    if (-not $Actif) {
        $sensibles = @($selection | Where-Object { $_.Avertissement })
        if ($sensibles.Count -gt 0) {
            $liste = ($sensibles | ForEach-Object { "  • $($_.Nom) : $($_.Avertissement)" }) -join "`n"
            if ((Show-Message "Ces programmes ont un rôle utile :`n`n$liste`n`nLes désactiver quand même ?" 'YesNo' 'Warning') -ne 'Yes') { return }
        }
    }

    # Copie des infos avant rechargement de la table
    $entrees = @($selection | ForEach-Object { [pscustomobject]@{ Type = $_.Type; Cible = $_.Cible; Nom = $_.Nom } })
    $echecs = New-Object System.Collections.ArrayList
    Set-Occupe $true 'Modification du démarrage…'
    try {
        foreach ($e in $entrees) {
            try { Set-EtatDemarrage -Type $e.Type -Cible $e.Cible -Nom $e.Nom -Actif $Actif }
            catch { [void]$echecs.Add("$($e.Nom) : $($_.Exception.Message)"); Write-Journal "Démarrage $($e.Nom) : $($_.Exception.Message)" 'ERREUR' }
        }
        Update-TableDemarrage
    }
    finally {
        $ok = $entrees.Count - $echecs.Count
        Set-Occupe $false ("{0} programme(s) {1}. Effet au prochain démarrage." -f $ok, $(if ($Actif) { 'réactivé(s)' } else { 'désactivé(s)' }))
    }
    if ($echecs.Count -gt 0) { Show-Message ("Échec pour :`n" + ($echecs -join "`n")) 'OK' 'Warning' | Out-Null }
}

# ---------------------------------------------------------------------
#  5 bis. Mises à jour (onglet « Mises à jour »)
# ---------------------------------------------------------------------
function Update-TableMaj([object[]]$MisesAJour) {
    <# Affiche les mises à jour : disponibles d'abord, puis infos manuelles #>
    $ordre = @{ 'Disponible' = 0; 'Manuel' = 1 }
    Reset-Grille $C.GrilleMaj $script:TableMaj {
        foreach ($m in ($MisesAJour | Sort-Object @{ e = { if ($ordre.ContainsKey($_.Etat)) { $ordre[$_.Etat] } else { 2 } } }, Type, Nom)) {
            [void]$script:TableMaj.Rows.Add($m.Type, $m.Nom, $m.Actuelle, $m.Disponible, $m.Source, $m.Etat, $m.Detail, $m.Cle, $m.Selection, $m.Modifiable)
        }
    }
    Update-GainMisesAJour
    Update-EtatsVides
}

function Invoke-RechercheMisesAJour {
    <# Recherche logiciels (winget), pilotes et Windows (Windows Update), infos BIOS / GPU #>
    $toutes = New-Object System.Collections.ArrayList
    $erreurs = New-Object System.Collections.ArrayList
    Set-Occupe $true 'Recherche des mises à jour des logiciels (winget)…'
    try {
        try { foreach ($m in @(Get-MisesAJourLogiciels)) { [void]$toutes.Add($m) } }
        catch { [void]$erreurs.Add("Logiciels : $($_.Exception.Message)") }

        Set-Statut 'Recherche des pilotes et mises à jour Windows (1 à 3 minutes)…'
        try { foreach ($m in @(Get-MisesAJourWindows)) { [void]$toutes.Add($m) } }
        catch { [void]$erreurs.Add("Windows Update : $($_.Exception.Message)") }

        Set-Statut 'Lecture du BIOS et du pilote graphique…'
        try {
            if (-not $script:Diagnostic) { $script:Diagnostic = Get-DiagnosticSysteme }
            foreach ($m in @(Get-InfosMisesAJourMateriel $script:Diagnostic.Donnees)) { [void]$toutes.Add($m) }
        }
        catch { [void]$erreurs.Add("Matériel : $($_.Exception.Message)") }

        Update-TableMaj $toutes
    }
    finally {
        $nb = @($toutes | Where-Object { $_.Etat -eq 'Disponible' }).Count
        Set-Occupe $false $(if ($erreurs.Count -gt 0) { "Recherche incomplète. $nb mise(s) à jour trouvée(s)." } elseif (@($toutes | Where-Object { $_.Type -eq 'Logiciel' -and $_.Etat -eq 'Manuel' }).Count) { "Logiciels à vérifier manuellement. $nb mise(s) à jour trouvée(s)." } elseif ($nb -gt 0) { "$nb mise(s) à jour disponible(s). Vérifie la sélection puis « Installer la sélection »." } else { 'Tout est à jour.' })
        Write-Journal "Recherche de mises à jour : $nb disponible(s)"
    }
    if ($erreurs.Count -gt 0) { Show-Message ("Recherche incomplète :`n" + ($erreurs -join "`n")) 'OK' 'Warning' | Out-Null }
}

function Invoke-InstallationMisesAJour {
    <# Installe les mises à jour cochées puis vérifie le résultat :
       logiciels -> nouvelle recherche winget ; Windows Update -> code de résultat.
       Les lignes « Manuel » (BIOS, pilote graphique) ouvrent la page du fabricant. #>
    $selection = @($script:TableMaj.Rows | Where-Object { $_.Selection })
    if ($selection.Count -eq 0) { Show-Message 'Coche au moins une mise à jour.' | Out-Null; return }
    $logiciels = @($selection | Where-Object { $_.Type -eq 'Logiciel' -and $_.Modifiable })
    $windows   = @($selection | Where-Object { $_.Type -in @('Pilote', 'Windows') -and $_.Modifiable })
    $liens     = @($selection | Where-Object { $_.Cle -like 'http*' })

    $liste = ($selection | ForEach-Object { "  • [$($_.Type)] $($_.Nom)" }) -join "`n"
    $avertissement = if ($windows.Count -gt 0) { "`n`nUn point de restauration sera créé avant les pilotes / mises à jour Windows." } else { '' }
    if ((Show-Message "Installer ces mises à jour ?`n`n$liste$avertissement`n`nFerme les logiciels concernés avant de continuer." 'YesNo' 'Question') -ne 'Yes') { return }

    $redemarrer = $false
    Set-Occupe $true 'Installation des mises à jour…'
    try {
        # --- Pilotes et Windows : point de restauration puis lot unique ---
        if ($windows.Count -gt 0) {
            Set-Statut 'Création du point de restauration…'
            if (-not (New-PointRestauration)) {
                if ((Show-Message "Le point de restauration n'a pas pu être créé. Installer quand même les pilotes / mises à jour Windows ?" 'YesNo' 'Warning') -ne 'Yes') { $windows = @() }
            }
        }

        # --- Logiciels (winget), un par un ---
        $numero = 0
        foreach ($ligne in $logiciels) {
            $numero++
            $ligne.Etat = 'Installation…'
            Set-Statut "[$numero/$($logiciels.Count)] Mise à jour de $($ligne.Nom)…"
            try { Install-MiseAJourLogiciel -Id $ligne.Cle; $ligne.Etat = 'Installé'; $ligne.Detail = "Mis à jour vers $($ligne.Disponible)" }
            catch { $ligne.Etat = 'Échec'; $ligne.Detail = $_.Exception.Message }
        }

        if ($windows.Count -gt 0) {
            foreach ($ligne in $windows) { $ligne.Etat = 'Installation…' }
            Set-Statut "Téléchargement et installation de $($windows.Count) mise(s) à jour Windows Update (plusieurs minutes)…"
            try {
                $retour = Install-MisesAJourWindows -Ids @($windows | ForEach-Object { $_.Cle })
                $redemarrer = $retour.RedemarrageRequis
                foreach ($ligne in $windows) {
                    $d = @($retour.Details | Where-Object { $_.Id -eq $ligne.Cle })[0]
                    if ($d -and $d.Reussi) { $ligne.Etat = 'Installé'; $ligne.Detail = $(if ($redemarrer) { 'Installé (redémarrage nécessaire)' } else { 'Installé' }) }
                    elseif ($d -and $d.Code -eq 3) { $ligne.Etat = 'Attention'; $ligne.Detail = 'Windows Update a terminé avec des erreurs.' }
                    else { $ligne.Etat = 'Échec'; $ligne.Detail = $(if ($d) { "Windows Update : code $($d.Code)" } else { 'Non traité par Windows Update' }) }
                }
            }
            catch { foreach ($ligne in $windows) { $ligne.Etat = 'Échec'; $ligne.Detail = $_.Exception.Message } }
        }

        # --- Vérification des logiciels : winget ne doit plus les proposer ---
        $installes = @($logiciels | Where-Object { $_.Etat -eq 'Installé' })
        if ($installes.Count -gt 0) {
            Set-Statut 'Vérification des logiciels mis à jour…'
            try {
                $verification = @(Get-MisesAJourLogiciels)
                if (@($verification | Where-Object { $_.Etat -eq 'Manuel' }).Count) { throw 'winget indisponible.' }
                $restants = @($verification | ForEach-Object { $_.Cle })
                foreach ($ligne in $installes) {
                    if ($restants -contains $ligne.Cle) { $ligne.Etat = 'Attention'; $ligne.Detail = 'winget propose encore une mise à jour : redémarre le logiciel ou le PC, puis relance la recherche' }
                    else { $ligne.Detail = "✔ Vérifié : version $($ligne.Disponible) installée" }
                }
            }
            catch {
                foreach ($ligne in $installes) { $ligne.Etat = 'Attention'; $ligne.Detail = 'Installation terminée, vérification indisponible.' }
                Write-Journal "Vérification winget impossible : $($_.Exception.Message)" 'ATTENTION'
            }
        }
    }
    catch {
        Write-Journal "Erreur pendant l'installation des mises à jour : $($_.Exception.Message)" 'ERREUR'
        Show-Message "Installation interrompue : $($_.Exception.Message)" 'OK' 'Error' | Out-Null
    }
    finally {
        $ok = @($selection | Where-Object { $_.Etat -eq 'Installé' }).Count
        $ko = @($selection | Where-Object { $_.Etat -in @('Échec', 'Attention') }).Count
        Update-GainMisesAJour
        Set-Occupe $false "Mises à jour : $ok installée(s) et vérifiée(s), $ko à revoir."
        Write-Journal "Installation des mises à jour : $ok OK, $ko à revoir"
    }

    foreach ($ligne in $liens) { Start-Process $ligne.Cle }   # BIOS / pilote graphique : page du fabricant

    if ($redemarrer -and (Show-Message "Des pilotes ou mises à jour Windows demandent un redémarrage.`nRedémarrer maintenant ?" 'YesNo' 'Question') -eq 'Yes') {
        Write-Journal 'Redémarrage demandé après mises à jour'
        Start-Process -FilePath 'shutdown.exe' -ArgumentList '/r /t 5' -WindowStyle Hidden
    }
}

# ---------------------------------------------------------------------
#  5 ter. Logiciels & jeux (onglet « Logiciels & jeux »)
# ---------------------------------------------------------------------
function Update-FiltreLogiciels {
    <# Filtre la liste par texte (nom, description, éditeur) et par catégorie #>
    $filtres = New-Object System.Collections.ArrayList
    $texte = $C.TxtFiltreLogiciels.Text.Trim()
    if ($texte) {
        # Échappement des caractères spéciaux de DataView.RowFilter
        $motif = ($texte -replace '([\[\]\*%])', '[$1]') -replace "'", "''"
        [void]$filtres.Add("(Nom LIKE '*$motif*' OR Description LIKE '*$motif*' OR Editeur LIKE '*$motif*')")
    }
    $categorie = [string]$C.CmbCategorieLogiciels.SelectedItem.Content
    if ($categorie -and $categorie -ne 'Toutes les catégories') { [void]$filtres.Add("Categorie = '$($categorie -replace "'", "''")'") }
    try { $script:TableLogiciels.DefaultView.RowFilter = ($filtres -join ' AND ') } catch { }
}

function Invoke-ListeLogiciels {
    <# Inventaire complet : registre, Steam, Epic, Xbox / Store #>
    Set-Occupe $true 'Inventaire des logiciels et jeux…'
    try {
        $elements = @(Get-LogicielsInstalles)
        Reset-Grille $C.GrilleLogiciels $script:TableLogiciels {
            foreach ($e in $elements) {
                $taille = if ($e.Octets -gt 0) { Format-Taille $e.Octets } else { '' }
                $etat = if ($e.Protege) { 'Protégé' } else { '' }
                [void]$script:TableLogiciels.Rows.Add($e.Nom, $e.Categorie, $e.Description, $e.Editeur, $e.Version, $taille, $e.Date, $e.Source,
                    $etat, $e.Detail, $e.Avertissement, $e.Cle, $e.Dossier, $false, (-not $e.Protege), [int64]$e.Octets)
            }
        }
        $script:TableLogiciels.DefaultView.Sort = 'Octets DESC'   # les plus volumineux en premier
        Update-FiltreLogiciels
        $jeux = @($elements | Where-Object { $_.Categorie -eq 'Jeu' })
        $tailleJeux = [int64](($jeux | Measure-Object -Property Octets -Sum).Sum)
        $C.TxtResumeLogiciels.Text = "$($elements.Count) éléments dont $($jeux.Count) jeux ($(Format-Taille $tailleJeux) connus)"
        Write-Journal "Inventaire logiciels : $($elements.Count) éléments"
    }
    catch {
        Write-Journal "Inventaire logiciels impossible : $($_.Exception.Message)" 'ERREUR'
        Show-Message "Inventaire impossible : $($_.Exception.Message)" 'OK' 'Error' | Out-Null
    }
    finally { Set-Occupe $false 'Inventaire terminé. Sélectionne une ligne pour voir ce que c''est.' }
}

function Get-LogicielSelectionne {
    <# Ligne sélectionnée dans la grille des logiciels (ou $null) #>
    $vue = $C.GrilleLogiciels.SelectedItem
    if ($vue) { return $vue.Row } else { return $null }
}

function Invoke-DesinstallationLogiciels {
    <# Désinstalle les éléments cochés, un par un, avec vérification #>
    $selection = @($script:TableLogiciels.Rows | Where-Object { $_.Selection -and $_.Modifiable -and $_.Etat -ne 'Désinstallé' })
    if ($selection.Count -eq 0) { Show-Message 'Coche au moins un logiciel ou un jeu (les éléments « Protégé » ne peuvent pas être cochés).' | Out-Null; return }

    $liste = ($selection | ForEach-Object {
            $ligne = "  • $($_.Nom)" + $(if ($_.Taille) { " ($($_.Taille))" } else { '' })
            if ($_.Avertissement) { $ligne += "`n      ⚠ $($_.Avertissement)" }
            $ligne
        }) -join "`n"
    $question = "Désinstaller définitivement :`n`n$liste`n`nCertains programmes afficheront leur propre fenêtre de désinstallation : suis-la jusqu'au bout."
    if ((Show-Message $question 'YesNo' 'Warning') -ne 'Yes') { return }

    Set-Occupe $true 'Désinstallation…'
    try {
        if (@($selection | Where-Object { $_.Source -in @('Registre', 'Store', 'Xbox') }).Count -gt 0) {
            Set-Statut 'Création du point de restauration…'
            if (-not (New-PointRestauration)) {
                if ((Show-Message "Le point de restauration n'a pas pu être créé. Continuer la désinstallation ?" 'YesNo' 'Warning') -ne 'Yes') { return }
            }
        }
        $numero = 0
        foreach ($ligne in $selection) {
            $numero++
            $ligne.Etat = 'Désinstallation…'
            Set-Statut "[$numero/$($selection.Count)] Désinstallation de $($ligne.Nom)…"
            $element = [pscustomobject]@{ Nom = $ligne.Nom; Source = $ligne.Source; Cle = $ligne.Cle; Dossier = $ligne.Dossier }
            try {
                $resultat = [string]@(Uninstall-Element -Element $element)[-1]
                if ($resultat -like 'MANUEL:*') { $ligne.Etat = 'Manuel'; $ligne.Detail = $resultat.Substring(7).Trim() }
                else {
                    $ligne.Etat = 'Désinstallé'; $ligne.Detail = $resultat; $ligne.Selection = $false; $ligne.Modifiable = $false

                }
                Write-Journal "Désinstallation $($ligne.Nom) : $resultat"
            }
            catch {
                $ligne.Etat = 'Échec'; $ligne.Detail = $_.Exception.Message
                Write-Journal "Désinstallation $($ligne.Nom) en échec : $($_.Exception.Message)" 'ERREUR'
            }
        }
    }
    finally {
        $ok = @($selection | Where-Object { $_.Etat -eq 'Désinstallé' }).Count
        $manuel = @($selection | Where-Object { $_.Etat -eq 'Manuel' }).Count
        $ko = @($selection | Where-Object { $_.Etat -eq 'Échec' }).Count
        Set-Occupe $false "Désinstallation : $ok vérifiée(s), $manuel à terminer toi-même, $ko échec(s). Détail dans la colonne État et le panneau du bas."
    }
}

# ---------------------------------------------------------------------
#  6. Événements
# ---------------------------------------------------------------------
$C.BtnAnalyser.Add_Click({ Invoke-Analyse })
$C.BtnToutOptimiser.Add_Click({ Invoke-ToutOptimiser })
$C.BtnAppliquer.Add_Click({ Invoke-Application })
$C.BtnAnnuler.Add_Click({ Invoke-Annulation })
$C.BtnJournal.Add_Click({ if (Test-Path $script:FichierJournal) { Start-Process notepad.exe $script:FichierJournal } })
$C.BtnDossierSauvegardes.Add_Click({ Start-Process explorer.exe $script:DossierSauvegardes })
$C.BtnRestaurationSysteme.Add_Click({ Start-Process rstrui.exe })

$C.BtnListerLogiciels.Add_Click({ Invoke-ListeLogiciels })
$C.BtnDesinstaller.Add_Click({ Invoke-DesinstallationLogiciels })
$C.TxtFiltreLogiciels.Add_TextChanged({ Update-FiltreLogiciels })
$C.CmbCategorieLogiciels.Add_SelectionChanged({ Update-FiltreLogiciels })

# Panneau de détails du logiciel sélectionné
$C.GrilleLogiciels.Add_SelectionChanged({
        $ligne = Get-LogicielSelectionne
        $actif = [bool]$ligne
        Update-BoutonsLogiciel
        $C.PanneauLogiciel.Visibility = if ($actif) { 'Visible' } else { 'Collapsed' }
        if (-not $actif) { return }
        $C.TxtNomLogiciel.Text = "$($ligne.Nom)  —  $($ligne.Categorie)"
        $C.TxtDescLogiciel.Text = $ligne.Description
        $C.TxtEnLigneLogiciel.Text = ''
        $infos = @()
        if ($ligne.Etat -eq 'Protégé') { $infos += '🔒 Protégé : nécessaire au système ou au matériel, désinstallation bloquée.' }
        if ($ligne.Avertissement) { $infos += "⚠ $($ligne.Avertissement)" }
        if ($ligne.Detail) { $infos += $ligne.Detail }
        $infos += ('Éditeur : {0}   •   Version : {1}   •   Source : {2}{3}' -f $(if ($ligne.Editeur) { $ligne.Editeur } else { '?' }), $(if ($ligne.Version) { $ligne.Version } else { '?' }), $ligne.Source,
            $(if ($ligne.Date) { "   •   Installé le : $($ligne.Date)" } else { '' }))
        if ($ligne.Dossier) { $infos += "Dossier : $($ligne.Dossier)" }
        $C.TxtInfosLogiciel.Text = $infos -join "`n"
    })
$C.BtnEnSavoirPlus.Add_Click({
        $ligne = Get-LogicielSelectionne
        if (-not $ligne) { return }
        Set-Occupe $true "Recherche d'une description pour $($ligne.Nom)…"
        try {
            $texte = [string]@(Get-DescriptionEnLigne -Element ([pscustomobject]@{ Nom = $ligne.Nom; Source = $ligne.Source; Cle = $ligne.Cle }))[-1]
            $C.TxtEnLigneLogiciel.Text = if ($texte.Trim()) { "📖 $($texte.Trim())" } else { "Aucune description trouvée en ligne : utilise « Rechercher sur le web »." }
        }
        catch { $C.TxtEnLigneLogiciel.Text = "Recherche en ligne impossible : $($_.Exception.Message)" }
        finally { Set-Occupe $false 'Prêt.' }
    })
$C.BtnDossierLogiciel.Add_Click({
        $ligne = Get-LogicielSelectionne
        if ($ligne -and $ligne.Dossier -and (Test-Path -LiteralPath $ligne.Dossier)) { Start-Process explorer.exe "`"$($ligne.Dossier)`"" }
    })
$C.BtnWebLogiciel.Add_Click({
        $ligne = Get-LogicielSelectionne
        if ($ligne) { Start-Process ("https://www.google.com/search?q=" + [uri]::EscapeDataString("$($ligne.Nom) c'est quoi")) }
    })

# Menu latéral -> page affichée
$C.MenuNavigation.Add_SelectionChanged({
        if ($C.MenuNavigation.SelectedIndex -ge 0) { $C.Onglets.SelectedIndex = $C.MenuNavigation.SelectedIndex }
    })
$C.BtnVoirTaches.Add_Click({ $C.Onglets.SelectedIndex = $script:Onglets.Taches })

# Changement de page (menu ou code) : synchronise le menu ; premier affichage de Logiciels : inventaire automatique
$C.Onglets.Add_SelectionChanged({
        param($s, $e)
        if ($e.OriginalSource -ne $C.Onglets) { return }   # ignore les sélections des grilles internes
        if ($C.MenuNavigation.SelectedIndex -ne $C.Onglets.SelectedIndex) { $C.MenuNavigation.SelectedIndex = $C.Onglets.SelectedIndex }
        if ($C.Onglets.SelectedIndex -eq $script:Onglets.Logiciels -and $script:TableLogiciels.Rows.Count -eq 0 -and -not $script:Occupe) {
            $C.Onglets.Dispatcher.BeginInvoke([Action] { Invoke-ListeLogiciels }) | Out-Null
        }
    })

$C.BtnRechercherMaj.Add_Click({ Invoke-RechercheMisesAJour })
$C.BtnInstallerMaj.Add_Click({ Invoke-InstallationMisesAJour })
$C.BtnCocherMaj.Add_Click({
        foreach ($ligne in $script:TableMaj.Rows) { $ligne.Selection = $ligne.Modifiable -and ($ligne.Etat -eq 'Disponible') }
    })

$C.BtnDesactiverDemarrage.Add_Click({ Set-DemarrageSelection $false })
$C.BtnActiverDemarrage.Add_Click({ Set-DemarrageSelection $true })
$C.BtnActualiserDemarrage.Add_Click({
        Set-Occupe $true 'Lecture des programmes au démarrage…'
        try { Update-TableDemarrage } finally { Set-Occupe $false 'Liste des programmes au démarrage actualisée.' }
    })

$C.BtnCocherRecommandes.Add_Click({
        foreach ($ligne in $script:TableTaches.Rows) { $ligne.Selection = $ligne.Modifiable -and ($ligne.Etat -eq 'Recommandé') }
        Update-Compteur
    })
$C.BtnToutDecocher.Add_Click({
        foreach ($ligne in $script:TableTaches.Rows) { $ligne.Selection = $false }
        Update-Compteur
    })

# Met à jour le compteur quand une case est cochée / décochée
$script:TableTaches.Add_ColumnChanged({ param($s, $e) if ($e.Column.ColumnName -eq 'Selection') { Update-Compteur } })

# Panneau d'explication de la tâche sélectionnée
$C.GrilleTaches.Add_SelectionChanged({
        $vue = $C.GrilleTaches.SelectedItem
        $C.PanneauTache.Visibility = if ($vue) { 'Visible' } else { 'Collapsed' }
        if (-not $vue) { return }
        $tache = $script:TachesParId[$vue.Row.Id]
        $C.TxtTitreTache.Text       = $tache.Titre
        $C.TxtDescriptionTache.Text = $tache.Description
        $C.TxtInfosTache.Text       = "$($vue.Row.Detail)`nImpact : $($tache.Impact)   •   Risque : $($tache.Risque)   •   Réversible : $($tache.Reversible)"
        $C.BtnOuvrir.Visibility     = if ($tache.Ouvrir) { 'Visible' } else { 'Collapsed' }
    })
$C.BtnOuvrir.Add_Click({
        $vue = $C.GrilleTaches.SelectedItem
        if (-not $vue) { return }
        $tache = $script:TachesParId[$vue.Row.Id]
        if ($tache.Ouvrir) {
            $donnees = if ($script:Diagnostic) { $script:Diagnostic.Donnees } else { @{ Gpus = @() } }
            try {
                $retour = @(& $tache.Ouvrir $donnees)[-1]
                # Une tâche peut demander l'affichage d'un onglet de l'application
                if ($retour -is [string] -and $retour -like 'onglet:*') {
                    $nomOnglet = $retour.Substring(7)
                    if ($script:Onglets.ContainsKey($nomOnglet)) { $C.Onglets.SelectedIndex = $script:Onglets[$nomOnglet] }
                }
            }
            catch { Show-Message "Impossible d'ouvrir : $($_.Exception.Message)" 'OK' 'Warning' | Out-Null }
        }
    })

# Filet de sécurité : toute erreur non prévue dans un gestionnaire d'événement
# fermerait l'application (ShowDialog la laisse remonter). On l'affiche et on continue.
$script:Fenetre.Dispatcher.Add_UnhandledException({
        param($s, $e)
        $e.Handled = $true
        Write-Journal "Erreur imprévue : $($e.Exception.Message)" 'ERREUR'
        try { Set-Occupe $false 'Erreur : voir le journal (page Historique).' } catch { }
        Show-Message "Une erreur imprévue est survenue :`n$($e.Exception.Message)`n`nLe logiciel reste ouvert ; le détail est dans le journal." 'OK' 'Error' | Out-Null
    })

# Empêche de fermer la fenêtre pendant une opération
$script:Fenetre.Add_Closing({
        param($s, $e)
        if ($script:Occupe) {
            $e.Cancel = $true
            Show-Message 'Une opération est en cours, patiente jusqu''à la fin.' 'OK' 'Warning' | Out-Null
        }
    })

# ---------------------------------------------------------------------
#  7. Lancement
# ---------------------------------------------------------------------
Initialize-TableTaches
Update-TableDemarrage
Update-TableHistorique
Update-EtatsVides

# Analyse en lecture seule dès que la fenêtre est affichée : le tableau de bord se remplit tout seul
# (priorité passée en PREMIER argument : sinon PowerShell la transmet comme paramètre de l'Action -> erreur « Nombre de paramètres incorrects »)
$script:Fenetre.Add_ContentRendered({ $script:Fenetre.Dispatcher.BeginInvoke([Windows.Threading.DispatcherPriority]::Background, [Action] { Test-SecuriteDemarrage; Invoke-Analyse }) | Out-Null })

try {
    [void]$script:Fenetre.ShowDialog()
}
catch {
    Write-Journal "Erreur fatale : $($_.Exception.Message)" 'ERREUR'
    [System.Windows.MessageBox]::Show("Erreur : $($_.Exception.Message)", 'Optimeo') | Out-Null
}
Write-Journal '===== Fermeture ====='

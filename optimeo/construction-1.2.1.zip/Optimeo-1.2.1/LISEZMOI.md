# Optimeo — Ton PC en pleine forme

**Version 1.2.1** — le numéro de version est incrémenté à chaque modification (voir « Versions » en bas).

Logiciel d'optimisation Windows 10 / 11. Un bouton **⚡ Tout optimiser** analyse le PC, applique
automatiquement les corrections sélectionnées, puis **vérifie** que chacune a vraiment corrigé le problème.
Optimeo enregistre les réglages réversibles avant modification. Les nettoyages de fichiers sont définitifs.

## Installer

Double-clic sur `dist\Optimeo-Installation-1.2.1.exe` : installe Optimeo dans `C:\Program Files\Optimeo`,
ajoute un raccourci dans le menu Démarrer (et sur le bureau en option) et l'inscrit dans « Applications installées »
pour pouvoir le désinstaller.

> L'installateur n'est pas signé numériquement (certificat payant) : Windows SmartScreen peut afficher
> « Windows a protégé votre ordinateur ». Clique sur **Informations complémentaires** puis **Exécuter quand même**.

## Lancer

Menu Démarrer > **Optimeo** (ou, sans installation, double-clic sur `Lancer-Optimiseur.bat`) :

1. Lance Optimeo
2. Accepte la fenêtre « Contrôle de compte d'utilisateur » (droits administrateur)
3. Le **Tableau de bord** s'affiche et analyse le PC tout seul (note de santé, gains possibles, matériel, recommandations).
4. Clique **Tout optimiser** et confirme. Le détail avant / après s'affiche dans la page **Rapport**.
   (Pour choisir toi-même : **Analyser**, coche des tâches, puis **Appliquer la sélection**.)

## Pages (menu à gauche)

Compteurs du menu : Tâches = corrections et actions à faire, Mises à jour = mises à jour disponibles, Démarrage = programmes actifs au démarrage.

| Page | Rôle |
|---|---|
| Tableau de bord | Note de santé sur 100, gains possibles (espace récupérable, corrections automatiques, mises à jour), processeur / mémoire / carte graphique / disque système et 5 recommandations principales |
| Tâches | Optimisations proposées. ⚡ = incluse dans « Tout optimiser ». Pastilles : orange = recommandé, bleu = optionnel ou action manuelle (BIOS, matériel), vert = déjà OK |
| Rapport | Pour chaque correction : état avant, état après la nouvelle analyse, résultat (✔ vérifié / ⚠ partiel / ✖ échec) et rappel des actions manuelles |
| Mises à jour | Recherche et installe les mises à jour des logiciels (winget), des pilotes et de Windows (Windows Update). Chaque installation est vérifiée. BIOS et pilote graphique : version affichée et page du fabricant |
| Logiciels & jeux | Tous les logiciels et jeux installés (registre, Steam, Epic, Xbox / Game Pass, Store), classés par taille, avec « C'est quoi ? », recherche, filtre par catégorie, description en ligne et désinstallation vérifiée. Les composants indispensables (pilotes, Visual C++, .NET…) sont protégés |
| Diagnostic | État du PC en lecture seule : Windows, CPU, RAM, GPU, disques, sécurité, alimentation |
| Démarrage | Active / désactive les programmes lancés au démarrage : registre, dossiers Démarrage, applis du Store, tâches planifiées. Les entrées sensibles (audio, sécurité, ventilateurs…) sont signalées et demandent confirmation |
| Historique | Annule une optimisation appliquée, ouvre la Restauration du système et le journal |

## Sécurité

- **Point de restauration** Windows demandé avant chaque application. En cas d’échec, tu choisis de continuer ou d’annuler.
- **Sauvegarde JSON** de chaque valeur de registre, service, plan d'alimentation ou DNS modifié :
  `C:\ProgramData\Optimeo\sauvegardes` — dossier en écriture réservée aux administrateurs, car
  l'annulation réécrit ces valeurs avec les droits administrateur (les sauvegardes des versions
  précédentes dans le profil utilisateur sont conservées sur disque et ne sont plus importées automatiquement)
- Si les droits de l’ancien dossier sont insuffisants, les nouvelles sauvegardes et le journal sont créés dans `%ProgramData%\Optimeo-Historique`. Les anciens fichiers restent disponibles sur disque.
- **Journal** de toutes les opérations : `C:\ProgramData\Optimeo\journal.log` (archivé en `journal.old.log` au-delà de 1 Mo)
- Le rapport indique les erreurs de vérification. Une erreur de tâche affiche ✖ dans le rapport. Une annulation incomplète reste dans l'historique pour réessayer.
- Non annulables (indiqué dans chaque tâche) : nettoyages de fichiers, désinstallation d'applis (réinstallables via le Store).

## Corrections automatiques (⚡)

- **Nettoyage** : corbeille (uniquement ce qui a été jeté il y a plus de 30 jours), fichiers temporaires, cache Windows Update, cache de l'Optimisation de distribution, cache des navigateurs (s'ils sont fermés), rapports d'erreurs.
- **Démarrage** : lanceurs de jeux et applis inutiles à l'allumage (Steam, Epic, EA, Discord, Teams…).
- **Jeux** : fréquence maximale de l'écran, optimisations des jeux en fenêtre, Mode Jeu, enregistrement en arrière-plan coupé, planification GPU matérielle.
- **Système** : TRIM, fichier d'échange automatique.
- **Confidentialité / réseau** : télémétrie, publicités, partage des mises à jour limité au réseau local.

Impossibles depuis Windows (signalés « À faire toi-même ») : profil EXPO/XMP, ventilateurs et pompe, Resizable BAR (BIOS), pilote graphique.

## Ce que le logiciel ne fait volontairement pas

Ces pratiques courantes des « optimiseurs » n'apportent rien ou cassent Windows :
nettoyage du registre, « libération » de RAM, tweaks TCP/Nagle « anti-lag », désactivation de Windows Defender
ou de Windows Update, désactivation massive de services, suppression du fichier d'échange.

## Structure du projet

```
OptimiseurPC/
├─ Lancer-Optimiseur.bat     Lancement sans installation (double-clic)
├─ OptimiseurPC.ps1          Point d'entrée : droits admin, fenêtre, Tout optimiser, rapport
├─ interface/
│  ├─ Fenetre.xaml           Interface WPF (thème sombre, menu latéral, tableau de bord)
│  ├─ logo.ico / logo.png    Logo d'Optimeo (icône, fenêtre)
│  └─ logo-1024.png          Logo en haute résolution (source)
└─ modules/
   ├─ Utilitaires.ps1        Journal, registre/services avec sauvegarde, annulation, point de restauration
   ├─ Diagnostic.ps1         Collecte des informations système (lecture seule)
   ├─ Taches.ps1             Catalogue des optimisations (vérifier / appliquer / ouvrir, ⚡ Auto)
   ├─ Demarrage.ps1          Programmes au démarrage
   ├─ Ecran.ps1              Fréquence de rafraîchissement des écrans (API Windows)
   ├─ MisesAJour.ps1         Mises à jour : winget, Windows Update, BIOS / pilote graphique
   └─ Logiciels.ps1          Inventaire logiciels & jeux, dictionnaire « C'est quoi ? », désinstallation
installateur/
├─ Lanceur/Lanceur.cs        Optimeo.exe : lance l'interface sans console, en administrateur
├─ Lanceur/app.manifest      Droits administrateur, Windows 10/11, haute résolution
├─ Optimeo.nsi               Script de l'installateur (NSIS)
├─ assistant.bmp, entete.bmp Images de l'installateur
└─ construire.ps1            Fabrique Optimeo.exe puis l'installateur
dist/
└─ Optimeo-Installation-1.2.1.exe   Installateur à distribuer
```

### Ajouter une optimisation

Ajouter une table dans `$script:CatalogueTaches` (`modules/Taches.ps1`) avec `Id`, `Categorie`, `Titre`,
`Description`, `Impact`, `Risque`, `Reversible`, `Manuel`, `Verifier`, `Appliquer` (et `Ouvrir` si manuel),
`Auto = $true` pour l'inclure dans « Tout optimiser », `Redemarrage = $true` si un redémarrage est nécessaire.
`Verifier` doit renvoyer `OK` une fois le problème corrigé : c'est ce contrôle qui produit « ✔ vérifié ».
Utiliser `Set-RegValeur`, `Set-ServiceDemarrage`, `Invoke-Commande` (programmes externes) et `Add-ActionAnnulable`
(avant de modifier le système) pour que la modification soit vérifiée et annulable.
Les opérations longues passent par `Invoke-EnArrierePlan` pour garder la fenêtre réactive.

### Note de santé

Calculée par `Get-ScoreSante` (`OptimiseurPC.ps1`) : 100 moins 6 points par tâche « Recommandé », 8 par action « Manuel »,
1 par « Optionnel », 12 par ligne de diagnostic « Problème » et 4 par « Attention ». 85 et plus = excellente, 65 et plus = correcte.

## Conseil de sécurité

Le logiciel s'exécute en administrateur : n'importe quel programme capable de modifier ses fichiers
pourrait donc faire exécuter son code en administrateur. L'installateur le place pour cette raison dans
`C:\Program Files\Optimeo`, dossier que seuls les administrateurs peuvent modifier, et le choix du dossier
n'est pas proposé. Au lancement, Optimeo prévient si son dossier est modifiable par un compte sans droits
(cas d'un lancement depuis le Bureau avec `Lancer-Optimiseur.bat`) et si la session Windows appartient à un
autre compte que celui qui a accepté l'élévation.

## Compatibilité

Windows 10 / 11 64 bits, Windows PowerShell 5.1 (inclus dans Windows). Le `.bat` fonctionne sans installation,
mais l'installateur est recommandé (dossier protégé).
Les réglages « utilisateur » s'appliquent au compte qui accepte l'élévation : lance le logiciel depuis ton propre compte administrateur.

## Versions

À chaque modification : incrémenter `$script:Version` (`OptimiseurPC.ps1`), `VERSION` (`installateur/Optimeo.nsi`),
`AssemblyVersion` (`installateur/Lanceur/Lanceur.cs`) et le titre de ce fichier, puis reconstruire l'installateur.

| Version | Changements |
|---|---|
| 1.2.1 | Sauvegarde des réglages avant écriture, vérification des droits de l’historique, restauration du partage Windows Update, résultats de mises à jour partiels signalés, nettoyage protégé contre les liens, désinstallations Epic et par utilisateur confiées à leur interface. |
| 1.2.0 | Corrections issues de l'audit : winget et « En savoir plus » réparés dans la version installée (lecture de la sortie sans console), désinstalleurs sans argument, sauvegardes déplacées dans `C:\ProgramData\Optimeo` protégé, contrôles du dossier d'exécution et du compte, désinstallation Epic durcie (jonctions, `.egstore`), TRIM et fichier d'échange plus sûrs à l'annulation, rapports d'erreurs de plus de 30 jours seulement, détection winget en échec, doublons Steam/Epic, protections de pilotes, délais maximaux sur les opérations longues, filet contre les erreurs imprévues, installateur (64 bits, dossier imposé, détection d'Optimeo ouvert) |
| 1.1.1 | Correction : erreur « ShowDialog… Nombre de paramètres incorrects » au lancement (analyse automatique du tableau de bord) |
| 1.1.0 | Nouvelle interface : menu latéral avec icônes et compteurs, tableau de bord (note de santé, gains possibles, matériel, recommandations) avec analyse au lancement, pastilles d'état colorées, icônes de catégorie, listes plus lisibles, champs de recherche et listes déroulantes sombres, messages pour les pages vides |
| 1.0.0 | Première version : Tout optimiser avec vérification, rapport, mises à jour, logiciels & jeux, installateur |

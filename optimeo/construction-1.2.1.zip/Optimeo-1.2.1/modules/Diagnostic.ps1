﻿# =====================================================================
#  Diagnostic.ps1
#  ---------------------------------------------------------------------
#  Collecte les informations du PC (lecture seule, aucune modification) :
#  système, processeur, mémoire, carte(s) graphique(s), disques, sécurité,
#  alimentation, démarrage.
#
#  Get-DiagnosticSysteme renvoie un objet avec :
#    .Donnees : faits bruts utilisés par les tâches (Taches.ps1)
#    .Lignes  : lignes affichées dans l'onglet « Diagnostic »
#  L'avancement est affiché via Write-Progression (Utilitaires.ps1).
# =====================================================================

# Âge (en jours) à partir duquel un pilote graphique est jugé ancien.
# Valeur unique utilisée par le diagnostic ET par la tâche MAN_PILOTE_GPU.
$script:SeuilAgePiloteJours = 180

function Get-DiagnosticSysteme {

    $d      = [ordered]@{}
    $lignes = New-Object System.Collections.ArrayList

    # Ajoute une ligne à l'onglet Diagnostic (État : OK / Info / Attention / Problème)
    function Add-Ligne([string]$Categorie, [string]$Element, [string]$Valeur, [string]$Etat = 'Info') {
        [void]$lignes.Add([pscustomobject]@{ Categorie = $Categorie; Element = $Element; Valeur = $Valeur; Etat = $Etat })
    }

    # -----------------------------------------------------------------
    #  Système
    # -----------------------------------------------------------------
    Write-Progression 'Diagnostic : système…'
    $os = Get-CimInstance Win32_OperatingSystem
    $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $d.Build       = [int]$os.BuildNumber
    $d.EstWin11    = $d.Build -ge 22000
    $d.NomSysteme  = '{0} {1}' -f ($os.Caption -replace '^Microsoft\s+', ''), $cv.DisplayVersion
    $d.EstPortable = [bool](Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
    $d.JoursAllume = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalDays, 1)
    $d.RedemarrageEnAttente = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or
                              (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')

    Add-Ligne 'Système' 'Windows' ('{0} (build {1}.{2})' -f $d.NomSysteme, $d.Build, $cv.UBR) 'Info'
    Add-Ligne 'Système' 'Type de PC' $(if ($d.EstPortable) { 'Portable' } else { 'Fixe' }) 'Info'
    Add-Ligne 'Système' 'Allumé depuis' ('{0} jour(s)' -f $d.JoursAllume) $(if ($d.JoursAllume -gt 7) { 'Attention' } else { 'OK' })
    if ($d.RedemarrageEnAttente) { Add-Ligne 'Système' 'Mise à jour' 'Redémarrage en attente' 'Attention' }

    # -----------------------------------------------------------------
    #  Processeur
    # -----------------------------------------------------------------
    Write-Progression 'Diagnostic : processeur…'
    $cpu = @(Get-CimInstance Win32_Processor)[0]
    $d.CpuNom = ($cpu.Name -replace '\s+', ' ').Trim()
    $d.CpuAmd = $d.CpuNom -match 'AMD'
    $d.CpuCoeurs  = [int]$cpu.NumberOfCores              # affichés sur le tableau de bord
    $d.CpuThreads = [int]$cpu.NumberOfLogicalProcessors
    Add-Ligne 'Processeur' 'Modèle' $d.CpuNom 'Info'
    Add-Ligne 'Processeur' 'Cœurs / threads' ('{0} / {1}' -f $cpu.NumberOfCores, $cpu.NumberOfLogicalProcessors) 'Info'
    Add-Ligne 'Processeur' 'Charge actuelle' ('{0} %' -f $cpu.LoadPercentage) $(if ($cpu.LoadPercentage -gt 80) { 'Attention' } else { 'OK' })

    # -----------------------------------------------------------------
    #  Mémoire vive
    # -----------------------------------------------------------------
    Write-Progression 'Diagnostic : mémoire…'
    $d.RamGo = [math]::Round($os.TotalVisibleMemorySize / 1MB)
    $ramUtilisee = [math]::Round((1 - $os.FreePhysicalMemory / $os.TotalVisibleMemorySize) * 100)
    Add-Ligne 'Mémoire' 'Quantité' ('{0} Go' -f $d.RamGo) $(if ($d.RamGo -lt 8) { 'Attention' } else { 'OK' })
    Add-Ligne 'Mémoire' 'Utilisation' ('{0} %' -f $ramUtilisee) $(if ($ramUtilisee -gt 85) { 'Attention' } else { 'OK' })

    $barrettes = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)
    $d.XmpSuspect   = $false  # vitesse de base certaine : profil XMP/EXPO très probablement inactif
    $d.XmpAVerifier = $false  # vitesse intermédiaire : profil peut-être inactif selon le kit
    if ($barrettes.Count -gt 0) {
        $typeRam = switch ([int]$barrettes[0].SMBIOSMemoryType) { 26 { 'DDR4' } 34 { 'DDR5' } 24 { 'DDR3' } default { 'Inconnu' } }
        # Toutes les barrettes : on retient la vitesse configurée la plus basse (c'est elle qui s'applique)
        $vitesse      = [int]($barrettes | Measure-Object -Property ConfiguredClockSpeed -Minimum).Minimum
        $vitesseMax   = [int]($barrettes | Measure-Object -Property Speed -Maximum).Maximum
        $d.RamType    = $typeRam
        $d.RamVitesse = $vitesse
        # Heuristique (PC fixe uniquement : pas de profil réglable sur portable)
        if (-not $d.EstPortable) {
            if (($typeRam -eq 'DDR4' -and $vitesse -le 2666) -or ($typeRam -eq 'DDR5' -and $vitesse -le 4800) -or ($vitesseMax -gt $vitesse)) {
                $d.XmpSuspect = $true
            }
            elseif (($typeRam -eq 'DDR4' -and $vitesse -lt 3200) -or ($typeRam -eq 'DDR5' -and $vitesse -lt 6000)) {
                $d.XmpAVerifier = $true
            }
        }
        # Ex. « 2 × 16 Go » ou « 16 + 8 Go » si les barrettes diffèrent
        $capacites = @($barrettes | ForEach-Object { [math]::Round($_.Capacity / 1GB) })
        $texteCapacite = if (@($capacites | Select-Object -Unique).Count -eq 1) { '{0} × {1} Go' -f $capacites.Count, $capacites[0] } else { ($capacites -join ' + ') + ' Go' }
        $etatRam = if ($d.XmpSuspect) { 'Attention' } elseif ($d.XmpAVerifier) { 'Info' } else { 'OK' }
        Add-Ligne 'Mémoire' 'Barrettes' ('{0} {1} @ {2} MHz' -f $texteCapacite, $typeRam, $vitesse) $etatRam
    }

    # -----------------------------------------------------------------
    #  Carte(s) graphique(s)
    # -----------------------------------------------------------------
    Write-Progression 'Diagnostic : carte graphique…'
    $d.Gpus = New-Object System.Collections.ArrayList
    $controleurs = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch 'Basic|Remote|Virtual|Parsec|Mirror' }
    foreach ($g in $controleurs) {
        $age = if ($g.DriverDate) { [int]((Get-Date) - $g.DriverDate).TotalDays } else { $null }
        $marque = if ($g.Name -match 'NVIDIA') { 'NVIDIA' } elseif ($g.Name -match 'AMD|Radeon') { 'AMD' } elseif ($g.Name -match 'Intel') { 'Intel' } else { 'Autre' }
        $gpu = [pscustomobject]@{
            Nom          = $g.Name
            Marque       = $marque
            Version      = "$($g.DriverVersion)"   # version du pilote (tableau de bord)
            AgePilote    = $age
            PiloteAncien = ($marque -ne 'Autre') -and ($age -gt $script:SeuilAgePiloteJours)
        }
        [void]$d.Gpus.Add($gpu)
        Add-Ligne 'Graphique' $gpu.Nom ('Pilote {0} — {1}' -f $g.DriverVersion, $(if ($null -ne $age) { "il y a $age jours" } else { 'date inconnue' })) $(if ($gpu.PiloteAncien) { 'Attention' } else { 'OK' })
    }

    # Écrans : fréquence réelle et maximale (API Windows, voir Ecran.ps1)
    $d.Ecrans = @()
    try { $d.Ecrans = @(Get-EtatEcrans) } catch { Write-Journal "Lecture des écrans impossible : $($_.Exception.Message)" 'ATTENTION' }
    foreach ($e in $d.Ecrans) {
        $etatEcran = if ($e.Actuelle -lt $e.Max) { 'Attention' } else { 'OK' }
        Add-Ligne 'Graphique' "Écran $($e.Numero) ($($e.Carte))" ('{0}×{1} à {2} Hz (maximum possible : {3} Hz)' -f $e.Largeur, $e.Hauteur, $e.Actuelle, $e.Max) $etatEcran
    }

    # -----------------------------------------------------------------
    #  Disques
    # -----------------------------------------------------------------
    Write-Progression 'Diagnostic : disques…'
    $d.DisquesPhysiques = @()
    try {
        $d.DisquesPhysiques = @(Get-PhysicalDisk -ErrorAction Stop | Select-Object FriendlyName,
            @{ n = 'Type'; e = { "$($_.MediaType)" } }, @{ n = 'Bus'; e = { "$($_.BusType)" } },
            @{ n = 'Sante'; e = { "$($_.HealthStatus)" } }, Size)
    }
    catch { }
    foreach ($pd in $d.DisquesPhysiques) {
        $etat = if ($pd.Sante -eq 'Healthy') { 'OK' } elseif ($pd.Sante -eq 'Warning') { 'Attention' } else { 'Problème' }
        Add-Ligne 'Disques' $pd.FriendlyName ('{0} {1} — {2:N0} Go — santé : {3}' -f $pd.Type, $pd.Bus, ($pd.Size / 1GB), $pd.Sante) $etat
    }
    $d.DisquesEnDanger = @($d.DisquesPhysiques | Where-Object { $_.Sante -and $_.Sante -ne 'Healthy' })
    $d.ASsd = [bool]($d.DisquesPhysiques | Where-Object { $_.Type -eq 'SSD' })

    $d.Volumes = New-Object System.Collections.ArrayList
    foreach ($v in (Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')) {
        if (-not $v.Size) { continue }
        $pct = [math]::Round($v.FreeSpace / $v.Size * 100)
        [void]$d.Volumes.Add([pscustomobject]@{ Lettre = $v.DeviceID.TrimEnd(':'); LibrePct = $pct; LibreGo = [math]::Round($v.FreeSpace / 1GB); TotalGo = [math]::Round($v.Size / 1GB) })
        Add-Ligne 'Disques' "Lecteur $($v.DeviceID)" ('{0} Go libres sur {1:N0} Go ({2} %)' -f [math]::Round($v.FreeSpace / 1GB), ($v.Size / 1GB), $pct) $(if ($pct -lt 10) { 'Problème' } elseif ($pct -lt 15) { 'Attention' } else { 'OK' })
    }

    $sortieTrim = (& fsutil.exe behavior query DisableDeleteNotify 2>$null) -join "`n"
    $d.TrimDesactive = $sortieTrim -match 'NTFS DisableDeleteNotify\s*=\s*1'
    if ($d.ASsd) { Add-Ligne 'Disques' 'TRIM (SSD)' $(if ($d.TrimDesactive) { 'Désactivé' } else { 'Activé' }) $(if ($d.TrimDesactive) { 'Problème' } else { 'OK' }) }

    $d.FichierEchangeAbsent = -not (Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue)
    Add-Ligne 'Disques' "Fichier d'échange" $(if ($d.FichierEchangeAbsent) { 'Aucun' } else { 'Présent' }) $(if ($d.FichierEchangeAbsent) { 'Attention' } else { 'OK' })

    # -----------------------------------------------------------------
    #  Alimentation
    # -----------------------------------------------------------------
    Write-Progression 'Diagnostic : alimentation…'
    $sortiePlan = (& powercfg.exe /getactivescheme) -join ' '
    $d.PlanActifGuid = if ($sortiePlan -match "($script:RegexGuid)") { $Matches[1].ToLower() } else { '' }
    $d.PlanActifNom  = if ($sortiePlan -match '\(([^)]+)\)\s*$') { $Matches[1] } else { 'Inconnu' }
    Add-Ligne 'Alimentation' 'Mode actif' $d.PlanActifNom 'Info'

    # -----------------------------------------------------------------
    #  Sécurité
    # -----------------------------------------------------------------
    Write-Progression 'Diagnostic : sécurité…'
    try {
        $antivirus = @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop)
        foreach ($av in $antivirus) {
            # 2e octet de productState : 0x10/0x11 = protection active
            $actif = ('{0:X6}' -f [int]$av.productState).Substring(2, 2) -in @('10', '11')
            Add-Ligne 'Sécurité' 'Antivirus' ('{0} — {1}' -f $av.displayName, $(if ($actif) { 'actif' } else { 'inactif' })) $(if ($actif) { 'OK' } else { 'Info' })
        }
        if ($antivirus.Count -eq 0) { Add-Ligne 'Sécurité' 'Antivirus' 'Aucun détecté' 'Problème' }
    }
    catch { }

    $d.HvciActif = $false
    try {
        $dg = Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction Stop
        $d.HvciActif = @($dg.SecurityServicesRunning) -contains 2
        Add-Ligne 'Sécurité' 'Intégrité de la mémoire (HVCI)' $(if ($d.HvciActif) { 'Activée' } else { 'Désactivée' }) 'Info'
    }
    catch { }

    # -----------------------------------------------------------------
    #  Démarrage
    # -----------------------------------------------------------------
    Write-Progression 'Diagnostic : programmes au démarrage…'
    $d.ProgrammesDemarrage = @(Get-ProgrammesDemarrage)
    $d.NbDemarrageActifs   = @($d.ProgrammesDemarrage | Where-Object { $_.Actif }).Count
    Add-Ligne 'Démarrage' 'Programmes actifs' "$($d.NbDemarrageActifs)" $(if ($d.NbDemarrageActifs -gt 10) { 'Attention' } else { 'OK' })

    return [pscustomobject]@{ Donnees = $d; Lignes = $lignes }
}

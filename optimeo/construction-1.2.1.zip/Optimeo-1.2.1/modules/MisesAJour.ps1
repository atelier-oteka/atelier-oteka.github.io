﻿# =====================================================================
#  MisesAJour.ps1
#  ---------------------------------------------------------------------
#  Recherche et installation des mises à jour :
#    - logiciels : winget (gestionnaire de paquets officiel de Windows)
#    - pilotes et Windows : Windows Update (API COM Microsoft.Update)
#    - informations : BIOS et pilote graphique (mise à jour manuelle,
#      trop risquée ou non disponible de façon fiable en automatique)
#  Les recherches et installations tournent en arrière-plan
#  (Invoke-EnArrierePlan) pour garder la fenêtre réactive.
#
#  Chaque mise à jour est un objet :
#    Type, Nom, Actuelle, Disponible, Source, Cle, Selection (par défaut),
#    Modifiable, Detail
# =====================================================================

function New-MiseAJour {
    <# Objet uniforme pour toutes les sources #>
    param([string]$Type, [string]$Nom, [string]$Actuelle = '', [string]$Disponible = '', [string]$Source = '',
        [string]$Cle = '', [bool]$Selection = $true, [bool]$Modifiable = $true, [string]$Detail = '', [string]$Etat = 'Disponible')
    [pscustomobject]@{
        Type = $Type; Nom = $Nom; Actuelle = $Actuelle; Disponible = $Disponible; Source = $Source
        Cle = $Cle; Selection = $Selection; Modifiable = $Modifiable; Detail = $Detail; Etat = $Etat
    }
}

# ---------------------------------------------------------------------
#  Logiciels (winget)
# ---------------------------------------------------------------------
function Test-Winget { return [bool](Get-Command winget -ErrorAction SilentlyContinue) }

function ConvertFrom-TableauWinget {
    <# Transforme le tableau texte de « winget upgrade » en objets.
       Les colonnes sont repérées par la position des titres (ligne au-dessus
       des tirets), ce qui fonctionne quelle que soit la langue de winget. #>
    param([string[]]$Lignes)
    $resultats = New-Object System.Collections.ArrayList
    for ($i = 1; $i -lt $Lignes.Count; $i++) {
        if ($Lignes[$i] -notmatch '^-{10,}') { continue }
        $entete = $Lignes[$i - 1]
        $debuts = @([regex]::Matches($entete, '\S+') | ForEach-Object { $_.Index })
        if ($debuts.Count -lt 4) { continue }
        for ($j = $i + 1; $j -lt $Lignes.Count; $j++) {
            $ligne = $Lignes[$j]
            if ([string]::IsNullOrWhiteSpace($ligne) -or $ligne -match '^\d+ ' -or $ligne.Length -lt $debuts[3]) { break }
            $cols = for ($c = 0; $c -lt $debuts.Count; $c++) {
                $debut = $debuts[$c]
                $fin = if ($c + 1 -lt $debuts.Count) { $debuts[$c + 1] } else { $ligne.Length }
                if ($debut -ge $ligne.Length) { '' } else { $ligne.Substring($debut, [math]::Min($fin, $ligne.Length) - $debut).Trim() }
            }
            $cols = @($cols)
            if ($cols.Count -lt 4 -or -not $cols[1]) { continue }
            [void]$resultats.Add([pscustomobject]@{ Nom = $cols[0]; Id = $cols[1]; Version = $cols[2]; Disponible = $cols[3]; Source = $(if ($cols.Count -gt 4) { $cols[4] } else { '' }) })
        }
    }
    return $resultats
}

function Get-MisesAJourLogiciels {
    <# Liste les logiciels ayant une mise à jour (winget) #>
    if (-not (Test-Winget)) {
        return @(New-MiseAJour -Type 'Logiciel' -Nom 'winget (App Installer)' -Selection $false -Modifiable $false -Etat 'Manuel' `
                -Detail "winget est absent : installe « App Installer » depuis le Microsoft Store pour les mises à jour automatiques des logiciels")
    }
    # Sortie lue en UTF-8 via Invoke-ProgrammeTexte (fonctionne aussi dans
    # Optimeo.exe, qui n'a pas de console) ; 5 minutes au maximum.
    $retour = Invoke-ProgrammeTexte -Programme 'winget' -Arguments 'upgrade --accept-source-agreements --disable-interactivity' -DelaiSecondes 300
    $paquets = @(ConvertFrom-TableauWinget @($retour.Lignes))
    if ($paquets.Count -eq 0) {
        # Pas de tableau : soit vraiment rien à mettre à jour, soit winget a échoué
        $texte = ($retour.Lignes -join ' ')
        $aucune = $texte -match '(?i)aucun[e]? (mise à niveau|package|application)|no (installed package|applicable)|Tout est à jour'
        if ($retour.Code -ne 0 -or -not $aucune) {
            throw ("winget n'a pas répondu correctement (code 0x{0:X8}) : {1}" -f $retour.Code, ((($retour.Lignes | Where-Object { $_.Trim() }) | Select-Object -Last 3) -join ' / '))
        }
    }
    $liste = foreach ($p in $paquets) {
        $tronque = $p.Id -match '…'
        New-MiseAJour -Type 'Logiciel' -Nom $p.Nom -Actuelle $p.Version -Disponible $p.Disponible -Source "winget ($($p.Source))" `
            -Cle $p.Id -Selection (-not $tronque) -Modifiable (-not $tronque) `
            -Detail $(if ($tronque) { 'Identifiant tronqué par winget : mettre à jour depuis le logiciel lui-même' } else { '' })
    }
    return @($liste)
}

function Install-MiseAJourLogiciel {
    <# Met à jour un logiciel avec winget (installation silencieuse). Erreur si échec. #>
    param([Parameter(Mandatory)][string]$Id)
    $arguments = "upgrade --id `"$Id`" --exact --silent --accept-package-agreements --accept-source-agreements --disable-interactivity"
    $code = Start-ProcessAvecInterface 'winget' $arguments -DelaiSecondes 1800
    Write-Journal "winget upgrade $Id -> code $code"
    if ($code -ne 0) { throw ('winget a échoué (code 0x{0:X8}) : le logiciel est peut-être ouvert, ferme-le puis réessaie' -f $code) }
}

# ---------------------------------------------------------------------
#  Pilotes et Windows (Windows Update)
# ---------------------------------------------------------------------
function Get-MisesAJourWindows {
    <# Recherche via Windows Update les pilotes et mises à jour non installés (1 à 3 min) #>
    $trouvees = Invoke-EnArrierePlan -DelaiSecondes 600 -Script {
        $session = New-Object -ComObject 'Microsoft.Update.Session'
        $recherche = $session.CreateUpdateSearcher()
        $resultat = $recherche.Search("IsInstalled=0 and IsHidden=0")
        foreach ($u in $resultat.Updates) {
            [pscustomobject]@{
                Titre       = $u.Title
                EstPilote   = ($u.Type -eq 2)
                Classe      = [string]$u.DriverClass
                Version     = if ($u.Type -eq 2 -and $u.DriverVerDate) { ([datetime]$u.DriverVerDate).ToString('dd/MM/yyyy') } else { '' }
                Taille      = [int64]$u.MaxDownloadSize
                Id          = $u.Identity.UpdateID
                Recommandee = [bool]$u.AutoSelectOnWebSites
            }
        }
    }
    $liste = foreach ($u in @($trouvees)) {
        $taille = if ($u.Taille -gt 0) { Format-Taille $u.Taille } else { '' }
        if ($u.EstPilote) {
            # Pilote graphique : celui du fabricant (AMD Adrenalin, NVIDIA App) est plus récent et complet
            # (Windows Update ne renseigne pas toujours la classe : on regarde aussi le titre)
            $graphique = ($u.Classe -match 'Display') -or ($u.Titre -match 'Display|Graphics|Radeon|GeForce|NVIDIA|Arc\b')
            New-MiseAJour -Type 'Pilote' -Nom $u.Titre -Disponible $u.Version -Source "Windows Update $taille" -Cle $u.Id `
                -Selection (-not $graphique) `
                -Detail $(if ($graphique) { "Pilote graphique : préfère celui du fabricant (AMD Adrenalin / NVIDIA App), non coché par défaut" } else { '' })
        }
        else {
            New-MiseAJour -Type 'Windows' -Nom $u.Titre -Source "Windows Update $taille" -Cle $u.Id -Selection $u.Recommandee `
                -Detail $(if (-not $u.Recommandee) { 'Mise à jour facultative' } else { '' })
        }
    }
    return @($liste)
}

function Install-MisesAJourWindows {
    <# Télécharge et installe un lot de mises à jour Windows Update (par identifiant).
       Renvoie un objet par mise à jour { Id ; Reussi ; Code } et RedemarrageRequis. #>
    param([Parameter(Mandatory)][string[]]$Ids)
    $retour = Invoke-EnArrierePlan -DelaiSecondes 3600 -Arguments @(, $Ids) -Script {
        param($ids)
        $session = New-Object -ComObject 'Microsoft.Update.Session'
        $recherche = $session.CreateUpdateSearcher()
        $collection = New-Object -ComObject 'Microsoft.Update.UpdateColl'
        # UNE seule recherche pour tout le lot (une recherche par identifiant
        # prenait plusieurs minutes chacune), puis filtrage sur les identifiants
        $trouve = $recherche.Search('IsInstalled=0 and IsHidden=0')
        foreach ($u in $trouve.Updates) {
            if ($ids -notcontains $u.Identity.UpdateID) { continue }
            if (-not $u.EulaAccepted) { $u.AcceptEula() }
            [void]$collection.Add($u)
        }
        if ($collection.Count -eq 0) { throw 'Mises à jour introuvables (déjà installées ?)' }
        $telechargement = $session.CreateUpdateDownloader()
        $telechargement.Updates = $collection
        $resultatTelechargement = $telechargement.Download()
        if ($resultatTelechargement.ResultCode -notin @(2, 3)) {
            throw ('Téléchargement impossible (code {0}, erreur 0x{1:X8}) : vérifie ta connexion puis réessaie' -f $resultatTelechargement.ResultCode, $resultatTelechargement.HResult)
        }
        $installation = $session.CreateUpdateInstaller()
        $installation.Updates = $collection
        try { $installation.ForceQuiet = $true } catch { }
        $resultat = $installation.Install()
        $details = for ($i = 0; $i -lt $collection.Count; $i++) {
            $code = $resultat.GetUpdateResult($i).ResultCode   # 2 = réussi, 3 = réussi avec erreurs, 4 = échec
            [pscustomobject]@{ Id = $collection.Item($i).Identity.UpdateID; Reussi = ($code -eq 2); Code = $code }
        }
        [pscustomobject]@{ Details = @($details); RedemarrageRequis = [bool]$resultat.RebootRequired }
    }
    $retour = @($retour)[-1]
    Write-Journal ("Windows Update : {0} mise(s) à jour traitée(s), redémarrage requis = {1}" -f @($retour.Details).Count, $retour.RedemarrageRequis)
    return $retour
}

# ---------------------------------------------------------------------
#  Informations : BIOS et pilote graphique
# ---------------------------------------------------------------------
function Get-InfosMisesAJourMateriel {
    <# Lignes « à vérifier soi-même » : BIOS et pilote graphique du fabricant #>
    param($Donnees)
    $liste = New-Object System.Collections.ArrayList

    $bios = Get-CimInstance Win32_BIOS
    $carte = Get-CimInstance Win32_BaseBoard
    $ageBios = [int]((Get-Date) - $bios.ReleaseDate).TotalDays
    $recherche = [uri]::EscapeDataString("$($carte.Product) BIOS")
    $lien = switch -Regex ($carte.Manufacturer) {
        'Gigabyte' { "https://www.gigabyte.com/Search?kw=$recherche" }
        'ASUS'     { "https://www.asus.com/searchresult?searchType=support&searchKey=$recherche" }
        'Micro-Star|MSI' { "https://www.msi.com/search/$recherche" }
        'ASRock'   { "https://www.asrock.com/search/?Model=$recherche" }
        default    { "https://www.google.com/search?q=$recherche" }
    }
    [void]$liste.Add((New-MiseAJour -Type 'BIOS' -Nom "$($carte.Manufacturer) $($carte.Product)" -Actuelle "$($bios.SMBIOSBIOSVersion) ($($bios.ReleaseDate.ToString('dd/MM/yyyy')))" `
                -Source 'Site du fabricant' -Cle $lien -Selection $false -Etat 'Manuel' `
                -Detail "BIOS de $ageBios jours. À mettre à jour seulement en cas de problème ou de nouveau processeur, avec l'outil du fabricant (Q-Flash chez Gigabyte). Sélectionne la ligne puis « Installer » pour ouvrir la page."))

    foreach ($gpu in @($Donnees.Gpus | Where-Object { $_.Marque -in @('AMD', 'NVIDIA', 'Intel') })) {
        $page = switch ($gpu.Marque) {
            'AMD'    { 'https://www.amd.com/fr/support/download/drivers.html' }
            'NVIDIA' { 'https://www.nvidia.com/fr-fr/software/nvidia-app/' }
            default  { 'https://www.intel.fr/content/www/fr/fr/support/detect.html' }
        }
        [void]$liste.Add((New-MiseAJour -Type 'Carte graphique' -Nom $gpu.Nom -Actuelle "pilote de $($gpu.AgePilote) jours" -Source 'Site du fabricant' `
                    -Cle $page -Selection $false -Etat $(if ($gpu.PiloteAncien) { 'Disponible' } else { 'Manuel' }) `
                    -Detail "Vérifie les nouvelles versions dans le logiciel du fabricant (AMD Adrenalin : Système > Mises à jour). Sélectionne la ligne puis « Installer » pour ouvrir la page."))
    }
    return $liste
}

﻿# =====================================================================
#  Taches.ps1
#  ---------------------------------------------------------------------
#  Catalogue de toutes les optimisations proposées.
#
#  Chaque tâche est une table avec :
#    Id, Categorie, Titre, Description  : informations affichées
#    Impact     : Faible / Moyen / Élevé (gain attendu, estimé honnêtement)
#    Risque     : Aucun / Faible / Moyen
#    Reversible : texte expliquant comment revenir en arrière
#    Manuel     : $true si l'action doit être faite par l'utilisateur
#    Auto       : $true = incluse dans « Tout optimiser » (gain réel, sans
#                 risque, annulable ou sans conséquence)
#    Redemarrage: $true si l'effet demande un redémarrage
#    Verifier   : { param($D) ... }  -> New-Resultat (état + détail)
#    Appliquer  : { param($D) ... }  -> texte de compte rendu
#    Ouvrir     : { param($D) ... }  (optionnel) ouvre la page utile ;
#                 peut renvoyer 'onglet:<Nom>' pour que l'interface
#                 affiche un de ses onglets (aucune dépendance à l'UI ici)
#  $D = données du diagnostic (voir Diagnostic.ps1).
#
#  Après application, l'interface relance Verifier : une correction n'est
#  annoncée « vérifiée » que si l'état est réellement devenu OK.
#
#  Règle suivie : uniquement des réglages reconnus et documentés.
#  Pas de « nettoyeur de registre », « libérateur de RAM », tweaks
#  réseau TCP miracles ou désactivation de la sécurité.
# =====================================================================

# Chemins de registre réutilisés
$script:RegCDM      = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
$script:RegAvance   = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
$script:GuidHautePerf = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'

# Applications préinstallées considérées comme superflues (liste volontairement prudente)
$script:ApplisSuperflues = @(
    'Microsoft.BingNews', 'Microsoft.BingWeather', 'Microsoft.BingSearch', 'Microsoft.MicrosoftSolitaireCollection',
    'Microsoft.People', 'Microsoft.WindowsFeedbackHub', 'Microsoft.MicrosoftOfficeHub', 'Microsoft.549981C3F5F10',
    'Clipchamp.Clipchamp', 'Microsoft.PowerAutomateDesktop', 'MicrosoftCorporationII.MicrosoftFamily',
    'Microsoft.WindowsMaps', 'Microsoft.MixedReality.Portal', 'Microsoft.SkypeApp', 'MicrosoftTeams',
    '*CandyCrush*', '*BubbleWitch*', 'king.com.*', '*Disney*', '*TikTok*', '*Facebook*', '*Instagram*'
)

# Services rarement utilisés sur un PC personnel : Nom -> mode cible
$script:ServicesSecondaires = [ordered]@{
    'Fax'           = 'Desactive'
    'RetailDemo'    = 'Desactive'
    'MapsBroker'    = 'Manuel'
    'WMPNetworkSvc' = 'Manuel'
}

function Get-ApplisSuperfluesPresentes {
    <# Liste les applications de $script:ApplisSuperflues installées pour l'utilisateur #>
    $installees = @(Get-AppxPackage -ErrorAction SilentlyContinue)   # une seule lecture (rapide)
    $trouvees = foreach ($motif in $script:ApplisSuperflues) { $installees | Where-Object { $_.Name -like $motif } }
    return @($trouvees | Sort-Object Name -Unique)
}

function Test-MiseAJourEnCours {
    <# $true si Windows Update est en train d'installer quelque chose #>
    try { return [bool](New-Object -ComObject 'Microsoft.Update.Installer').IsBusy }
    catch { return [bool](Get-Process -Name 'TiWorker' -ErrorAction SilentlyContinue) }
}

function Get-PlanHautePerformance {
    <# Renvoie le GUID d'un plan « Performances élevées » déjà présent (original
       ou copie créée précédemment), ou $null. Évite de créer des doublons. #>
    foreach ($ligne in (& powercfg.exe /list)) {
        if ($ligne -notmatch "($script:RegexGuid)") { continue }
        $guid = $Matches[1]   # à lire tout de suite : le -match suivant écrase $Matches
        if ($guid -eq $script:GuidHautePerf -or $ligne -match 'Performances élevées|High performance') { return $guid }
    }
    return $null
}

function Get-CartesReseauActives {
    <# Cartes réseau physiques connectées #>
    return @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
}

# Navigateurs : cache supprimé seulement si le navigateur est fermé
# (les favoris, mots de passe, cookies et l'historique ne sont pas touchés)
$script:Navigateurs = @(
    @{ Nom = 'Chrome';   Processus = 'chrome';  Base = "$env:LOCALAPPDATA\Google\Chrome\User Data" }
    @{ Nom = 'Edge';     Processus = 'msedge';  Base = "$env:LOCALAPPDATA\Microsoft\Edge\User Data" }
    @{ Nom = 'Brave';    Processus = 'brave';   Base = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data" }
    @{ Nom = 'Opera GX'; Processus = 'opera';   Base = "$env:LOCALAPPDATA\Opera Software\Opera GX Stable" }
    @{ Nom = 'Opera';    Processus = 'opera';   Base = "$env:LOCALAPPDATA\Opera Software\Opera Stable" }
    @{ Nom = 'Firefox';  Processus = 'firefox'; Base = "$env:LOCALAPPDATA\Mozilla\Firefox\Profiles" }
)

function Get-DossiersCacheNavigateur {
    <# Dossiers de cache d'un navigateur (tous profils) #>
    param($Navigateur)
    if (-not (Test-Path -LiteralPath $Navigateur.Base)) { return @() }
    if ($Navigateur.Nom -eq 'Firefox') {
        return @(Get-ChildItem -LiteralPath $Navigateur.Base -Directory -ErrorAction SilentlyContinue |
                ForEach-Object { Join-Path $_.FullName 'cache2' } | Where-Object { Test-Path -LiteralPath $_ })
    }
    $profils = @($Navigateur.Base) + @(Get-ChildItem -LiteralPath $Navigateur.Base -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' } | ForEach-Object { $_.FullName })
    $dossiers = foreach ($profil in $profils) {
        foreach ($sous in @('Cache', 'Code Cache', 'GPUCache')) {
            $chemin = Join-Path $profil $sous
            if (Test-Path -LiteralPath $chemin) { $chemin }
        }
    }
    return @($dossiers | Select-Object -Unique)
}

# Cache de l'Optimisation de distribution (morceaux de mises à jour partagés)
$script:DossierCacheLivraison = "$env:windir\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache"

# Lanceurs et applis sans utilité au démarrage : ils se mettent à jour quand on les ouvre.
# (Jamais : audio, sécurité, pilotes, périphériques, synchronisation — voir Demarrage.ps1)
$script:LanceursNonEssentiels = '^(Steam|EpicGamesLauncher|EADM|EA Desktop|GalaxyClient|GogGalaxy|UbisoftConnect|Uplay|Battle\.net|Discord|Spotify|MicrosoftEdgeAutoLaunch.*|MSTeams|Teams|Copilot|StartExperiencesApp|Skype.*)$'

function Get-LanceursActifs {
    <# Entrées de démarrage actives correspondant à la liste des lanceurs non essentiels #>
    return @(Get-ProgrammesDemarrage | Where-Object { $_.Actif -and $_.Modifiable -and -not $_.Avertissement -and $_.Nom -match $script:LanceursNonEssentiels })
}

# Corbeille : âge (jours) au-delà duquel un élément supprimé est vidé automatiquement
$script:JoursCorbeille = 30

function Get-ElementsCorbeille {
    <# Éléments de la corbeille de l'utilisateur sur tous les disques, avec leur date
       de suppression. Windows range chaque élément en deux parties :
       $I… (8 o version, 8 o taille, 8 o date de suppression FILETIME…) et $R… (le contenu). #>
    param($Volumes)
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    foreach ($volume in $Volumes) {
        $dossier = "$($volume.Lettre):\`$Recycle.Bin\$sid"
        if (-not (Test-Path -LiteralPath $dossier -ErrorAction SilentlyContinue)) { continue }
        foreach ($info in (Get-ChildItem -LiteralPath $dossier -Filter '$I*' -Force -File -ErrorAction SilentlyContinue)) {
            try {
                $octets = [IO.File]::ReadAllBytes($info.FullName)
                if ($octets.Length -lt 24) { continue }
                $taille = [BitConverter]::ToInt64($octets, 8)
                $supprime = [DateTime]::FromFileTime([BitConverter]::ToInt64($octets, 16))
            }
            catch { continue }
            [pscustomobject]@{
                Info     = $info.FullName
                Contenu  = Join-Path $dossier ('$R' + $info.Name.Substring(2))
                Supprime = $supprime
                Taille   = $taille
            }
        }
    }
}

# Âge minimal des rapports d'erreurs supprimés (les traces récentes servent à
# diagnostiquer un écran bleu et sont conservées)
$script:JoursRapports = 30

# Chemins nettoyés par la tâche « Rapports d'erreurs »
$script:DossiersRapports = @(
    "$env:ProgramData\Microsoft\Windows\WER\ReportArchive",
    "$env:ProgramData\Microsoft\Windows\WER\ReportQueue",
    "$env:LOCALAPPDATA\Microsoft\Windows\WER",
    "$env:windir\Minidump",
    "$env:windir\LiveKernelReports"
)

$script:CatalogueTaches = @(

    # =================================================================
    #  NETTOYAGE
    # =================================================================
    @{
        Id = 'NET_TEMP'; Categorie = 'Nettoyage'; Titre = 'Vider les fichiers temporaires'
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Non (fichiers jetables)'
        Description = "Supprime tous les fichiers temporaires de ton compte et de Windows. Seuls sont conservés les fichiers créés dans la dernière heure (installation en cours…) et ceux qu'un programme ouvert utilise encore : le rapport indique combien."
        Verifier = {
            param($D)
            # Même filtre d'une heure que le nettoyage : sinon la tâche resterait « à corriger »
            $taille = Get-TailleDossiers @($env:TEMP, "$env:windir\Temp") -AgeMinimumHeures 1
            if ($taille -gt 300MB) { New-Resultat 'Recommandé' "$(Format-Taille $taille) de fichiers temporaires" }
            elseif ($taille -gt 50MB) { New-Resultat 'Optionnel' "$(Format-Taille $taille) de fichiers temporaires" }
            else { New-Resultat 'OK' "$(Format-Taille $taille) seulement" }
        }
        Appliquer = {
            param($D)
            Format-Nettoyage @((Clear-Dossier $env:TEMP 1), (Clear-Dossier "$env:windir\Temp" 1))
        }
    }

    @{
        Id = 'NET_WU'; Categorie = 'Nettoyage'; Titre = 'Vider le cache de Windows Update'
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Non (Windows retélécharge si besoin)'
        Description = "Supprime les fichiers d'installation des mises à jour déjà téléchargées (dossier SoftwareDistribution\Download). Aucun effet sur les mises à jour déjà installées."
        Verifier = {
            param($D)
            if ($D.RedemarrageEnAttente) { return New-Resultat 'Non applicable' 'Redémarre d''abord : une mise à jour attend' }
            if (Test-MiseAJourEnCours) { return New-Resultat 'Non applicable' 'Une mise à jour est en cours d''installation' }
            $taille = Get-TailleDossiers @("$env:windir\SoftwareDistribution\Download")
            if ($taille -gt 500MB) { New-Resultat 'Recommandé' "$(Format-Taille $taille) récupérables" }
            elseif ($taille -gt 100MB) { New-Resultat 'Optionnel' "$(Format-Taille $taille) récupérables" }
            else { New-Resultat 'OK' "$(Format-Taille $taille) seulement" }
        }
        Appliquer = {
            param($D)
            # Nouvelle vérification juste avant d'agir : l'état a pu changer depuis l'analyse
            if (Test-MiseAJourEnCours) { throw "Une mise à jour est en cours d'installation : réessaie plus tard." }
            try {
                Stop-Service -Name wuauserv, bits -Force -ErrorAction Stop
                $nettoyage = Clear-Dossier "$env:windir\SoftwareDistribution\Download"
            }
            finally {
                Start-Service -Name bits, wuauserv -ErrorAction SilentlyContinue   # toujours relancer les services
            }
            Format-Nettoyage @($nettoyage)
        }
    }

    @{
        Id = 'NET_CORBEILLE_ANCIENS'; Categorie = 'Nettoyage'; Titre = "Vider la corbeille des fichiers supprimés il y a plus de 30 jours"
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Non (fichiers supprimés depuis plus d''un mois)'
        Description = "Comme l'Assistant de stockage de Windows : supprime définitivement de la corbeille uniquement ce que tu as jeté il y a plus de 30 jours. Les fichiers supprimés récemment restent récupérables."
        Verifier = {
            param($D)
            $limite = (Get-Date).AddDays(-$script:JoursCorbeille)
            $anciens = @(Get-ElementsCorbeille $D.Volumes | Where-Object { $_.Supprime -lt $limite })
            if ($anciens.Count -eq 0) { return New-Resultat 'OK' "Rien de plus de $($script:JoursCorbeille) jours dans la corbeille" }
            $taille = [int64](($anciens | Measure-Object -Property Taille -Sum).Sum)
            $etat = if ($taille -gt 100MB) { 'Recommandé' } else { 'Optionnel' }
            New-Resultat $etat "$($anciens.Count) élément(s) de plus de $($script:JoursCorbeille) jours ($(Format-Taille $taille))"
        }
        Appliquer = {
            param($D)
            $limite = (Get-Date).AddDays(-$script:JoursCorbeille)
            $supprimes = 0; $echecs = 0; [int64]$libere = 0
            foreach ($element in @(Get-ElementsCorbeille $D.Volumes | Where-Object { $_.Supprime -lt $limite })) {
                try {
                    if (Test-Path -LiteralPath $element.Contenu -PathType Container) {
                        # Directory.Delete ne suit pas les jonctions : aucun risque hors de la corbeille
                        [IO.Directory]::Delete($element.Contenu, $true)
                    }
                    elseif (Test-Path -LiteralPath $element.Contenu) {
                        (Get-Item -LiteralPath $element.Contenu -Force).Attributes = 'Normal'
                        [IO.File]::Delete($element.Contenu)
                    }
                    [IO.File]::Delete($element.Info)
                    $supprimes++; $libere += $element.Taille
                }
                catch { $echecs++; Write-Journal "Corbeille : échec sur $($element.Contenu) : $($_.Exception.Message)" 'ATTENTION' }
            }
            if ($supprimes -eq 0 -and $echecs -gt 0) { throw "Aucun élément n'a pu être supprimé ($echecs échec(s))" }
            "$supprimes élément(s) supprimé(s), $(Format-Taille $libere) libérés" + $(if ($echecs) { " ; $echecs en échec" } else { '' })
        }
    }

    @{
        Id = 'NET_CORBEILLE'; Categorie = 'Nettoyage'; Titre = 'Vider entièrement la corbeille'
        Impact = 'Faible'; Risque = 'Faible'; Manuel = $false
        Reversible = 'Non — vérifie qu''elle ne contient rien d''important'
        Description = "Vide définitivement TOUTE la corbeille, y compris ce que tu viens de jeter. Jamais fait automatiquement (un fichier supprimé par erreur serait perdu) : coche cette tâche puis « Appliquer la sélection » si tu es sûr."
        Verifier = {
            param($D)
            $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
            $chemins = foreach ($v in $D.Volumes) { "$($v.Lettre):\`$Recycle.Bin\$sid" }
            # desktop.ini est recréé par Windows : sans cette exclusion, la corbeille ne serait jamais « vide »
            $taille = Get-TailleDossiers @($chemins) -ExclureNoms @('desktop.ini')
            # Jamais « Recommandé » : suppression définitive, l'utilisateur doit choisir lui-même
            if ($taille -gt 0) { New-Resultat 'Optionnel' "$(Format-Taille $taille) dans la corbeille" }
            else { New-Resultat 'OK' 'Corbeille vide' }
        }
        Appliquer = {
            param($D)
            # En arrière-plan : peut être long avec beaucoup de fichiers.
            # Les erreurs sont remontées (plus de « Corbeille vidée » en cas d'échec).
            Invoke-EnArrierePlan -DelaiSecondes 900 -Script { Clear-RecycleBin -Force -ErrorAction Stop } | Out-Null
            'Corbeille vidée'
        }
    }

    @{
        Id = 'NET_RAPPORTS'; Categorie = 'Nettoyage'; Titre = "Supprimer les anciens rapports d'erreurs"
        Impact = 'Faible'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Non'
        Description = "Supprime les rapports d'erreurs Windows et les fichiers de plantage de plus de $script:JoursRapports jours. Les traces récentes et le vidage mémoire complet (MEMORY.DMP) sont conservés : ils servent à diagnostiquer un écran bleu. Pour tout supprimer, fais-le depuis le Nettoyage de disque de Windows."
        Verifier = {
            param($D)
            # Même filtre d'âge que la suppression, sinon l'état ne reviendrait jamais à « OK »
            $taille = Get-TailleDossiers $script:DossiersRapports -AgeMinimumHeures ($script:JoursRapports * 24)
            if ($taille -gt 300MB) { New-Resultat 'Recommandé' "$(Format-Taille $taille) récupérables (plus de $script:JoursRapports jours)" }
            elseif ($taille -gt 10MB) { New-Resultat 'Optionnel' "$(Format-Taille $taille) récupérables (plus de $script:JoursRapports jours)" }
            else { New-Resultat 'OK' "$(Format-Taille $taille) seulement" }
        }
        Appliquer = {
            param($D)
            $resultats = @(foreach ($dossier in $script:DossiersRapports) { Clear-Dossier $dossier ($script:JoursRapports * 24) })
            Format-Nettoyage $resultats
        }
    }

    @{
        Id = 'NET_NAVIGATEURS'; Categorie = 'Nettoyage'; Titre = 'Vider le cache des navigateurs'
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Non (le cache se reconstitue au fil de la navigation)'
        Description = "Supprime les fichiers de cache de Chrome, Edge, Brave, Opera et Firefox (pages, images et scripts mis en mémoire). Les favoris, mots de passe, cookies et l'historique ne sont PAS touchés. Un navigateur ouvert est ignoré : ferme-le avant (Edge reste souvent ouvert en arrière-plan)."
        Verifier = {
            param($D)
            [int64]$total = 0
            $details = New-Object System.Collections.ArrayList
            $ouverts = New-Object System.Collections.ArrayList
            foreach ($nav in $script:Navigateurs) {
                $taille = Get-TailleDossiers (Get-DossiersCacheNavigateur $nav)
                if ($taille -lt 1MB) { continue }
                # Un navigateur ouvert n'est pas nettoyé : sa taille n'est donc pas
                # comptée dans le total, sinon la tâche ne serait jamais « OK »
                if (Get-Process -Name $nav.Processus -ErrorAction SilentlyContinue) {
                    [void]$ouverts.Add("$($nav.Nom) $(Format-Taille $taille) (ouvert : à fermer)")
                    continue
                }
                $total += $taille
                [void]$details.Add("$($nav.Nom) $(Format-Taille $taille)")
            }
            $texte = (@($details) + @($ouverts)) -join ' ; '
            if ($total -gt 500MB) { New-Resultat 'Recommandé' $texte }
            elseif ($total -gt 100MB) { New-Resultat 'Optionnel' $texte }
            elseif ($ouverts.Count -gt 0) { New-Resultat 'OK' "$(Format-Taille $total) à vider ; $($ouverts -join ' ; ')" }
            else { New-Resultat 'OK' "$(Format-Taille $total) de cache seulement" }
        }
        Appliquer = {
            param($D)
            $resultats = New-Object System.Collections.ArrayList
            $ignores = New-Object System.Collections.ArrayList
            foreach ($nav in $script:Navigateurs) {
                $dossiers = @(Get-DossiersCacheNavigateur $nav)
                if ($dossiers.Count -eq 0) { continue }
                if (Get-Process -Name $nav.Processus -ErrorAction SilentlyContinue) { [void]$ignores.Add($nav.Nom); continue }
                foreach ($dossier in $dossiers) { [void]$resultats.Add((Clear-Dossier $dossier)) }
            }
            $texte = if ($resultats.Count -gt 0) { Format-Nettoyage @($resultats) } else { 'Aucun cache supprimé' }
            if ($ignores.Count -gt 0) { $texte += " ; ignorés car ouverts : $($ignores -join ', ')" }
            $texte
        }
    }

    @{
        Id = 'NET_LIVRAISON'; Categorie = 'Nettoyage'; Titre = "Vider le cache de l'Optimisation de distribution"
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Non (morceaux de mises à jour déjà installées)'
        Description = "Windows garde des morceaux de mises à jour pour les partager avec d'autres PC. Ce cache peut peser plusieurs Go. Il est vidé avec la commande officielle de Windows."
        Verifier = {
            param($D)
            $taille = Get-TailleDossiers @($script:DossierCacheLivraison)
            if ($taille -gt 500MB) { New-Resultat 'Recommandé' "$(Format-Taille $taille) récupérables" }
            elseif ($taille -gt 100MB) { New-Resultat 'Optionnel' "$(Format-Taille $taille) récupérables" }
            else { New-Resultat 'OK' "$(Format-Taille $taille) seulement" }
        }
        Appliquer = {
            param($D)
            $avant = Get-TailleDossiers @($script:DossierCacheLivraison)
            Delete-DeliveryOptimizationCache -Force -ErrorAction Stop
            $apres = Get-TailleDossiers @($script:DossierCacheLivraison)
            "$(Format-Taille ([math]::Max(0, $avant - $apres))) libérés"
        }
    }

    @{
        Id = 'NET_DISM'; Categorie = 'Nettoyage'; Titre = 'Nettoyer les anciens composants Windows'
        Impact = 'Moyen'; Risque = 'Faible'; Manuel = $false
        Reversible = 'Non (les anciennes versions de mises à jour ne pourront plus être désinstallées)'
        Description = "Lance DISM /StartComponentCleanup : supprime les anciennes versions des composants remplacés par des mises à jour. Peut libérer plusieurs Go. Durée : 5 à 20 minutes."
        Verifier = { param($D) New-Resultat 'Optionnel' 'Gain non mesurable sans analyse longue' }
        Appliquer = {
            param($D)
            $code = Start-ProcessAvecInterface 'dism.exe' '/Online /Cleanup-Image /StartComponentCleanup /Quiet /NoRestart'
            if ($code -eq 0) { 'Terminé' } else { "Terminé avec le code $code" }
        }
    }

    # =================================================================
    #  DÉMARRAGE & SERVICES
    # =================================================================
    @{
        Id = 'DEM_PROGRAMMES'; Categorie = 'Démarrage'; Titre = 'Trier les programmes au démarrage'
        Impact = 'Élevé'; Risque = 'Aucun'; Manuel = $true
        Reversible = 'Oui (réactivation en un clic)'
        Description = "C'est souvent le gain le plus visible au démarrage. Clique sur « Ouvrir » pour aller dans la page « Démarrage », coche les programmes dont tu n'as pas besoin dès l'allumage (launchers, utilitaires constructeurs…) et clique « Désactiver ». Garde l'antivirus et les pilotes (audio, AMD/NVIDIA)."
        Verifier = {
            param($D)
            # On ne compte ni les entrées utiles signalées (audio, sécurité…) ni les lanceurs gérés par DEM_LANCEURS
            $autres = @($D.ProgrammesDemarrage | Where-Object { $_.Actif -and -not $_.Avertissement -and $_.Nom -notmatch $script:LanceursNonEssentiels })
            if ($autres.Count -gt 4) { New-Resultat 'Manuel' "$($autres.Count) autres programmes actifs à examiner : $(($autres | ForEach-Object { $_.Nom }) -join ', ')" }
            else { New-Resultat 'OK' "$($D.NbDemarrageActifs) programmes actifs, dont $($autres.Count) à examiner" }
        }
        Ouvrir = { param($D) 'onglet:Demarrage' }
    }

    @{
        Id = 'DEM_LANCEURS'; Categorie = 'Démarrage'; Titre = 'Retirer les lanceurs de jeux et applis du démarrage'
        Impact = 'Élevé'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique ou page Démarrage)'
        Description = "Empêche Steam, Epic, EA, GOG, Ubisoft, Battle.net, Discord, Spotify, Teams, Copilot et le préchargement d'Edge de se lancer à l'allumage. Ils fonctionnent normalement quand tu les ouvres. Les pilotes, l'audio, la sécurité et les logiciels de périphériques ne sont jamais touchés."
        Verifier = {
            param($D)
            $lanceurs = Get-LanceursActifs
            if ($lanceurs.Count -gt 0) { New-Resultat 'Recommandé' ('Actifs : ' + (($lanceurs | ForEach-Object { $_.Nom }) -join ', ')) }
            else { New-Resultat 'OK' 'Aucun lanceur au démarrage' }
        }
        Appliquer = {
            param($D)
            $lanceurs = Get-LanceursActifs
            foreach ($entree in $lanceurs) {
                Add-ActionAnnulable ([ordered]@{ Type = 'Demarrage'; TypeEntree = $entree.Type; Cible = $entree.Cible; Nom = $entree.Nom })
                Set-EtatDemarrage -Type $entree.Type -Cible $entree.Cible -Nom $entree.Nom -Actif $false
            }
            "$($lanceurs.Count) programme(s) retiré(s) du démarrage"
        }
    }

    @{
        Id = 'DEM_SERVICES'; Categorie = 'Démarrage'; Titre = 'Mettre en veille des services rarement utilisés'
        Impact = 'Faible'; Risque = 'Faible'; Manuel = $false
        Reversible = 'Oui (page Historique)'
        Description = "Fax et Démo en magasin : désactivés. Cartes hors connexion et Partage réseau du Lecteur Windows Media : démarrage manuel (ils se lancent si une appli en a besoin). Gain faible : désactiver massivement des services apporte peu et casse souvent des fonctions."
        Verifier = {
            param($D)
            $cible = @{ Desactive = 4; Manuel = 3 }
            $aModifier = foreach ($nom in $script:ServicesSecondaires.Keys) {
                $start = Get-ServiceStart $nom
                if ($null -ne $start -and $start -lt $cible[$script:ServicesSecondaires[$nom]]) { $nom }
            }
            if (@($aModifier).Count -gt 0) { New-Resultat 'Optionnel' ('À ajuster : ' + (@($aModifier) -join ', ')) }
            else { New-Resultat 'OK' 'Déjà réglés' }
        }
        Appliquer = {
            param($D)
            foreach ($nom in $script:ServicesSecondaires.Keys) {
                if ($null -ne (Get-ServiceStart $nom)) { Set-ServiceDemarrage -Nom $nom -Mode $script:ServicesSecondaires[$nom] }
            }
            'Services ajustés'
        }
    }

    @{
        Id = 'DEM_APPLIS'; Categorie = 'Démarrage'; Titre = 'Désinstaller les applications préinstallées inutiles'
        Impact = 'Faible'; Risque = 'Faible'; Manuel = $false
        Reversible = 'Non automatiquement — réinstallables depuis le Microsoft Store'
        Description = "Supprime pour ton compte les applis promotionnelles (Actualités, Météo, Solitaire, Clipchamp, Teams perso, Candy Crush…). Les applis Xbox, Photos, Calculatrice, Store, etc. ne sont jamais touchées. Le détail liste exactement ce qui sera supprimé."
        Verifier = {
            param($D)
            $applis = Get-ApplisSuperfluesPresentes
            if ($applis.Count -gt 0) { New-Resultat 'Optionnel' (($applis | ForEach-Object { $_.Name -replace '^[^.]+\.', '' }) -join ', ') }
            else { New-Resultat 'OK' 'Aucune appli superflue trouvée' }
        }
        Appliquer = {
            param($D)
            $applis = Get-ApplisSuperfluesPresentes
            $ok = 0
            $echecs = New-Object System.Collections.ArrayList
            foreach ($appli in $applis) {
                Write-Progression "Désinstallation : $($appli.Name)…"
                try {
                    # En arrière-plan : Remove-AppxPackage peut prendre plusieurs secondes
                    Invoke-EnArrierePlan -Arguments @($appli.PackageFullName) -Script { param($paquet) Remove-AppxPackage -Package $paquet -ErrorAction Stop } | Out-Null
                    $ok++
                    Write-Journal "Appli supprimée : $($appli.Name)"
                }
                catch {
                    [void]$echecs.Add($appli.Name)
                    Write-Journal "Échec suppression $($appli.Name) : $($_.Exception.Message)" 'ERREUR'
                }
            }
            if ($applis.Count -gt 0 -and $ok -eq 0) { throw "Aucune appli n'a pu être supprimée (voir le journal)" }
            if ($echecs.Count -gt 0) { "$ok appli(s) supprimée(s) — échec : $($echecs -join ', ')" } else { "$ok appli(s) supprimée(s)" }
        }
    }

    # =================================================================
    #  JEUX & PERFORMANCES
    # =================================================================
    @{
        Id = 'PERF_ALIM'; Categorie = 'Performances'; Titre = "Mode d'alimentation « Performances élevées »"
        Impact = 'Faible'; Risque = 'Aucun'; Manuel = $false
        Reversible = 'Oui (page Historique)'
        Description = "Empêche le processeur de descendre dans ses états d'économie les plus profonds. Gain réel mais modeste en jeu. Sur processeur AMD Ryzen avec les pilotes chipset AMD, le mode « Utilisation normale » est déjà optimisé : le gain est quasi nul et la consommation au repos augmente."
        Verifier = {
            param($D)
            if ($D.PlanActifGuid -eq $script:GuidHautePerf -or $D.PlanActifNom -match 'performance') { return New-Resultat 'OK' "Actif : $($D.PlanActifNom)" }
            if ($D.EstPortable) { return New-Resultat 'Optionnel' "Actif : $($D.PlanActifNom) — réduit l'autonomie sur batterie" }
            if ($D.CpuAmd) { return New-Resultat 'Optionnel' "Actif : $($D.PlanActifNom) — gain très faible sur Ryzen" }
            New-Resultat 'Recommandé' "Actif : $($D.PlanActifNom)"
        }
        Appliquer = {
            param($D)
            # Plan actif lu maintenant (et non à l'analyse) pour une annulation exacte
            if ((Invoke-Commande 'powercfg.exe' @('/getactivescheme')) -match "($script:RegexGuid)") { $ancienGuid = $Matches[1] } else { throw 'Plan actif introuvable' }
            Add-ActionAnnulable ([ordered]@{ Type = 'PlanAlimentation'; Guid = $ancienGuid })
            $guid = Get-PlanHautePerformance
            if (-not $guid) {
                # Plan masqué sur ce PC : on en crée une copie (une seule fois, réutilisée ensuite)
                $sortie = Invoke-Commande 'powercfg.exe' @('-duplicatescheme', $script:GuidHautePerf)
                if ($sortie -match "($script:RegexGuid)") { $guid = $Matches[1] } else { throw "Impossible de créer le mode Performances élevées : $sortie" }
            }
            Invoke-Commande 'powercfg.exe' @('/setactive', $guid) | Out-Null
            'Mode Performances élevées activé'
        }
    }

    @{
        Id = 'PERF_MODEJEU'; Categorie = 'Performances'; Titre = 'Activer le Mode Jeu de Windows'
        Impact = 'Faible'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique)'
        Description = "Le Mode Jeu donne la priorité au jeu en cours et bloque les redémarrages Windows Update pendant la partie. Activé par défaut ; cette tâche le réactive s'il a été coupé."
        Verifier = {
            param($D)
            if ((Get-RegValeur 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled') -eq 0) { New-Resultat 'Recommandé' 'Mode Jeu désactivé' }
            else { New-Resultat 'OK' 'Mode Jeu actif' }
        }
        Appliquer = {
            param($D)
            Set-RegValeur 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1
            'Mode Jeu activé'
        }
    }

    @{
        Id = 'PERF_ENREG'; Categorie = 'Performances'; Titre = "Couper l'enregistrement de jeu en arrière-plan"
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique)'
        Description = "La Xbox Game Bar peut enregistrer en continu les dernières minutes de jeu, ce qui coûte des images/seconde. Les captures manuelles (Win+Alt+R) restent possibles. Si tu utilises le « replay instantané » d'AMD Adrenalin, désactive-le aussi dans Adrenalin si tu n'en as pas besoin."
        Verifier = {
            param($D)
            if ((Get-RegValeur 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled') -eq 1) { New-Resultat 'Recommandé' 'Enregistrement en arrière-plan actif' }
            else { New-Resultat 'OK' 'Enregistrement en arrière-plan inactif' }
        }
        Appliquer = {
            param($D)
            Set-RegValeur 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled' 0
            'Enregistrement en arrière-plan coupé'
        }
    }

    @{
        Id = 'PERF_HAGS'; Categorie = 'Performances'; Titre = 'Planification GPU à accélération matérielle'
        Impact = 'Faible'; Risque = 'Faible'; Manuel = $false; Auto = $true; Redemarrage = $true
        Reversible = 'Oui (onglet Historique) — redémarrage nécessaire'
        Description = "Laisse la carte graphique gérer sa propre mémoire. Réduit légèrement la latence ; requis pour la génération d'images (DLSS 3 / AFMF selon les jeux). Nécessite une carte récente (NVIDIA GTX 1000+, AMD RX 5000+, Intel Arc) et un redémarrage."
        Verifier = {
            param($D)
            $valeur = Get-RegValeur 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode'
            if ($valeur -eq 2) { return New-Resultat 'OK' 'Activée' }
            if (-not ($D.Gpus | Where-Object { $_.Marque -in @('NVIDIA', 'AMD', 'Intel') })) { return New-Resultat 'Non applicable' 'Aucune carte compatible détectée' }
            # Valeur absente : Windows applique son propre réglage (activé par défaut
            # sur les cartes récentes). On ne touche à rien et on l'indique.
            if ($null -eq $valeur) { return New-Resultat 'OK' 'Réglage par défaut de Windows (activé sur les cartes récentes)' }
            New-Resultat 'Optionnel' 'Désactivée'
        }
        Appliquer = {
            param($D)
            Set-RegValeur 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 2
            'Activée (après redémarrage)'
        }
    }

    @{
        Id = 'PERF_JEUX_FENETRE'; Categorie = 'Performances'; Titre = 'Optimisations pour les jeux en mode fenêtré'
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique)'
        Description = "Réglage de Windows 11 qui fait fonctionner les jeux DirectX 10/11 en fenêtre ou fenêtre sans bordure comme en plein écran : latence réduite et fréquence d'images plus stable."
        Verifier = {
            param($D)
            if (-not $D.EstWin11) { return New-Resultat 'Non applicable' 'Réservé à Windows 11' }
            $valeur = [string](Get-RegValeur 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences' 'DirectXUserGlobalSettings')
            if ($valeur -match 'SwapEffectUpgradeEnable=1') { return New-Resultat 'OK' 'Activées' }
            if ($valeur -match 'SwapEffectUpgradeEnable=0') { return New-Resultat 'Recommandé' 'Désactivées' }
            # Absent : activé par défaut depuis Windows 11 24H2, désactivé avant
            if ($D.Build -ge 26100) { return New-Resultat 'OK' 'Activées par défaut (Windows 11 24H2 ou plus récent)' }
            New-Resultat 'Recommandé' 'Désactivées'
        }
        Appliquer = {
            param($D)
            $cle = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
            # On conserve les autres réglages présents dans la même valeur (ex. VRROptimizeEnable)
            $valeur = [string](Get-RegValeur $cle 'DirectXUserGlobalSettings')
            $valeur = ($valeur -replace 'SwapEffectUpgradeEnable=\d;?', '').Trim()
            if ($valeur -and -not $valeur.EndsWith(';')) { $valeur += ';' }
            Set-RegValeur $cle 'DirectXUserGlobalSettings' ($valeur + 'SwapEffectUpgradeEnable=1;') 'String'
            'Activées (à la prochaine ouverture des jeux)'
        }
    }

    @{
        Id = 'PERF_ECRAN_HZ'; Categorie = 'Performances'; Titre = "Régler l'écran à sa fréquence maximale"
        Impact = 'Élevé'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique)'
        Description = "Un écran 144/165/240 Hz est souvent laissé à 60 Hz par Windows. Le logiciel choisit la fréquence la plus haute proposée par le pilote pour ta résolution actuelle, la teste puis l'applique. L'écran clignote une seconde. Si la fréquence maximale reste basse, vérifie que l'écran est branché sur la carte graphique avec un câble DisplayPort ou HDMI 2.0+."
        Verifier = {
            param($D)
            $ecrans = @(Get-EtatEcrans)   # lecture en direct : l'état a pu changer depuis l'analyse
            if ($ecrans.Count -eq 0) { return New-Resultat 'Non applicable' 'Aucun écran détecté' }
            $sousMax = @($ecrans | Where-Object { $_.Actuelle -lt $_.Max })
            if ($sousMax.Count -gt 0) { New-Resultat 'Recommandé' (($sousMax | ForEach-Object { "Écran $($_.Numero) : $($_.Actuelle) Hz alors que $($_.Max) Hz est possible" }) -join ' ; ') }
            else { New-Resultat 'OK' (($ecrans | ForEach-Object { "Écran $($_.Numero) : $($_.Actuelle) Hz (maximum)" }) -join ' ; ') }
        }
        Appliquer = {
            param($D)
            $modifies = 0
            foreach ($e in @(Get-EtatEcrans | Where-Object { $_.Actuelle -lt $_.Max })) {
                Add-ActionAnnulable ([ordered]@{ Type = 'Ecran'; Peripherique = $e.Peripherique; Frequence = $e.Actuelle })
                Set-FrequenceEcran -Peripherique $e.Peripherique -Frequence $e.Max
                $modifies++
            }
            "$modifies écran(s) réglé(s) au maximum"
        }
    }

    @{
        Id = 'PERF_SOURIS'; Categorie = 'Performances'; Titre = "Désactiver l'accélération de la souris"
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false
        Reversible = 'Oui (onglet Historique) — effectif après déconnexion'
        Description = "Désactive « Améliorer la précision du pointeur ». Le déplacement du curseur devient proportionnel au mouvement de la souris : indispensable pour viser de façon régulière dans les jeux de tir."
        Verifier = {
            param($D)
            if ((Get-RegValeur 'HKCU:\Control Panel\Mouse' 'MouseSpeed') -ne '0') { New-Resultat 'Optionnel' 'Accélération active — recommandé pour les FPS' }
            else { New-Resultat 'OK' 'Accélération désactivée' }
        }
        Appliquer = {
            param($D)
            Set-RegValeur 'HKCU:\Control Panel\Mouse' 'MouseSpeed' '0' 'String'
            Set-RegValeur 'HKCU:\Control Panel\Mouse' 'MouseThreshold1' '0' 'String'
            Set-RegValeur 'HKCU:\Control Panel\Mouse' 'MouseThreshold2' '0' 'String'
            'Désactivée (après déconnexion)'
        }
    }

    @{
        Id = 'PERF_VISUELS'; Categorie = 'Performances'; Titre = 'Alléger les effets visuels'
        Impact = 'Faible'; Risque = 'Aucun'; Manuel = $false
        Reversible = 'Oui (onglet Historique) — effectif après déconnexion'
        Description = "Coupe la transparence et les animations de fenêtres et de barre des tâches. L'interface paraît plus vive, mais le gain réel n'existe que sur les PC modestes (peu de RAM ou sans carte graphique dédiée)."
        Verifier = {
            param($D)
            $transparence = Get-RegValeur 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'EnableTransparency'
            $animations   = Get-RegValeur $script:RegAvance 'TaskbarAnimations'
            if ($transparence -eq 0 -and $animations -eq 0) { return New-Resultat 'OK' 'Effets déjà allégés' }
            $pcModeste = $D.RamGo -lt 8 -or -not ($D.Gpus | Where-Object { $_.Marque -in @('NVIDIA', 'AMD') })
            if ($pcModeste) { New-Resultat 'Recommandé' 'Utile sur ce PC' } else { New-Resultat 'Optionnel' 'Gain négligeable sur ce PC, question de goût' }
        }
        Appliquer = {
            param($D)
            Set-RegValeur 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'EnableTransparency' 0
            Set-RegValeur $script:RegAvance 'TaskbarAnimations' 0
            Set-RegValeur 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' '0' 'String'
            'Effets allégés (après déconnexion)'
        }
    }

    @{
        Id = 'PERF_TRIM'; Categorie = 'Performances'; Titre = 'Activer le TRIM des SSD'
        Impact = 'Élevé'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique)'
        Description = "Le TRIM permet au SSD de garder ses performances et sa durée de vie. Il est actif par défaut ; cette tâche le réactive s'il a été coupé."
        Verifier = {
            param($D)
            if (-not $D.ASsd) { return New-Resultat 'Non applicable' 'Aucun SSD détecté' }
            if ($D.TrimDesactive) { New-Resultat 'Recommandé' 'TRIM désactivé' } else { New-Resultat 'OK' 'TRIM actif' }
        }
        Appliquer = {
            param($D)
            # On relit l'état RÉEL : si le TRIM était déjà actif, aucune annulation
            # n'est enregistrée (sinon « Annuler » le désactiverait, à l'inverse du but)
            $etat = Invoke-Commande 'fsutil.exe' @('behavior', 'query', 'DisableDeleteNotify')
            if ($etat -notmatch 'NTFS DisableDeleteNotify\s*=\s*([01])') { throw 'État TRIM NTFS inconnu.' }
            if ($Matches[1] -eq '0') { return 'TRIM déjà actif' }
            Add-ActionAnnulable ([ordered]@{ Type = 'Trim'; Valeur = 1 })
            Invoke-Commande 'fsutil.exe' @('behavior', 'set', 'DisableDeleteNotify', 'NTFS', '0') | Out-Null
            'TRIM NTFS activé'
        }
    }

    @{
        Id = 'PERF_OPTIM_DISQUES'; Categorie = 'Performances'; Titre = 'Optimiser les disques maintenant'
        Impact = 'Faible'; Risque = 'Aucun'; Manuel = $false
        Reversible = 'Sans objet (opération de maintenance)'
        Description = "Lance l'outil Windows d'optimisation : TRIM pour les SSD, défragmentation pour les disques durs. Windows le fait normalement chaque semaine ; utile surtout si la tâche planifiée a été désactivée. Peut être long sur un disque dur."
        Verifier = {
            param($D)
            $tache = Get-ScheduledTask -TaskPath '\Microsoft\Windows\Defrag\' -TaskName 'ScheduledDefrag' -ErrorAction SilentlyContinue
            if ($tache -and $tache.State -eq 'Disabled') { New-Resultat 'Recommandé' "L'optimisation automatique hebdomadaire est désactivée" }
            else { New-Resultat 'Optionnel' 'Optimisation automatique déjà active' }
        }
        Appliquer = {
            param($D)
            $echecs = New-Object System.Collections.ArrayList
            foreach ($volume in $D.Volumes) {
                Write-Progression "Optimisation du lecteur $($volume.Lettre): …"
                $code = Start-ProcessAvecInterface 'defrag.exe' "$($volume.Lettre): /O"
                if ($code -ne 0) { [void]$echecs.Add("$($volume.Lettre): (code $code)") }
            }
            if ($echecs.Count -gt 0) { throw "Optimisation incomplète : $($echecs -join ', ')" }
            'Disques optimisés'
        }
    }

    # =================================================================
    #  ACTIONS MANUELLES (matériel, pilotes, maintenance)
    # =================================================================
    @{
        Id = 'MAN_XMP'; Categorie = 'Manuel'; Titre = 'Activer le profil XMP / EXPO de la RAM'
        Impact = 'Élevé'; Risque = 'Faible'; Manuel = $true
        Reversible = 'Oui (désactiver le profil dans le BIOS)'
        Description = "La RAM démarre à une vitesse de base prudente tant que son profil n'est pas activé. Vérifie la vitesse annoncée de ton kit (ex. DDR5-6000). Au démarrage du PC, appuie sur Suppr ou F2 pour entrer dans le BIOS, cherche « EXPO » (AMD) ou « XMP » (Intel) et active le profil 1, puis enregistre (F10). Gain fréquent de 5 à 15 % d'images/seconde sur Ryzen. Si le PC devient instable, remets le réglage sur « Auto »."
        Verifier = {
            param($D)
            if ($D.EstPortable) { return New-Resultat 'Non applicable' 'Non réglable sur un portable' }
            if ($D.XmpSuspect) { New-Resultat 'Manuel' "$($D.RamType) à $($D.RamVitesse) MHz — profil probablement inactif" }
            elseif ($D.XmpAVerifier) { New-Resultat 'Optionnel' "$($D.RamType) à $($D.RamVitesse) MHz — à vérifier si ta RAM est vendue pour une vitesse supérieure (inscrite sur la barrette ou la boîte)" }
            else { New-Resultat 'OK' "$($D.RamType) à $($D.RamVitesse) MHz" }
        }
    }

    @{
        Id = 'MAN_PILOTE_GPU'; Categorie = 'Manuel'; Titre = 'Mettre à jour le pilote graphique'
        Impact = 'Moyen'; Risque = 'Faible'; Manuel = $true
        Reversible = 'Oui (réinstaller la version précédente)'
        Description = "Les pilotes récents corrigent des bugs et améliorent les performances des jeux récents. Télécharge-les uniquement depuis le site du fabricant (AMD Adrenalin, NVIDIA App, Intel)."
        Verifier = {
            param($D)
            $anciens = @($D.Gpus | Where-Object { $_.PiloteAncien })   # seuil défini dans Diagnostic.ps1
            if ($anciens.Count -gt 0) { New-Resultat 'Manuel' (($anciens | ForEach-Object { "$($_.Nom) : pilote de $($_.AgePilote) jours" }) -join ' ; ') }
            else { New-Resultat 'OK' 'Pilote(s) récent(s)' }
        }
        Ouvrir = {
            param($D)
            $marques = @($D.Gpus | ForEach-Object { $_.Marque })
            if ($marques -contains 'NVIDIA') { Start-Process 'https://www.nvidia.com/fr-fr/software/nvidia-app/' }
            elseif ($marques -contains 'AMD') { Start-Process 'https://www.amd.com/fr/support/download/drivers.html' }
            else { Start-Process 'https://www.intel.fr/content/www/fr/fr/support/detect.html' }
        }
    }

    @{
        Id = 'MAN_REDEMARRER'; Categorie = 'Manuel'; Titre = 'Redémarrer le PC'
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $true
        Reversible = 'Sans objet'
        Description = "Avec le « démarrage rapide » de Windows, « Arrêter » ne remet pas le système à zéro : seul « Redémarrer » le fait. Un redémarrage hebdomadaire libère la mémoire et termine les mises à jour."
        Verifier = {
            param($D)
            if ($D.RedemarrageEnAttente) { New-Resultat 'Manuel' 'Une mise à jour attend un redémarrage' }
            elseif ($D.JoursAllume -gt 7) { New-Resultat 'Manuel' "Pas de redémarrage depuis $($D.JoursAllume) jours" }
            else { New-Resultat 'OK' "Dernier démarrage il y a $($D.JoursAllume) jour(s)" }
        }
    }

    @{
        Id = 'MAN_ESPACE'; Categorie = 'Manuel'; Titre = 'Libérer de la place sur un disque presque plein'
        Impact = 'Élevé'; Risque = 'Aucun'; Manuel = $true
        Reversible = 'Sans objet'
        Description = "Un disque rempli à plus de 85-90 % ralentit fortement (surtout un SSD). Désinstalle les jeux inutilisés, déplace vidéos et photos vers un autre disque, et active l'Assistant de stockage."
        Verifier = {
            param($D)
            $pleins = @($D.Volumes | Where-Object { $_.LibrePct -lt 15 })
            if ($pleins.Count -gt 0) { New-Resultat 'Manuel' (($pleins | ForEach-Object { "$($_.Lettre): $($_.LibrePct) % libres" }) -join ' ; ') }
            else { New-Resultat 'OK' 'Espace libre suffisant' }
        }
        Ouvrir = { param($D) Start-Process 'ms-settings:storagesense' }
    }

    @{
        Id = 'MAN_SANTE_DISQUE'; Categorie = 'Manuel'; Titre = "Sauvegarder les données d'un disque en mauvaise santé"
        Impact = 'Élevé'; Risque = 'Aucun'; Manuel = $true
        Reversible = 'Sans objet'
        Description = "Windows signale un disque en mauvaise santé. Copie tes fichiers importants ailleurs sans attendre, puis vérifie le disque avec l'outil du fabricant (ou CrystalDiskInfo) avant de le remplacer."
        Verifier = {
            param($D)
            if ($D.DisquesEnDanger.Count -gt 0) { New-Resultat 'Manuel' (($D.DisquesEnDanger | ForEach-Object { "$($_.FriendlyName) : $($_.Sante)" }) -join ' ; ') }
            else { New-Resultat 'OK' 'Tous les disques sont sains' }
        }
    }

    @{
        Id = 'SYS_ECHANGE'; Categorie = 'Performances'; Titre = "Réactiver le fichier d'échange"
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true; Redemarrage = $true
        Reversible = 'Oui (page Historique)'
        Description = "Sans fichier d'échange, certains jeux gourmands plantent même avec beaucoup de RAM. Le logiciel remet la gestion automatique de Windows (effective après redémarrage)."
        Verifier = {
            param($D)
            $systeme = Get-CimInstance Win32_ComputerSystem
            if ($systeme.AutomaticManagedPagefile) { return New-Resultat 'OK' 'Géré automatiquement par Windows' }
            if ($D.FichierEchangeAbsent) { New-Resultat 'Recommandé' "Aucun fichier d'échange" } else { New-Resultat 'OK' 'Taille réglée manuellement' }
        }
        Appliquer = {
            param($D)
            $systeme = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
            $avant = [bool]$systeme.AutomaticManagedPagefile
            # Les tailles réglées à la main sont effacées par la gestion automatique :
            # on les sauvegarde d'abord pour que l'annulation puisse les remettre
            $cleMemoire = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
            $pagingAvant = Get-RegValeur $cleMemoire 'PagingFiles'
            if ($null -ne $pagingAvant) {
                Add-ActionAnnulable ([ordered]@{ Type = 'Registre'; Chemin = $cleMemoire; Nom = 'PagingFiles'; Existait = $true
                        TypeValeur = 'MultiString'; Valeur = [string[]]@($pagingAvant) })
            }
            Add-ActionAnnulable ([ordered]@{ Type = 'Echange'; Automatique = $avant })
            Set-CimInstance -InputObject $systeme -Property @{ AutomaticManagedPagefile = $true } -ErrorAction Stop
            'Gestion automatique activée (après redémarrage)'
        }
    }

    @{
        Id = 'MAN_HVCI'; Categorie = 'Manuel'; Titre = "Intégrité de la mémoire (sécurité vs performances)"
        Impact = 'Faible'; Risque = 'Moyen'; Manuel = $true
        Reversible = 'Oui'
        Description = "Cette protection bloque des pilotes malveillants mais peut coûter quelques % d'images/seconde. Elle est à laisser ACTIVÉE dans la plupart des cas ; ne la désactive que si tu mesures un vrai gain dans tes jeux et acceptes la baisse de sécurité. Certains anti-triche l'exigent."
        Verifier = {
            param($D)
            if ($D.HvciActif) { New-Resultat 'Optionnel' 'Activée — à conserver sauf besoin précis' } else { New-Resultat 'OK' 'Désactivée' }
        }
        Ouvrir = { param($D) Start-Process 'windowsdefender://coreisolation' }
    }

    # =================================================================
    #  CONFIDENTIALITÉ & RÉSEAU
    # =================================================================
    @{
        Id = 'PRIV_TELEMETRIE'; Categorie = 'Confidentialité'; Titre = 'Réduire la télémétrie de Windows'
        Impact = 'Faible'; Risque = 'Faible'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique)'
        Description = "Désactive le service « Expériences des utilisateurs connectés et télémétrie » (DiagTrack) et les expériences personnalisées basées sur tes données de diagnostic. Windows Update continue de fonctionner normalement."
        Verifier = {
            param($D)
            $start = Get-ServiceStart 'DiagTrack'
            if ($null -eq $start) { return New-Resultat 'Non applicable' 'Service absent' }
            if ($start -ne 4) { New-Resultat 'Recommandé' 'Télémétrie active' } else { New-Resultat 'OK' 'Télémétrie réduite' }
        }
        Appliquer = {
            param($D)
            Set-ServiceDemarrage -Nom 'DiagTrack' -Mode 'Desactive'
            Set-RegValeur 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' 'TailoredExperiencesWithDiagnosticDataEnabled' 0
            'Télémétrie réduite'
        }
    }

    @{
        Id = 'PRIV_PUB'; Categorie = 'Confidentialité'; Titre = 'Supprimer les publicités et suggestions de Windows'
        Impact = 'Faible'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique)'
        Description = "Coupe l'identifiant publicitaire, les applis sponsorisées installées automatiquement, les suggestions du menu Démarrer, les « conseils » et les pubs de l'Explorateur de fichiers."
        Verifier = {
            param($D)
            $pubActive = (Get-RegValeur 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled') -ne 0 -or
                         (Get-RegValeur $script:RegCDM 'SilentInstalledAppsEnabled') -ne 0 -or
                         (Get-RegValeur $script:RegCDM 'SubscribedContent-338388Enabled') -ne 0
            if ($pubActive) { New-Resultat 'Recommandé' 'Publicités et suggestions actives' } else { New-Resultat 'OK' 'Déjà désactivées' }
        }
        Appliquer = {
            param($D)
            Set-RegValeur 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled' 0
            foreach ($nom in @('SilentInstalledAppsEnabled', 'SystemPaneSuggestionsEnabled', 'SoftLandingEnabled',
                    'SubscribedContent-310093Enabled', 'SubscribedContent-338388Enabled', 'SubscribedContent-338389Enabled',
                    'SubscribedContent-338393Enabled', 'SubscribedContent-353694Enabled', 'SubscribedContent-353696Enabled')) {
                Set-RegValeur $script:RegCDM $nom 0
            }
            Set-RegValeur $script:RegAvance 'ShowSyncProviderNotifications' 0
            if ($D.EstWin11) { Set-RegValeur $script:RegAvance 'Start_IrisRecommendations' 0 }
            'Publicités et suggestions désactivées'
        }
    }

    @{
        Id = 'PRIV_BING'; Categorie = 'Confidentialité'; Titre = 'Retirer les résultats Bing du menu Démarrer'
        Impact = 'Faible'; Risque = 'Aucun'; Manuel = $false
        Reversible = 'Oui (onglet Historique) — effectif après déconnexion'
        Description = "La recherche du menu Démarrer ne montre plus que tes applis, fichiers et paramètres : plus rapide et sans envoi de ta saisie à Bing. Tu perds la recherche web depuis le menu Démarrer. Ce réglage passe par une stratégie : Windows peut afficher « Certains paramètres sont gérés par votre organisation », c'est normal."
        Verifier = {
            param($D)
            if ((Get-RegValeur 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions') -eq 1) { New-Resultat 'OK' 'Bing déjà retiré' }
            else { New-Resultat 'Optionnel' 'Résultats web Bing actifs' }
        }
        Appliquer = {
            param($D)
            Set-RegValeur 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'BingSearchEnabled' 0
            Set-RegValeur 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions' 1
            'Bing retiré (après déconnexion)'
        }
    }

    @{
        Id = 'RES_PARTAGE_MAJ'; Categorie = 'Réseau'; Titre = 'Ne plus envoyer les mises à jour à des PC sur Internet'
        Impact = 'Moyen'; Risque = 'Aucun'; Manuel = $false; Auto = $true
        Reversible = 'Oui (page Historique)'
        Description = "L'Optimisation de la distribution peut utiliser ta connexion pour envoyer des morceaux de mises à jour à d'autres PC sur Internet. Cette tâche limite le partage à ton réseau local."
        Verifier = {
            param($D)
            $mode = Get-RegValeur 'Registry::HKEY_USERS\S-1-5-20\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings' 'DownloadMode'
            if ($mode -eq 3) { New-Resultat 'Recommandé' 'Partage avec Internet actif' }
            elseif ($null -eq $mode) { New-Resultat 'Optionnel' 'Réglage par défaut (non défini)' }
            else { New-Resultat 'OK' 'Partage limité ou désactivé' }
        }
        Appliquer = {
            param($D)
            Set-RegValeur 'Registry::HKEY_USERS\S-1-5-20\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings' 'DownloadMode' 1
            'Partage limité au réseau local'
        }
    }

    @{
        Id = 'RES_DNS'; Categorie = 'Réseau'; Titre = 'Utiliser un DNS rapide (Cloudflare 1.1.1.1)'
        Impact = 'Faible'; Risque = 'Faible'; Manuel = $false
        Reversible = 'Oui (page Historique)'
        Description = "Remplace les DNS IPv4 et IPv6 de la box par ceux de Cloudflare. Peut accélérer légèrement l'ouverture des sites. N'améliore PAS le ping en jeu. À éviter si ta box fournit des services qui dépendent du DNS de l'opérateur (TV, contrôle parental de la box)."
        Verifier = {
            param($D)
            $cartes = Get-CartesReseauActives
            if ($cartes.Count -eq 0) { return New-Resultat 'Non applicable' 'Aucune carte réseau connectée' }
            $v4 = @($cartes | ForEach-Object { (Get-DnsClientServerAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses })
            $v6 = @($cartes | ForEach-Object { (Get-DnsClientServerAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv6 -ErrorAction SilentlyContinue).ServerAddresses } | Where-Object { $_ -notlike 'fec0:*' })
            $v4Ok = $v4 -contains '1.1.1.1'
            $v6Ok = ($v6.Count -eq 0) -or ($v6 -contains '2606:4700:4700::1111')
            if ($v4Ok -and $v6Ok) { return New-Resultat 'OK' 'Cloudflare déjà utilisé' }
            $detail = 'DNS actuel : ' + ((@($v4) + @($v6) | Select-Object -Unique) -join ', ')
            New-Resultat 'Optionnel' $detail
        }
        Appliquer = {
            param($D)
            foreach ($carte in (Get-CartesReseauActives)) {
                # Mémorise pour chaque famille si les DNS étaient saisis à la main (statiques) ou automatiques
                $nsV4 = Get-RegValeur "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($carte.InterfaceGuid)" 'NameServer'
                $nsV6 = Get-RegValeur "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces\$($carte.InterfaceGuid)" 'NameServer'
                $sauvegarde = [ordered]@{
                    Type       = 'Dns'
                    Index      = $carte.ifIndex
                    StatiqueV4 = -not [string]::IsNullOrWhiteSpace($nsV4)
                    StatiqueV6 = -not [string]::IsNullOrWhiteSpace($nsV6)
                    ServeursV4 = @((Get-DnsClientServerAddress -InterfaceIndex $carte.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses)
                    ServeursV6 = @((Get-DnsClientServerAddress -InterfaceIndex $carte.ifIndex -AddressFamily IPv6 -ErrorAction SilentlyContinue).ServerAddresses)
                }
                Add-ActionAnnulable $sauvegarde
                Set-DnsClientServerAddress -InterfaceIndex $carte.ifIndex -ErrorAction Stop `
                    -ServerAddresses @('1.1.1.1', '1.0.0.1', '2606:4700:4700::1111', '2606:4700:4700::1001')
                Write-Journal "DNS Cloudflare (IPv4 + IPv6) appliqué sur $($carte.Name)"
            }
            Clear-DnsClientCache -ErrorAction SilentlyContinue
            'DNS Cloudflare appliqué (IPv4 + IPv6)'
        }
    }
)

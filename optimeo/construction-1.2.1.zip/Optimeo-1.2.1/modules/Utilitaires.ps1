﻿# =====================================================================
#  Utilitaires.ps1
#  ---------------------------------------------------------------------
#  Fonctions communes utilisées par tous les modules :
#    - dossiers de données et journal (avec rotation)
#    - rafraîchissement de l'interface et exécution en arrière-plan
#      (évite l'état « Ne répond pas » de Windows)
#    - écriture SÉCURISÉE du registre et des services : l'état précédent
#      est mémorisé et toute erreur est remontée (jamais de faux succès)
#    - enregistrement / annulation des sauvegardes (fichiers JSON)
#    - création d'un point de restauration Windows
#    - mesure et nettoyage de dossiers (sans suivre les liens symboliques)
#  Aucune dépendance vers l'interface : celle-ci s'abonne via
#  $script:CallbackStatut et $script:Fenetre (tous deux facultatifs).
#  Compatible Windows PowerShell 5.1.
# =====================================================================

# ---------------------------------------------------------------------
#  Dossiers de données
# ---------------------------------------------------------------------
#  Les sauvegardes sont relues PUIS RÉÉCRITES EN ADMINISTRATEUR lors d'une
#  annulation : elles sont donc rangées dans %ProgramData%\Optimeo, en écriture
#  réservée aux administrateurs (un programme sans droits ne peut pas les
#  falsifier). Les anciennes copies dans le profil utilisateur restent sur disque.
$script:DossierDonnees = Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'Optimeo'
$script:DossierSauvegardes = Join-Path $script:DossierDonnees 'sauvegardes'
$script:FichierJournal = Join-Path $script:DossierDonnees 'journal.log'
$script:TailleMaxJournal = 1MB

function Assert-FichierProtege {
    param([string]$Chemin)
    $item = Get-Item -LiteralPath $Chemin -Force -ErrorAction Stop
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Lien refusé : $Chemin" }
    $acl = Get-Acl -LiteralPath $Chemin -ErrorAction Stop
    $sid = [Security.Principal.SecurityIdentifier]
    $admin = @('S-1-5-32-544', 'S-1-5-18')
    if ($acl.GetOwner($sid).Value -notin $admin) { throw "Propriétaire non autorisé : $Chemin" }
    $ecriture = [Security.AccessControl.FileSystemRights]'Write,Delete,DeleteSubdirectoriesAndFiles,ChangePermissions,TakeOwnership'
    foreach ($regle in $acl.GetAccessRules($true, $true, $sid)) {
        if ($regle.AccessControlType -eq 'Allow' -and ($regle.FileSystemRights -band $ecriture) -and $regle.IdentityReference.Value -notin $admin) {
            throw "Droits d’écriture non protégés : $Chemin"
        }
    }
}

function Initialize-DossierDonnees {
    $droits = New-Object Security.AccessControl.DirectorySecurity
    $droits.SetAccessRuleProtection($true, $false)
    $administrateurs = New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
    $droits.SetOwner($administrateurs)
    foreach ($compte in @('S-1-5-32-544', 'S-1-5-18', 'S-1-5-32-545')) {
        $acces = if ($compte -eq 'S-1-5-32-545') { 'ReadAndExecute' } else { 'FullControl' }
        $droits.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule(
            (New-Object Security.Principal.SecurityIdentifier($compte)), $acces, 'ContainerInherit,ObjectInherit', 'None', 'Allow')))
    }
    foreach ($dossier in @($script:DossierDonnees, $script:DossierSauvegardes)) {
        if (-not (Test-Path -LiteralPath $dossier)) { [IO.Directory]::CreateDirectory($dossier, $droits) | Out-Null }
        Assert-FichierProtege $dossier
    }
    foreach ($nom in @('journal.log', 'journal.old.log')) {
        $fichier = Join-Path $script:DossierDonnees $nom
        if (Test-Path -LiteralPath $fichier) { Assert-FichierProtege $fichier }
    }
}
try { Initialize-DossierDonnees }
catch {
    # Un ancien dossier peut appartenir au compte personnel. On le conserve
    # intact et on crée un emplacement protégé pour les nouvelles opérations.
    $script:DossierDonnees = Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'Optimeo-Historique'
    $script:DossierSauvegardes = Join-Path $script:DossierDonnees 'sauvegardes'
    $script:FichierJournal = Join-Path $script:DossierDonnees 'journal.log'
    Initialize-DossierDonnees
}

# Liste des modifications réversibles effectuées pendant l'application
# d'UNE tâche. Vidée avant chaque tâche, puis enregistrée en JSON.
$script:ActionsEnCours = New-Object System.Collections.ArrayList

# Expression régulière d'un GUID (plans d'alimentation…)
$script:RegexGuid = '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'

# Fonction d'affichage de l'avancement, fournie par l'interface (facultative)
$script:CallbackStatut = $null

# ---------------------------------------------------------------------
#  Journal
# ---------------------------------------------------------------------
function Write-Journal {
    <# Ajoute une ligne horodatée dans journal.log.
       Au-delà de 1 Mo, l'ancien journal est renommé journal.old.log. #>
    param(
        [string]$Message,
        [ValidateSet('INFO', 'ATTENTION', 'ERREUR')][string]$Niveau = 'INFO'
    )
    $ligne = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Niveau, $Message
    try {
        $fichier = Get-Item -LiteralPath $script:FichierJournal -ErrorAction SilentlyContinue
        if ($fichier -and $fichier.Length -gt $script:TailleMaxJournal) {
            Move-Item -LiteralPath $script:FichierJournal -Destination ($script:FichierJournal -replace '\.log$', '.old.log') -Force -ErrorAction Stop
        }
        Add-Content -LiteralPath $script:FichierJournal -Value $ligne -Encoding UTF8 -ErrorAction Stop
    }
    catch { }   # le journal ne doit jamais bloquer le programme
}

# ---------------------------------------------------------------------
#  Interface : rafraîchissement, statut, arrière-plan
# ---------------------------------------------------------------------
function Update-Interface {
    <# Laisse WPF redessiner la fenêtre et traiter les événements pendant
       un traitement long (sinon Windows la marque « Ne répond pas »). #>
    if ($script:Fenetre) {
        $script:Fenetre.Dispatcher.Invoke([Action] { }, [Windows.Threading.DispatcherPriority]::Background)
    }
}

function Write-Progression {
    <# Affiche un texte d'avancement si l'interface en fournit le moyen #>
    param([string]$Texte)
    if ($script:CallbackStatut) { & $script:CallbackStatut $Texte } else { Update-Interface }
}

function Invoke-EnArrierePlan {
    <# Exécute un scriptblock AUTONOME dans un runspace séparé, en gardant
       l'interface réactive. Le scriptblock ne voit ni les fonctions ni les
       variables du projet : tout ce dont il a besoin passe par -Arguments.
       Une erreur dans le scriptblock est relancée ici.
       -DelaiSecondes : abandon au bout de ce délai (0 = sans limite) ; évite
       qu'une commande Windows bloquée fige l'application indéfiniment. #>
    param([Parameter(Mandatory)][scriptblock]$Script, [object[]]$Arguments = @(), [int]$DelaiSecondes = 0)
    $ps = [PowerShell]::Create()
    try {
        [void]$ps.AddScript($Script.ToString())
        foreach ($argument in $Arguments) { [void]$ps.AddArgument($argument) }
        $handle = $ps.BeginInvoke()
        $chrono = [Diagnostics.Stopwatch]::StartNew()
        while (-not $handle.IsCompleted) {
            if ($DelaiSecondes -gt 0 -and $chrono.Elapsed.TotalSeconds -gt $DelaiSecondes) {
                try { $ps.Stop() } catch { }
                throw "Opération interrompue : aucune réponse de Windows après $DelaiSecondes secondes."
            }
            Update-Interface
            Start-Sleep -Milliseconds 100
        }
        try { $resultat = $ps.EndInvoke($handle) }
        catch {
            # Relance l'erreur d'origine plutôt que l'enveloppe « EndInvoke »
            $origine = $_.Exception
            while ($origine.InnerException) { $origine = $origine.InnerException }
            throw $origine
        }
        if ($ps.Streams.Error.Count -gt 0) { throw $ps.Streams.Error[0].Exception }
        return $resultat
    }
    finally { $ps.Dispose() }
}

function Start-ProcessAvecInterface {
    <# Lance un programme externe (dism, defrag, désinstalleur…) et attend sa
       fin tout en gardant l'interface réactive. Renvoie le code de sortie.
       -Style Normal : pour un désinstalleur, dont la fenêtre doit rester
       visible (sinon l'utilisateur ne peut pas répondre à ses questions).
       -DelaiSecondes : abandon de l'attente au-delà (0 = sans limite) ; le
       programme continue de tourner, l'application reprend la main. #>
    param([string]$Programme, [string]$Arguments, [ValidateSet('Hidden', 'Normal')][string]$Style = 'Hidden', [int]$DelaiSecondes = 0)
    $parametres = @{ FilePath = $Programme; WindowStyle = $Style; PassThru = $true }
    # PowerShell 5.1 refuse -ArgumentList vide : on ne le passe que s'il y a des arguments
    if ($Arguments -and $Arguments.Trim()) { $parametres.ArgumentList = $Arguments }
    $processus = Start-Process @parametres
    $null = $processus.Handle   # nécessaire pour pouvoir lire ExitCode ensuite
    $chrono = [Diagnostics.Stopwatch]::StartNew()
    while (-not $processus.HasExited) {
        if ($DelaiSecondes -gt 0 -and $chrono.Elapsed.TotalSeconds -gt $DelaiSecondes) {
            throw "$Programme n'a pas répondu en $DelaiSecondes secondes : termine l'opération dans sa fenêtre, puis relance une analyse."
        }
        Update-Interface
        Start-Sleep -Milliseconds 200
    }
    return $processus.ExitCode
}

function Invoke-ProgrammeTexte {
    <# Lance un programme en console (winget…) et renvoie ses lignes de sortie
       décodées en UTF-8, SANS console : c'est indispensable car Optimeo.exe est
       compilé sans console, où « [Console]::OutputEncoding = … » lève l'erreur
       « Descripteur non valide ». Renvoie { Lignes ; Code }. #>
    param([Parameter(Mandatory)][string]$Programme, [string]$Arguments = '', [int]$DelaiSecondes = 300)
    $chemin = (Get-Command $Programme -ErrorAction Stop).Source
    $infos = New-Object Diagnostics.ProcessStartInfo
    $infos.FileName = $chemin
    $infos.Arguments = $Arguments
    $infos.UseShellExecute = $false
    $infos.CreateNoWindow = $true
    $infos.RedirectStandardOutput = $true
    $infos.RedirectStandardError = $true
    $infos.StandardOutputEncoding = New-Object Text.UTF8Encoding $false
    $infos.StandardErrorEncoding = New-Object Text.UTF8Encoding $false
    $processus = New-Object Diagnostics.Process
    $processus.StartInfo = $infos
    [void]$processus.Start()
    # Lecture asynchrone : évite le blocage si le tampon de sortie se remplit
    $lectureSortie = $processus.StandardOutput.ReadToEndAsync()
    $lectureErreur = $processus.StandardError.ReadToEndAsync()
    $chrono = [Diagnostics.Stopwatch]::StartNew()
    while (-not $processus.HasExited) {
        if ($chrono.Elapsed.TotalSeconds -gt $DelaiSecondes) {
            try { $processus.Kill() } catch { }
            throw "$Programme n'a pas répondu en $DelaiSecondes secondes."
        }
        Update-Interface
        Start-Sleep -Milliseconds 150
    }
    $texte = ($lectureSortie.Result + "`n" + $lectureErreur.Result)
    $code = $processus.ExitCode
    $processus.Dispose()
    # Retire les caractères de progression de winget (barres, curseurs)
    $texte = $texte -replace '\r[^\n]*\r', ''
    return [pscustomobject]@{ Lignes = @($texte -split "`r?`n"); Code = $code }
}

function Invoke-Commande {
    <# Lance un programme en ligne de commande (sc, powercfg, fsutil) et
       lève une erreur si son code de sortie n'est pas 0.
       PowerShell 5.1 ne le fait pas tout seul. Renvoie la sortie texte. #>
    param([Parameter(Mandatory)][string]$Programme, [string[]]$Arguments = @())
    # En PS 5.1, « 2>&1 » + ErrorActionPreference=Stop transforme la moindre
    # ligne d'erreur en exception : on juge uniquement sur le code de sortie.
    $ErrorActionPreference = 'Continue'
    $sortie = & $Programme @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw ('{0} {1} a échoué (code {2}) : {3}' -f $Programme, ($Arguments -join ' '), $LASTEXITCODE, (($sortie | Out-String).Trim()))
    }
    return (($sortie | Out-String).Trim())
}

# ---------------------------------------------------------------------
#  Résultat d'une vérification de tâche
# ---------------------------------------------------------------------
function New-Resultat {
    <# États possibles :
         Recommandé     -> gain réel attendu, coché par défaut
         Optionnel      -> utile selon l'usage, non coché
         OK             -> déjà optimisé
         Manuel         -> action à faire soi-même (BIOS, pilote…)
         Non applicable -> ne concerne pas ce PC #>
    param(
        [ValidateSet('Recommandé', 'Optionnel', 'OK', 'Manuel', 'Non applicable')][string]$Etat,
        [string]$Detail = ''
    )
    [pscustomobject]@{ Etat = $Etat; Detail = $Detail }
}

# ---------------------------------------------------------------------
#  Registre (lecture / écriture avec sauvegarde)
# ---------------------------------------------------------------------
function Get-RegValeur {
    <# Lit une valeur de registre ; renvoie $null si absente.
       La virgule (« return , ») empêche PowerShell de découper les valeurs
       binaires (byte[]) en une liste d'octets séparés. #>
    param([string]$Chemin, [string]$Nom)
    try { return , (Get-ItemProperty -Path $Chemin -Name $Nom -ErrorAction Stop).$Nom } catch { return $null }
}

function Set-RegValeur {
    <# Écrit une valeur de registre. L'ancienne valeur (ou son absence) est
       enregistrée sur disque avant l’écriture.
       Toute erreur (accès refusé…) est remontée à l'appelant. #>
    param(
        [Parameter(Mandatory)][string]$Chemin,
        [Parameter(Mandatory)][string]$Nom,
        [Parameter(Mandatory)]$Valeur,
        [ValidateSet('DWord', 'QWord', 'String', 'ExpandString', 'MultiString', 'Binary')][string]$Type = 'DWord'
    )
    $sauvegarde = [ordered]@{ Type = 'Registre'; Chemin = $Chemin; Nom = $Nom; Existait = $false; Valeur = $null; TypeValeur = $null }

    if (Test-Path -Path $Chemin) {
        $cle = Get-Item -Path $Chemin -ErrorAction Stop
        if ($cle.GetValueNames() -contains $Nom) {
            $sauvegarde.Existait   = $true
            $sauvegarde.TypeValeur = $cle.GetValueKind($Nom).ToString()
            $sauvegarde.Valeur     = $cle.GetValue($Nom, $null, 'DoNotExpandEnvironmentNames')
        }
    }
    Add-ActionAnnulable $sauvegarde
    if (-not (Test-Path -LiteralPath $Chemin)) {
        New-Item -Path $Chemin -Force -ErrorAction Stop | Out-Null
    }

    New-ItemProperty -Path $Chemin -Name $Nom -Value $Valeur -PropertyType $Type -Force -ErrorAction Stop | Out-Null
    Write-Journal "Registre : $Chemin\$Nom = $Valeur"
}

# ---------------------------------------------------------------------
#  Services (mode de démarrage avec sauvegarde)
# ---------------------------------------------------------------------
function Get-ServiceStart {
    <# Renvoie la valeur « Start » d'un service (2 auto, 3 manuel, 4 désactivé) ou $null s'il n'existe pas #>
    param([string]$Nom)
    return Get-RegValeur "HKLM:\SYSTEM\CurrentControlSet\Services\$Nom" 'Start'
}

function Set-ServiceDemarrage {
    <# Change le mode de démarrage d'un service après lecture de l'ancien mode.
       Erreur remontée si sc.exe échoue. #>
    param(
        [Parameter(Mandatory)][string]$Nom,
        [ValidateSet('Desactive', 'Manuel', 'Automatique')][string]$Mode
    )
    $cheminReg = "HKLM:\SYSTEM\CurrentControlSet\Services\$Nom"
    if (-not (Test-Path $cheminReg)) { Write-Journal "Service absent : $Nom" 'ATTENTION'; return }

    $sauvegarde = [ordered]@{
        Type             = 'Service'
        Nom              = $Nom
        Start            = Get-RegValeur $cheminReg 'Start'
        DelayedAutostart = Get-RegValeur $cheminReg 'DelayedAutostart'
    }
    Add-ActionAnnulable $sauvegarde
    $modeSc = @{ Desactive = 'disabled'; Manuel = 'demand'; Automatique = 'auto' }[$Mode]
    Invoke-Commande 'sc.exe' @('config', $Nom, 'start=', $modeSc) | Out-Null
    if ($Mode -eq 'Desactive') { Stop-Service -Name $Nom -Force -ErrorAction SilentlyContinue }
    Write-Journal "Service $Nom -> $Mode"
}

function Add-ActionAnnulable {
    param([System.Collections.IDictionary]$Action)
    if (-not $script:FichierAction -or -not $script:TacheEnCours) { throw 'Aucune tâche en cours.' }
    [void]$script:ActionsEnCours.Add($Action)
    $contenu = [ordered]@{
        TacheId = $script:TacheEnCours.Id
        Titre = $script:TacheEnCours.Titre
        Date = (Get-Date -Format 'dd/MM/yyyy HH:mm:ss')
        Actions = @($script:ActionsEnCours)
    }
    $temporaire = $script:FichierAction + '.tmp'
    try {
        $json = ConvertTo-Json -InputObject $contenu -Depth 8 -ErrorAction Stop
        [IO.File]::WriteAllText($temporaire, $json, [Text.Encoding]::UTF8)
        if ([IO.File]::Exists($script:FichierAction)) {
            [IO.File]::Replace($temporaire, $script:FichierAction, [Management.Automation.Language.NullString]::Value)
        }
        else { [IO.File]::Move($temporaire, $script:FichierAction) }
    }
    catch {
        $script:ActionsEnCours.RemoveAt($script:ActionsEnCours.Count - 1)
        throw "Enregistrement de l’historique impossible. Réglage interrompu. $($_.Exception.Message)"
    }
    finally { if ([IO.File]::Exists($temporaire)) { [IO.File]::Delete($temporaire) } }
}

function Get-Sauvegardes {
    <# Liste les sauvegardes encore annulables (plus récentes en premier) #>
    Get-ChildItem -Path $script:DossierSauvegardes -Filter '*.json' -File -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending |
        ForEach-Object {
            try {
                Assert-FichierProtege $_.FullName
                $s = Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
                [pscustomobject]@{ Fichier = $_.FullName; Date = $s.Date; Titre = $s.Titre; NbActions = @($s.Actions).Count }
            }
            catch { Write-Journal "Sauvegarde illisible ignorée : $($_.Exception.Message)" 'ATTENTION' }
        }
}

function Restore-Action {
    <# Remet UNE action dans son état d'origine. Toute erreur est remontée. #>
    param($Action)
    switch ($Action.Type) {
        'Registre' {
            # Garde-fou : une sauvegarde ne doit désigner que le registre local
            if ($Action.Chemin -notmatch '^(HKLM|HKCU|HKU):\\' -and $Action.Chemin -ne 'Registry::HKEY_USERS\S-1-5-20\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings') { throw "Chemin de registre inattendu dans la sauvegarde : $($Action.Chemin)" }
            if ($Action.Existait) {
                if (-not (Test-Path $Action.Chemin)) { New-Item -Path $Action.Chemin -Force -ErrorAction Stop | Out-Null }
                $valeur = $Action.Valeur
                if ($Action.TypeValeur -eq 'Binary')      { $valeur = [byte[]]@($valeur) }
                if ($Action.TypeValeur -eq 'MultiString') { $valeur = [string[]]@($valeur) }
                New-ItemProperty -Path $Action.Chemin -Name $Action.Nom -Value $valeur -PropertyType $Action.TypeValeur -Force -ErrorAction Stop | Out-Null
            }
            elseif ($null -ne (Get-RegValeur $Action.Chemin $Action.Nom)) {
                Remove-ItemProperty -Path $Action.Chemin -Name $Action.Nom -ErrorAction Stop
            }
        }
        'Service' {
            $modeSc = switch ([int]$Action.Start) { 2 { 'auto' } 3 { 'demand' } 4 { 'disabled' } default { $null } }
            if ($modeSc) {
                if ($modeSc -eq 'auto' -and [int]$Action.DelayedAutostart -eq 1) { $modeSc = 'delayed-auto' }
                Invoke-Commande 'sc.exe' @('config', $Action.Nom, 'start=', $modeSc) | Out-Null
                if ($modeSc -like '*auto') { Start-Service -Name $Action.Nom -ErrorAction SilentlyContinue }
            }
        }
        'PlanAlimentation' { Invoke-Commande 'powercfg.exe' @('/setactive', $Action.Guid) | Out-Null }
        'Trim' { Invoke-Commande 'fsutil.exe' @('behavior', 'set', 'DisableDeleteNotify', 'NTFS', "$($Action.Valeur)") | Out-Null }
        'Dns' {
            # On repart des réglages automatiques, puis on remet les éventuels DNS saisis à la main
            Set-DnsClientServerAddress -InterfaceIndex $Action.Index -ResetServerAddresses -ErrorAction Stop
            if ($Action.StatiqueV4 -and @($Action.ServeursV4).Count -gt 0) {
                Set-DnsClientServerAddress -InterfaceIndex $Action.Index -ServerAddresses @($Action.ServeursV4) -ErrorAction Stop
            }
            if ($Action.StatiqueV6 -and @($Action.ServeursV6).Count -gt 0) {
                Set-DnsClientServerAddress -InterfaceIndex $Action.Index -ServerAddresses @($Action.ServeursV6) -ErrorAction Stop
            }
            Clear-DnsClientCache -ErrorAction SilentlyContinue
        }
        'Demarrage' { Set-EtatDemarrage -Type $Action.TypeEntree -Cible $Action.Cible -Nom $Action.Nom -Actif $true }
        'Ecran' { Set-FrequenceEcran -Peripherique $Action.Peripherique -Frequence ([int]$Action.Frequence) }
        'Echange' {
            $systeme = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
            Set-CimInstance -InputObject $systeme -Property @{ AutomaticManagedPagefile = [bool]$Action.Automatique } -ErrorAction Stop
        }
        default { throw "Type d'action inconnu : $($Action.Type)" }
    }
    Write-Journal "Annulation : $($Action.Type) $($Action.Chemin) $($Action.Nom)"
}

function Undo-Sauvegarde {
    <# Annule toutes les actions d'une sauvegarde (dans l'ordre inverse).
       Si tout a réussi, le fichier est renommé en .annule (trace conservée) ;
       sinon il reste dans l'historique pour pouvoir réessayer.
       Renvoie le nombre d'erreurs. #>
    param([string]$Fichier)
    if ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Fichier)) -ne $script:DossierSauvegardes -or [IO.Path]::GetExtension($Fichier) -ne '.json') { throw "Sauvegarde hors historique." }
    Assert-FichierProtege $Fichier
    $sauvegarde = Get-Content -LiteralPath $Fichier -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
    $actions = @($sauvegarde.Actions)
    [array]::Reverse($actions)
    $erreurs = 0
    foreach ($action in $actions) {
        try { Restore-Action $action }
        catch { $erreurs++; Write-Journal "Échec annulation ($($action.Type) $($action.Nom)) : $($_.Exception.Message)" 'ERREUR' }
    }
    if ($erreurs -eq 0) {
        Move-Item -LiteralPath $Fichier -Destination ($Fichier -replace '\.json$', '.annule') -Force -ErrorAction Stop
    }
    return $erreurs
}

# ---------------------------------------------------------------------
#  Point de restauration Windows
# ---------------------------------------------------------------------
function New-PointRestauration {
    <# Crée un point de restauration (en arrière-plan : peut durer une minute).
       Active la protection système sur le disque Windows si nécessaire et
       lève temporairement la limite « 1 point par 24 h ». Renvoie $true si réussi. #>
    $cle = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    $ancienneFrequence = Get-RegValeur $cle 'SystemRestorePointCreationFrequency'
    try {
        New-ItemProperty -Path $cle -Name 'SystemRestorePointCreationFrequency' -Value 0 -PropertyType DWord -Force -ErrorAction Stop | Out-Null
        Invoke-EnArrierePlan -DelaiSecondes 300 -Arguments @("$env:SystemDrive\") -Script {
            param($lecteur)
            Enable-ComputerRestore -Drive $lecteur -ErrorAction Stop
            Checkpoint-Computer -Description 'Optimeo - avant optimisation' -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop
        } | Out-Null
        Write-Journal 'Point de restauration créé'
        return $true
    }
    catch {
        Write-Journal "Point de restauration impossible : $($_.Exception.Message)" 'ERREUR'
        return $false
    }
    finally {
        if ($null -eq $ancienneFrequence) { Remove-ItemProperty -Path $cle -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue }
        else { New-ItemProperty -Path $cle -Name 'SystemRestorePointCreationFrequency' -Value $ancienneFrequence -PropertyType DWord -Force -ErrorAction SilentlyContinue | Out-Null }
    }
}

# ---------------------------------------------------------------------
#  Fichiers et dossiers
# ---------------------------------------------------------------------
function Get-FichiersSansLiens {
    <# Parcourt un dossier récursivement SANS suivre les jonctions ni les
       liens symboliques (évite de toucher des fichiers hors du dossier).
       -AvecDossiers : renvoie aussi les sous-dossiers parcourus.
       Rafraîchit l'interface régulièrement (gros dossiers). #>
    param([string]$Chemin, [switch]$AvecDossiers)
    if (-not (Test-Path -LiteralPath $Chemin -ErrorAction SilentlyContinue)) { return }   # absent ou inaccessible
    $racine = Get-Item -LiteralPath $Chemin -Force -ErrorAction Stop
    if (-not $racine.PSIsContainer -or -not $racine.Parent) { return }
    for ($parent = $racine; $null -ne $parent; $parent = $parent.Parent) {
        if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { return }
    }
    $pile = New-Object System.Collections.Stack
    $pile.Push($Chemin)
    $compteur = 0
    while ($pile.Count -gt 0) {
        $courant = $pile.Pop()
        foreach ($element in (Get-ChildItem -LiteralPath $courant -Force -ErrorAction SilentlyContinue)) {
            if ((++$compteur % 500) -eq 0) { Update-Interface }
            if ($element.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
            if ($element.PSIsContainer) {
                if (-not ($element.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
                    $pile.Push($element.FullName)
                    if ($AvecDossiers) { $element }
                }
            }
            else { $element }
        }
    }
}

function Get-TailleDossiers {
    <# Taille totale (octets) d'un ou plusieurs dossiers.
       -ExclureNoms : noms de fichiers à ignorer (ex. desktop.ini, toujours
       présent dans la corbeille, qui empêcherait l'état « vide »).
       -AgeMinimumHeures : ne compte que les fichiers plus vieux que N heures
       (même règle que Clear-Dossier, pour que la vérification et le nettoyage
       mesurent exactement la même chose). #>
    param([string[]]$Chemins, [string[]]$ExclureNoms = @(), [int]$AgeMinimumHeures = 0)
    [int64]$total = 0
    $limite = (Get-Date).AddHours(-$AgeMinimumHeures)
    foreach ($chemin in $Chemins) {
        foreach ($fichier in (Get-FichiersSansLiens $chemin)) {
            if ($ExclureNoms -contains $fichier.Name) { continue }
            if ($AgeMinimumHeures -gt 0 -and @($fichier.LastWriteTime, $fichier.CreationTime, $fichier.LastAccessTime | Sort-Object -Descending)[0] -gt $limite) { continue }
            $total += $fichier.Length
        }
    }
    return $total
}

function Clear-Dossier {
    <# Supprime le CONTENU d'un dossier (pas le dossier lui-même).
       -AgeMinimumHeures : conserve les fichiers plus récents (0 = tout).
       Les fichiers utilisés par un programme ouvert ne peuvent pas être
       supprimés : ils sont comptés pour l'expliquer dans le rapport.
       Renvoie un objet { Libere (octets) ; Verrouilles (nombre) ; TailleVerrouilles (octets) }. #>
    param([string]$Chemin, [int]$AgeMinimumHeures = 0)
    $resultat = [pscustomobject]@{ Libere = [int64]0; Verrouilles = 0; TailleVerrouilles = [int64]0 }
    if (-not (Test-Path -LiteralPath $Chemin)) { return $resultat }
    $limite = (Get-Date).AddHours(-$AgeMinimumHeures)

    $elements = @(Get-FichiersSansLiens $Chemin -AvecDossiers)
    $compteur = 0
    foreach ($fichier in ($elements | Where-Object { -not $_.PSIsContainer })) {
        if ((++$compteur % 200) -eq 0) { Update-Interface }
        # Date la plus récente des trois : un fichier extrait d'une archive garde
        # sa date d'origine, mais vient peut-être d'être créé sur le disque
        $dateFichier = @($fichier.LastWriteTime, $fichier.CreationTime, $fichier.LastAccessTime | Sort-Object -Descending)[0]
        if ($dateFichier -gt $limite) { continue }
        $taille = $fichier.Length
        try {
            # Retire l'attribut lecture seule qui bloque certaines suppressions
            if ($fichier.Attributes -band [IO.FileAttributes]::ReadOnly) { $fichier.Attributes = $fichier.Attributes -bxor [IO.FileAttributes]::ReadOnly }
            Remove-Item -LiteralPath $fichier.FullName -Force -ErrorAction Stop
            $resultat.Libere += $taille
        }
        catch {
            $resultat.Verrouilles++
            $resultat.TailleVerrouilles += $taille
        }
    }
    # Supprime ensuite les sous-dossiers devenus vides (les plus profonds d'abord)
    $dossiers = $elements | Where-Object { $_.PSIsContainer } | Sort-Object { $_.FullName.Length } -Descending
    foreach ($dossier in $dossiers) {
        if (-not (Get-ChildItem -LiteralPath $dossier.FullName -Force -ErrorAction SilentlyContinue)) {
            # [IO.Directory]::Delete : jamais de question de confirmation, même
            # si un fichier réapparaît entre-temps (Remove-Item en poserait une)
            try { [IO.Directory]::Delete($dossier.FullName, $false) } catch { }
        }
    }
    return $resultat
}

function Format-Nettoyage {
    <# Texte de compte rendu d'un ou plusieurs résultats de Clear-Dossier #>
    param([object[]]$Resultats)
    $libere = [int64](($Resultats | Measure-Object -Property Libere -Sum).Sum)
    $verrouilles = [int](($Resultats | Measure-Object -Property Verrouilles -Sum).Sum)
    $tailleVerrouilles = [int64](($Resultats | Measure-Object -Property TailleVerrouilles -Sum).Sum)
    $texte = "$(Format-Taille $libere) libérés"
    if ($verrouilles -gt 0) { $texte += " ; $verrouilles fichier(s) utilisés par un programme ouvert conservés ($(Format-Taille $tailleVerrouilles))" }
    return $texte
}

function Format-Taille {
    <# Affiche une taille en Ko / Mo / Go #>
    param([double]$Octets)
    if ($Octets -ge 1GB) { return '{0:N1} Go' -f ($Octets / 1GB) }
    if ($Octets -ge 1MB) { return '{0:N0} Mo' -f ($Octets / 1MB) }
    return '{0:N0} Ko' -f ($Octets / 1KB)
}

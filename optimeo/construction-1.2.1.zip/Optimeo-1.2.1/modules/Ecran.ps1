﻿# =====================================================================
#  Ecran.ps1
#  ---------------------------------------------------------------------
#  Lecture et réglage de la fréquence de rafraîchissement des écrans
#  via l'API Windows (user32.dll), comme le panneau « Affichage avancé ».
#    - Get-EtatEcrans           : fréquence actuelle / maximale par écran
#    - Set-FrequenceEcran       : applique une fréquence (testée avant)
#  Seuls les modes proposés par le pilote pour la résolution actuelle
#  sont utilisés (jamais de mode entrelacé ni de résolution différente).
# =====================================================================

if (-not ('OptimEcran' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class OptimEcran
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct DEVMODE
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
        public short dmSpecVersion; public short dmDriverVersion; public short dmSize; public short dmDriverExtra;
        public int dmFields;
        public int dmPositionX; public int dmPositionY; public int dmDisplayOrientation; public int dmDisplayFixedOutput;
        public short dmColor; public short dmDuplex; public short dmYResolution; public short dmTTOption; public short dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel; public int dmPelsWidth; public int dmPelsHeight;
        public int dmDisplayFlags; public int dmDisplayFrequency;
        public int dmICMMethod; public int dmICMIntent; public int dmMediaType; public int dmDitherType;
        public int dmReserved1; public int dmReserved2; public int dmPanningWidth; public int dmPanningHeight;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct DISPLAY_DEVICE
    {
        public int cb;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
        public int StateFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool EnumDisplayDevices(string device, uint num, ref DISPLAY_DEVICE dd, uint flags);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool EnumDisplaySettings(string device, int mode, ref DEVMODE dm);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int ChangeDisplaySettingsEx(string device, ref DEVMODE dm, IntPtr hwnd, uint flags, IntPtr param);

    const int ENUM_CURRENT_SETTINGS = -1;
    const int ATTACHED_TO_DESKTOP = 0x1;
    const int DM_INTERLACED = 0x2;
    const int DM_DISPLAYFREQUENCY = 0x400000;
    const uint CDS_UPDATEREGISTRY = 0x1;
    const uint CDS_TEST = 0x2;

    static DEVMODE NouveauMode() { DEVMODE dm = new DEVMODE(); dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE)); return dm; }

    // Liste des écrans actifs : "\\.\DISPLAY1|Nom de la carte graphique"
    public static string[] Ecrans()
    {
        var liste = new System.Collections.Generic.List<string>();
        for (uint i = 0; ; i++)
        {
            DISPLAY_DEVICE dd = new DISPLAY_DEVICE(); dd.cb = Marshal.SizeOf(dd);
            if (!EnumDisplayDevices(null, i, ref dd, 0)) break;
            if ((dd.StateFlags & ATTACHED_TO_DESKTOP) != 0) liste.Add(dd.DeviceName + "|" + dd.DeviceString);
        }
        return liste.ToArray();
    }

    // Mode actuel : largeur, hauteur, fréquence
    public static int[] ModeActuel(string ecran)
    {
        DEVMODE dm = NouveauMode();
        if (!EnumDisplaySettings(ecran, ENUM_CURRENT_SETTINGS, ref dm)) return null;
        return new int[] { dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency };
    }

    // Fréquence maximale proposée pour la résolution et la profondeur de couleur actuelles
    public static int FrequenceMax(string ecran)
    {
        DEVMODE actuel = NouveauMode();
        if (!EnumDisplaySettings(ecran, ENUM_CURRENT_SETTINGS, ref actuel)) return 0;
        int max = 0;
        for (int i = 0; ; i++)
        {
            DEVMODE dm = NouveauMode();
            if (!EnumDisplaySettings(ecran, i, ref dm)) break;
            if (dm.dmPelsWidth == actuel.dmPelsWidth && dm.dmPelsHeight == actuel.dmPelsHeight &&
                dm.dmBitsPerPel == actuel.dmBitsPerPel && (dm.dmDisplayFlags & DM_INTERLACED) == 0 &&
                dm.dmDisplayFrequency > max) max = dm.dmDisplayFrequency;
        }
        return max;
    }

    // Applique une fréquence : test préalable puis enregistrement. 0 = succès.
    public static int AppliquerFrequence(string ecran, int frequence)
    {
        DEVMODE dm = NouveauMode();
        if (!EnumDisplaySettings(ecran, ENUM_CURRENT_SETTINGS, ref dm)) return -100;
        dm.dmDisplayFrequency = frequence;
        dm.dmFields = DM_DISPLAYFREQUENCY;
        int test = ChangeDisplaySettingsEx(ecran, ref dm, IntPtr.Zero, CDS_TEST, IntPtr.Zero);
        if (test != 0) return test;
        return ChangeDisplaySettingsEx(ecran, ref dm, IntPtr.Zero, CDS_UPDATEREGISTRY, IntPtr.Zero);
    }
}
'@
}

function Get-EtatEcrans {
    <# Renvoie un objet par écran actif : Peripherique, Carte, Largeur, Hauteur, Actuelle, Max #>
    $numero = 0
    foreach ($entree in [OptimEcran]::Ecrans()) {
        $numero++
        $peripherique, $carte = $entree -split '\|', 2
        $mode = [OptimEcran]::ModeActuel($peripherique)
        if (-not $mode) { continue }
        [pscustomobject]@{
            Numero       = $numero
            Peripherique = $peripherique
            Carte        = $carte
            Largeur      = $mode[0]
            Hauteur      = $mode[1]
            Actuelle     = $mode[2]
            Max          = [OptimEcran]::FrequenceMax($peripherique)
        }
    }
}

function Set-FrequenceEcran {
    <# Applique une fréquence à un écran ; erreur si Windows la refuse #>
    param([Parameter(Mandatory)][string]$Peripherique, [Parameter(Mandatory)][int]$Frequence)
    $code = [OptimEcran]::AppliquerFrequence($Peripherique, $Frequence)
    if ($code -ne 0) { throw "Windows a refusé $Frequence Hz sur $Peripherique (code $code)" }
    Write-Journal "Écran $Peripherique réglé à $Frequence Hz"
}

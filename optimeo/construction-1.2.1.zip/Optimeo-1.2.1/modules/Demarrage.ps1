﻿# =====================================================================
#  Demarrage.ps1
#  ---------------------------------------------------------------------
#  Gestion des programmes lancés au démarrage de Windows.
#  Sources lues (comme le Gestionnaire des tâches, et un peu plus) :
#    - clés Run du registre (utilisateur, tous, 32 bits)
#    - dossiers « Démarrage »
#    - applications du Microsoft Store (StartupTask : Teams, Copilot…)
#    - tâches planifiées non Microsoft lancées à l'ouverture de session
#      ou au démarrage (mises à jour, utilitaires constructeurs…)
#  Rien n'est jamais supprimé : on active / désactive seulement, avec les
#  mêmes mécanismes que Windows. Tout est réversible.
# =====================================================================

$script:BaseApprouve = 'Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved'
$script:BaseStore    = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData'

# Emplacements « classiques » lus par Windows au démarrage
$script:SourcesDemarrage = @(
    @{ Emplacement = 'Registre (utilisateur)';          Cle = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run';             Approuve = "HKCU:\$script:BaseApprouve\Run" }
    @{ Emplacement = 'Registre (tous)';                 Cle = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run';             Approuve = "HKLM:\$script:BaseApprouve\Run" }
    @{ Emplacement = 'Registre (tous, 32 bits)';        Cle = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'; Approuve = "HKLM:\$script:BaseApprouve\Run32" }
    @{ Emplacement = 'Dossier Démarrage (utilisateur)'; Dossier = [Environment]::GetFolderPath('Startup');       Approuve = "HKCU:\$script:BaseApprouve\StartupFolder" }
    @{ Emplacement = 'Dossier Démarrage (tous)';        Dossier = [Environment]::GetFolderPath('CommonStartup'); Approuve = "HKLM:\$script:BaseApprouve\StartupFolder" }
)

# Entrées à ne désactiver qu'en connaissance de cause : motif (nom ou commande) -> conséquence
$script:EntreesSensibles = [ordered]@{
    'SecurityHealth'                                      = "Icône et alertes de Sécurité Windows (la protection antivirus reste active)"
    'RtkAud|Realtek'                                      = 'Service audio Realtek : détection des prises jack, réglages audio'
    'Waves|Nahimic|DolbyAudio'                            = 'Traitement audio du fabricant (effets, micro)'
    'iCUE|Corsair'                                        = 'Corsair iCUE : courbes de ventilateurs / pompe et éclairage'
    'LGHUB|Logitech'                                      = 'Logitech G HUB : profils de souris et clavier (DPI, macros)'
    'Synaptics|SynTP|ELAN'                                = 'Pilote du pavé tactile'
    'OneDrive'                                            = 'Synchronisation OneDrive arrêtée tant que tu ne l''ouvres pas'
    'StartCN|StartDVR|StartAUEP|AMDNoiseSuppression|Radeon' = 'AMD Adrenalin : profils personnalisés de la carte graphique, capture, suppression de bruit'
}

function Get-AvertissementDemarrage {
    <# Renvoie la conséquence connue d'une désactivation, ou '' #>
    param([string]$Nom, [string]$Commande)
    foreach ($motif in $script:EntreesSensibles.Keys) {
        if ($Nom -match $motif -or $Commande -match $motif) { return $script:EntreesSensibles[$motif] }
    }
    return ''
}

function New-EntreeDemarrage {
    <# Crée un objet uniforme pour toutes les sources #>
    param([string]$Nom, [string]$Commande, [string]$Emplacement, [string]$Type, [string]$Cible, [bool]$Actif, [bool]$Modifiable = $true)
    [pscustomobject]@{
        Nom           = $Nom
        Commande      = $Commande
        Emplacement   = $Emplacement
        Type          = $Type        # Registre | Store | Tache
        Cible         = $Cible       # clé StartupApproved, clé StartupTask ou chemin de tâche planifiée
        Actif         = $Actif
        Modifiable    = $Modifiable
        Avertissement = Get-AvertissementDemarrage $Nom $Commande
    }
}

function Test-EntreeActive {
    <# Une entrée Run / dossier est désactivée si la valeur StartupApproved
       existe et que son premier octet est impair (03 ou 07). #>
    param([string]$CleApprouve, [string]$Nom)
    $octets = Get-RegValeur $CleApprouve $Nom
    if ($octets -is [byte[]] -and $octets.Length -gt 0) { return (($octets[0] -band 1) -eq 0) }
    return $true
}

function Get-ProgrammesDemarrage {
    <# Renvoie la liste complète des programmes au démarrage (actifs et désactivés) #>
    $liste = New-Object System.Collections.ArrayList

    # --- Registre et dossiers Démarrage ---
    foreach ($source in $script:SourcesDemarrage) {
        if ($source.Cle) {
            if (-not (Test-Path $source.Cle)) { continue }
            $cle = Get-Item -Path $source.Cle
            foreach ($nom in $cle.GetValueNames()) {
                if ([string]::IsNullOrEmpty($nom)) { continue }
                [void]$liste.Add((New-EntreeDemarrage -Nom $nom -Commande ([string]$cle.GetValue($nom)) -Emplacement $source.Emplacement `
                            -Type 'Registre' -Cible $source.Approuve -Actif (Test-EntreeActive $source.Approuve $nom)))
            }
        }
        elseif ($source.Dossier -and (Test-Path -LiteralPath $source.Dossier)) {
            foreach ($fichier in (Get-ChildItem -LiteralPath $source.Dossier -File -Force -ErrorAction SilentlyContinue)) {
                if ($fichier.Name -ieq 'desktop.ini') { continue }
                [void]$liste.Add((New-EntreeDemarrage -Nom $fichier.Name -Commande $fichier.FullName -Emplacement $source.Emplacement `
                            -Type 'Registre' -Cible $source.Approuve -Actif (Test-EntreeActive $source.Approuve $fichier.Name)))
            }
        }
    }

    # --- Applications du Microsoft Store ---
    # State : 0 désactivé par défaut, 1 désactivé par l'utilisateur, 2 activé, 3/4 imposé par une stratégie
    if (Test-Path $script:BaseStore) {
        $paquets = @{}
        foreach ($p in (Get-AppxPackage -ErrorAction SilentlyContinue)) { $paquets[$p.PackageFamilyName] = $p.Name }
        foreach ($famille in (Get-ChildItem -Path $script:BaseStore -ErrorAction SilentlyContinue)) {
            if (-not $paquets.ContainsKey($famille.PSChildName)) { continue }   # appli désinstallée
            foreach ($tache in (Get-ChildItem -Path $famille.PSPath -ErrorAction SilentlyContinue)) {
                $etat = Get-RegValeur $tache.PSPath 'State'
                if ($null -eq $etat) { continue }
                $nomAppli = $paquets[$famille.PSChildName] -replace '^(Microsoft|MicrosoftCorporationII)\.', ''
                [void]$liste.Add((New-EntreeDemarrage -Nom $nomAppli -Commande "$($famille.PSChildName) ($($tache.PSChildName))" `
                            -Emplacement 'Application du Store' -Type 'Store' -Cible $tache.PSPath `
                            -Actif ($etat -in @(2, 4)) -Modifiable ($etat -in @(0, 1, 2))))
            }
        }
    }

    # --- Tâches planifiées (hors Microsoft) à l'ouverture de session ou au démarrage ---
    foreach ($t in (Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -notlike '\Microsoft\*' })) {
        $auDemarrage = @($t.Triggers | Where-Object { $_.CimClass.CimClassName -in @('MSFT_TaskLogonTrigger', 'MSFT_TaskBootTrigger') })
        if ($auDemarrage.Count -eq 0) { continue }
        # Un déclencheur désactivé ne lance rien : la tâche est comptée comme inactive
        $declencheurActif = @($auDemarrage | Where-Object { $_.Enabled }).Count -gt 0
        $action = @($t.Actions)[0]
        $commande = if ($action -and $action.Execute) { ('{0} {1}' -f $action.Execute, $action.Arguments).Trim() } else { '' }
        [void]$liste.Add((New-EntreeDemarrage -Nom $t.TaskName -Commande $commande -Emplacement 'Tâche planifiée' `
                    -Type 'Tache' -Cible ($t.TaskPath + $t.TaskName) -Actif (($t.State -ne 'Disabled') -and $declencheurActif)))
    }

    return $liste
}

function Set-EtatDemarrage {
    <# Active ou désactive une entrée de démarrage selon son type.
       Toute erreur est remontée à l'appelant. #>
    param(
        [Parameter(Mandatory)][ValidateSet('Registre', 'Store', 'Tache')][string]$Type,
        [Parameter(Mandatory)][string]$Cible,
        [Parameter(Mandatory)][string]$Nom,
        [Parameter(Mandatory)][bool]$Actif
    )
    switch ($Type) {
        'Registre' {
            # 12 octets : 02 = activé, 03 = désactivé (même format que le Gestionnaire des tâches)
            if (-not (Test-Path $Cible)) { New-Item -Path $Cible -Force -ErrorAction Stop | Out-Null }
            $octets = New-Object byte[] 12
            $octets[0] = if ($Actif) { 2 } else { 3 }
            New-ItemProperty -Path $Cible -Name $Nom -Value $octets -PropertyType Binary -Force -ErrorAction Stop | Out-Null
        }
        'Store' {
            # 2 = activé, 1 = désactivé par l'utilisateur
            New-ItemProperty -Path $Cible -Name 'State' -Value $(if ($Actif) { 2 } else { 1 }) -PropertyType DWord -Force -ErrorAction Stop | Out-Null
        }
        'Tache' {
            $position = $Cible.LastIndexOf('\')
            $chemin = $Cible.Substring(0, $position + 1)
            $nomTache = $Cible.Substring($position + 1)
            if ($Actif) { Enable-ScheduledTask -TaskPath $chemin -TaskName $nomTache -ErrorAction Stop | Out-Null }
            else { Disable-ScheduledTask -TaskPath $chemin -TaskName $nomTache -ErrorAction Stop | Out-Null }
        }
    }
    Write-Journal ("Démarrage ({0}) : {1} -> {2}" -f $Type, $Nom, $(if ($Actif) { 'activé' } else { 'désactivé' }))
}

﻿# =====================================================================
#  Logiciels.ps1
#  ---------------------------------------------------------------------
#  Inventaire des logiciels et jeux installés, explication de ce que
#  c'est, et désinstallation VÉRIFIÉE.
#  Sources :
#    - Registre (programmes classiques, MSI ou EXE)
#    - Steam (manifestes appmanifest_*.acf de chaque bibliothèque)
#    - Epic Games (manifestes .item) : désinstallation directe, comme le launcher
#    - Xbox / PC Game Pass et applis du Microsoft Store (paquets Appx)
#  Chaque élément : Nom, Categorie, Description, Editeur, Version,
#  Octets, Date, Source, Cle, Dossier, Protege, Avertissement, Detail.
# =====================================================================

# ---------------------------------------------------------------------
#  Dictionnaire « C'est quoi ? »
#  M = motif (sur le nom), C = catégorie, D = description,
#  P = protégé (désinstallation bloquée), A = avertissement avant désinstallation
#  La PREMIÈRE règle qui correspond est utilisée.
# ---------------------------------------------------------------------
$script:ReglesLogiciels = @(
    # --- Ce logiciel ---
    @{ M = '^Optimeo$'; C = 'Utilitaire'; P = $true; D = "Ce logiciel. Pour le désinstaller : Paramètres > Applications > Applications installées > Optimeo." }

    # --- Composants système : protégés ---
    @{ M = 'Visual C\+\+.*Redistributable'; C = 'Système'; P = $true; D = "Bibliothèques Microsoft utilisées par de nombreux jeux et logiciels. Chaque version sert à des programmes différents." }
    @{ M = '^Microsoft (\.NET|ASP\.NET|Windows Desktop Runtime)'; C = 'Système'; P = $true; D = ".NET : moteur nécessaire à de nombreux logiciels (outils AMD, GIGABYTE, Unity…)." }
    @{ M = 'DirectX'; C = 'Système'; P = $true; D = "Composants graphiques utilisés par les jeux." }
    @{ M = 'WebView2'; C = 'Système'; P = $true; D = "Moteur web intégré utilisé par de nombreuses applis (Teams, Widgets…)." }
    @{ M = '^Microsoft Edge$'; C = 'Navigateur'; P = $true; D = "Navigateur intégré à Windows : il ne peut pas être désinstallé proprement." }
    @{ M = 'Compatibility Fix Database|Update Health Tools|^Windows Subsystem|Microsoft Store$|^Store$|App Installer|Xbox Identity|Store Purchase|Windows Security|Sécurité Windows'; C = 'Système'; P = $true; D = "Composant de Windows." }
    @{ M = 'Microsoft GameInput'; C = 'Système'; P = $true; D = "Gère manettes et périphériques de jeu pour les jeux récents." }
    @{ M = 'Steamworks Common Redistributables'; C = 'Système'; P = $true; D = "Bibliothèques partagées nécessaires aux jeux Steam." }
    @{ M = 'Epic Online Services'; C = 'Système'; A = "Des jeux Epic ou multijoueurs peuvent ne plus se lancer."; D = "Services en ligne (amis, succès, anti-triche) utilisés par les jeux Epic et d'autres jeux." }
    @{ M = 'EasyAntiCheat|BattlEye|Vanguard|PunkBuster'; C = 'Système'; A = "Les jeux en ligne qui l'utilisent ne se lanceront plus."; D = "Anti-triche requis par certains jeux en ligne." }
    @{ M = 'Rockstar Games SDK|Social Club'; C = 'Système'; A = "Les jeux Rockstar peuvent ne plus se lancer."; D = "Composant requis par les jeux Rockstar." }

    # --- Pilotes : protégés ---
    @{ M = 'Chipset'; C = 'Pilote'; P = $true; D = "Pilotes de la carte mère (gestion de l'énergie du processeur, USB…). Indispensable." }
    @{ M = '^Windows Driver Package'; C = 'Pilote'; P = $true; D = "Paquet de pilotes installé par un constructeur. À désinstaller seulement depuis le Gestionnaire de périphériques." }
    @{ M = 'Intel.*(Management Engine|Rapid Storage|Serial IO|Dynamic Platform)'; C = 'Pilote'; P = $true; D = "Composant bas niveau de la carte mère Intel." }
    @{ M = 'NVIDIA (HD Audio|PhysX|FrameView SDK)'; C = 'Pilote'; P = $true; D = "Composant installé avec le pilote NVIDIA." }
    @{ M = 'AMD (Ryzen Master|Chipset Software)'; C = 'Pilote'; P = $true; D = "Composant bas niveau de la plateforme AMD." }
    @{ M = 'Realtek.*Audio|High Definition Audio'; C = 'Pilote'; P = $true; D = "Pilote de la carte son." }
    @{ M = 'Realtek.*(Ethernet|LAN|Network)'; C = 'Pilote'; P = $true; D = "Pilote de la carte réseau filaire." }
    @{ M = 'Intel.*(Bluetooth|Wireless|Wi-?Fi)'; C = 'Pilote'; P = $true; D = "Pilote Bluetooth / Wi-Fi." }
    @{ M = '^AMD Software'; C = 'Pilote'; P = $true; D = "Pilote de ta carte graphique AMD et son panneau Adrenalin." }
    @{ M = '^NVIDIA (Graphics Driver|Pilote graphique)|^NVIDIA App'; C = 'Pilote'; P = $true; D = "Pilote de ta carte graphique NVIDIA et son panneau." }

    # --- Utilitaires matériel ---
    @{ M = 'AMD Install Manager'; C = 'Matériel'; D = "Installe et met à jour les composants AMD. Désinstallable si tu mets à jour via Adrenalin." }
    @{ M = 'AMD Chat'; C = 'Utilitaire'; D = "Assistant IA local d'AMD (plusieurs Go). Inutile si tu ne t'en sers pas." }
    @{ M = 'AMD Image Inspector'; C = 'Utilitaire'; D = "Outil AMD de comparaison de la qualité d'image. Rarement utile." }
    @{ M = 'AMD Privacy View'; C = 'Utilitaire'; D = "Floute l'écran quand tu t'éloignes (via la webcam). Rarement utile." }
    @{ M = 'Ryzen Master'; C = 'Matériel'; D = "Réglage et surveillance du processeur Ryzen (températures, undervolting)." }
    @{ M = 'GIGABYTE Control Center|^GBT_'; C = 'Matériel'; D = "Suite GIGABYTE : éclairage RGB, mises à jour de la carte mère. Les modules GBT_* en font partie." }
    @{ M = 'GIGABYTE (SSD|Storage|Wi-Fi Compass|Performance Library)'; C = 'Matériel'; D = "Module de GIGABYTE Control Center." }
    @{ M = 'Smart Backup'; C = 'Utilitaire'; D = "Logiciel de sauvegarde GIGABYTE. Inutile si tu ne l'utilises pas." }
    @{ M = 'iCUE|Corsair Device Control'; C = 'Matériel'; D = "Logiciel Corsair : éclairage, ventilateurs et périphériques Corsair. Inutile sans matériel Corsair." }
    @{ M = 'Logitech G HUB'; C = 'Matériel'; D = "Profils des souris, claviers et casques Logitech (DPI, macros, éclairage)." }
    @{ M = 'ASTRO Command Center'; C = 'Matériel'; D = "Réglages des casques ASTRO (égaliseur, micro)." }
    @{ M = 'Razer Synapse|SteelSeries|NGENUITY|Armoury Crate|MSI Center|Dragon Center|Samsung Magician|Crucial Storage'; C = 'Matériel'; D = "Logiciel du fabricant pour gérer ton matériel (réglages, éclairage, mises à jour)." }
    @{ M = 'HWiNFO|CPU-Z|GPU-Z|HWMonitor|CrystalDisk'; C = 'Utilitaire'; D = "Surveillance du matériel : températures, vitesses des ventilateurs, capteurs." }
    @{ M = 'Afterburner|RivaTuner'; C = 'Utilitaire'; D = "Overclocking de la carte graphique et affichage des FPS en jeu." }

    # --- Plateformes de jeux ---
    @{ M = '^Steam$'; C = 'Plateforme de jeux'; A = "Désinstaller Steam supprime aussi TOUS ses jeux."; D = "Boutique et lanceur de jeux de Valve." }
    @{ M = 'Epic Games Launcher'; C = 'Plateforme de jeux'; A = "Les jeux Epic ne pourront plus être lancés."; D = "Boutique et lanceur Epic Games (Fortnite, jeux gratuits de la semaine)." }
    @{ M = '^EA app$|^Origin$'; C = 'Plateforme de jeux'; A = "Les jeux EA (EA SPORTS FC, Battlefield…) ne pourront plus être lancés."; D = "Lanceur des jeux Electronic Arts." }
    @{ M = 'GOG GALAXY'; C = 'Plateforme de jeux'; D = "Lanceur GOG. Les jeux GOG (Cyberpunk 2077…) fonctionnent aussi sans lui." }
    @{ M = 'Ubisoft Connect|Uplay'; C = 'Plateforme de jeux'; A = "Les jeux Ubisoft ne pourront plus être lancés."; D = "Lanceur des jeux Ubisoft." }
    @{ M = 'Battle\.net'; C = 'Plateforme de jeux'; D = "Lanceur Blizzard / Activision (Diablo, Call of Duty…)." }
    @{ M = 'Rockstar Games Launcher'; C = 'Plateforme de jeux'; A = "Les jeux Rockstar ne pourront plus être lancés."; D = "Lanceur des jeux Rockstar (GTA, Red Dead Redemption)." }
    @{ M = 'Riot Client'; C = 'Plateforme de jeux'; D = "Lanceur Riot Games (League of Legends, Valorant)." }
    @{ M = '^Xbox$|GamingApp'; C = 'Plateforme de jeux'; A = "Les jeux Xbox / PC Game Pass ne pourront plus être lancés ni mis à jour."; D = "Appli Xbox : PC Game Pass et jeux du Microsoft Store." }

    # --- Communication, navigateurs ---
    @{ M = 'Discord'; C = 'Communication'; D = "Messagerie vocale et textuelle pour joueurs." }
    @{ M = 'Teams'; C = 'Communication'; D = "Messagerie et visioconférence Microsoft." }
    @{ M = 'Zoom|Skype|WhatsApp|Telegram|Signal|Messenger'; C = 'Communication'; D = "Messagerie / appels vidéo." }
    @{ M = 'Google Chrome|Firefox|Brave|Opera|Vivaldi'; C = 'Navigateur'; D = "Navigateur web." }

    # --- Création, développement ---
    @{ M = '^Blender'; C = 'Création'; D = "Logiciel 3D gratuit : modélisation, animation, rendu." }
    @{ M = 'CapCut'; C = 'Création'; D = "Logiciel de montage vidéo (ByteDance, créateur de TikTok)." }
    @{ M = 'DaVinci Resolve|Premiere|Vegas|Shotcut|Kdenlive'; C = 'Création'; D = "Logiciel de montage vidéo." }
    @{ M = 'OBS Studio|Streamlabs'; C = 'Création'; D = "Enregistrement d'écran et streaming." }
    @{ M = 'Audacity|FL Studio|Ableton|Reaper'; C = 'Création'; D = "Enregistrement et montage audio." }
    @{ M = 'Adobe|Photoshop|GIMP|Krita|Paint\.NET|Affinity|Canva|Figma'; C = 'Création'; D = "Retouche d'image / graphisme." }
    @{ M = 'Unreal Engine'; C = 'Création'; D = "Moteur de création de jeux d'Epic (très volumineux)." }
    @{ M = 'Quixel Bridge|Fab UE Plugin'; C = 'Création'; D = "Bibliothèque de modèles et textures pour Unreal Engine." }
    @{ M = '^Unity Hub'; C = 'Création'; D = "Gestionnaire des projets et versions de Unity." }
    @{ M = '^Unity '; C = 'Création'; D = "Éditeur Unity (moteur de création de jeux), une version par ligne." }
    @{ M = '^Twine'; C = 'Création'; D = "Outil d'écriture d'histoires interactives." }
    @{ M = 'yWriter'; C = 'Création'; D = "Logiciel d'aide à l'écriture de romans." }
    @{ M = 'Visual Studio Code'; C = 'Développement'; D = "Éditeur de code de Microsoft." }
    @{ M = 'Visual Studio (Community|Professional|Enterprise|Build Tools)'; C = 'Développement'; D = "Environnement de développement Microsoft (très volumineux)." }
    @{ M = '^Git$|GitHub Desktop'; C = 'Développement'; D = "Gestion de versions du code source." }
    @{ M = '^Python Launcher'; C = 'Développement'; D = "Lance la bonne version de Python (commande « py »)." }
    @{ M = '^Python'; C = 'Développement'; D = "Langage de programmation Python. Plusieurs versions peuvent cohabiter : garde celle que tes projets utilisent." }
    @{ M = 'Node\.js'; C = 'Développement'; D = "Environnement JavaScript pour le développement." }
    @{ M = 'Java|JDK|JRE|Temurin'; C = 'Développement'; D = "Java : nécessaire à certains logiciels et jeux (Minecraft Java…)." }

    # --- Bureautique, IA, utilitaires, sécurité ---
    @{ M = 'Microsoft 365|Office|Outlook|OneNote|LibreOffice|Word|Excel|PowerPoint'; C = 'Bureautique'; D = "Suite bureautique / messagerie." }
    @{ M = 'OneDrive'; C = 'Bureautique'; A = "Les fichiers déjà synchronisés restent en ligne mais ne se synchronisent plus."; D = "Synchronisation de fichiers dans le cloud Microsoft." }
    @{ M = 'Copilot'; C = 'Bureautique'; D = "Assistant IA de Microsoft." }
    @{ M = '^Claude$'; C = 'Bureautique'; D = "Application Claude (Anthropic)." }
    @{ M = 'ChatGPT|Codex'; C = 'Bureautique'; D = "Application d'IA d'OpenAI." }
    @{ M = '7-Zip|WinRAR|PeaZip|Bandizip'; C = 'Utilitaire'; D = "Compression / décompression d'archives (zip, rar…)." }
    @{ M = 'VLC|MPC-HC|PotPlayer'; C = 'Utilitaire'; D = "Lecteur vidéo." }
    @{ M = 'Notepad\+\+'; C = 'Utilitaire'; D = "Éditeur de texte." }
    @{ M = 'PowerToys'; C = 'Utilitaire'; D = "Outils Microsoft pour Windows (raccourcis, fenêtres, couleurs…)." }
    @{ M = 'CCleaner|Driver Booster|Advanced SystemCare|IObit'; C = 'Utilitaire'; D = "« Optimiseur » souvent inutile, parfois publicitaire. Désinstallation conseillée." }
    @{ M = 'qBittorrent|uTorrent|BitTorrent|Deluge'; C = 'Utilitaire'; D = "Téléchargement de fichiers en pair-à-pair (torrent)." }
    @{ M = 'AnyDesk|TeamViewer|Parsec|RustDesk'; C = 'Utilitaire'; D = "Contrôle d'un PC à distance. À désinstaller si tu ne l'utilises pas (sécurité)." }
    @{ M = 'Wallpaper Engine|Overwolf|Medal'; C = 'Utilitaire'; D = "Utilitaire pour joueurs (fonds animés, clips, overlays). Consomme des ressources en arrière-plan." }
    @{ M = 'Avast|AVG|Norton|McAfee|Avira|Kaspersky|Bitdefender|ESET|Total ?AV'; C = 'Sécurité'; D = "Antivirus tiers. Microsoft Defender suffit dans la plupart des cas ; ne garde qu'un seul antivirus." }
    @{ M = 'Malwarebytes'; C = 'Sécurité'; D = "Anti-malware complémentaire (analyse à la demande)." }
)

# Applications fournies avec Windows : identifiant du paquet -> description
$script:ApplisWindows = [ordered]@{
    'Microsoft.WindowsCalculator'        = 'Calculatrice.'
    'Microsoft.WindowsAlarms'            = 'Horloge : alarmes, minuteur, chronomètre.'
    'Microsoft.WindowsCamera'            = 'Application webcam.'
    'Microsoft.WindowsNotepad'           = 'Bloc-notes (éditeur de texte simple).'
    'Microsoft.Paint'                    = 'Paint : dessin simple.'
    'Microsoft.Windows.Photos'           = 'Visionneuse et retouche simple de photos.'
    'Microsoft.ScreenSketch'             = "Outil Capture d'écran (Win+Maj+S)."
    'Microsoft.WindowsSoundRecorder'     = 'Enregistreur vocal.'
    'Microsoft.ZuneMusic'                = 'Lecteur multimédia (musique et vidéo).'
    'Microsoft.MicrosoftStickyNotes'     = 'Pense-bêtes (notes sur le bureau).'
    'Microsoft.WindowsTerminal'          = 'Terminal : ligne de commande.'
    'Microsoft.Todos'                    = 'Microsoft To Do : listes de tâches.'
    'Microsoft.BingWeather'              = 'Météo.'
    'Microsoft.BingNews'                 = 'Actualités.'
    'Microsoft.GetHelp'                  = "Assistance Microsoft (« Obtenir de l'aide »)."
    'Microsoft.WindowsFeedbackHub'       = 'Envoi de commentaires à Microsoft. Inutile au quotidien.'
    'Microsoft.YourPhone'                = 'Mobile connecté : relie ton téléphone au PC (SMS, photos).'
    'Microsoft.PowerAutomateDesktop'     = "Automatisation de tâches répétitives. Rarement utile à la maison."
    'MicrosoftCorporationII.MicrosoftFamily' = 'Contrôle parental Microsoft Family.'
    'Clipchamp.Clipchamp'                = 'Clipchamp : montage vidéo simple de Microsoft.'
    'Microsoft.XboxGamingOverlay'        = 'Xbox Game Bar (Win+G) : captures, performances, widgets en jeu.'
    'Microsoft.XboxDevices'              = 'Accessoires Xbox : réglage et mise à jour des manettes Xbox.'
    'Microsoft.WindowsHDRCalibration'    = "Calibrage HDR de l'écran."
    'DolbyLaboratories.DolbyAccess'      = 'Dolby Access : son spatial Dolby Atmos pour casque.'
    'MicrosoftWindows.CrossDevice'       = 'Liaison entre Windows et le téléphone (expérience multi-appareils).'
}

# Éditeurs de jeux : un programme de ces éditeurs non reconnu ci-dessus est un jeu
$script:EditeursJeux = 'Electronic Arts|CAPCOM|Ubisoft|Rockstar Games|Bethesda|CD PROJEKT|GOG\.com|Bandai Namco|SEGA|Square Enix|Activision|Blizzard|2K|Paradox|Focus Entertainment|Warner Bros|Konami|Battlefield Studios|Riot Games|Valve'
# Dossiers typiques d'installation de jeux
$script:DossiersJeux = 'steamapps\\common|\\Epic Games\\|GOG Games|\\EA Games\\|Ubisoft Game Launcher\\games|\\XboxGames\\|Rockstar Games\\(?!Launcher)'

function Get-DescriptionLogiciel {
    <# Applique le dictionnaire : renvoie Categorie, Description, Protege, Avertissement.
       Les règles sont testées sur le nom affiché ET sur l'identifiant (paquet Store). #>
    param([string]$Nom, [string]$Editeur, [string]$Dossier, [string]$Identifiant = '', [switch]$EstJeu)
    $nomPaquet = ($Identifiant -split '_')[0]
    if (-not $EstJeu -and $nomPaquet -and $script:ApplisWindows.Contains($nomPaquet)) {
        $avertissement = if ($nomPaquet -eq 'Microsoft.XboxGamingOverlay') { 'Plus de captures de jeu ni de raccourci Win+G.' } else { 'Réinstallable gratuitement depuis le Microsoft Store.' }
        return [pscustomobject]@{ Categorie = 'Appli Windows'; Description = $script:ApplisWindows[$nomPaquet]; Protege = $false; Avertissement = $avertissement }
    }
    foreach ($regle in $script:ReglesLogiciels) {
        # Pour un jeu (Steam, Epic, Xbox), seules les règles « Système » s'appliquent (ex. Steamworks)
        if ($EstJeu -and $regle.C -ne 'Système') { continue }
        if ($Nom -match $regle.M -or ($nomPaquet -and $nomPaquet -match $regle.M)) {
            return [pscustomobject]@{ Categorie = $regle.C; Description = $regle.D; Protege = [bool]$regle.P; Avertissement = [string]$regle.A }
        }
    }
    if ($EstJeu -or $Dossier -match $script:DossiersJeux -or $Editeur -match $script:EditeursJeux) {
        return [pscustomobject]@{ Categorie = 'Jeu'; Description = 'Jeu vidéo.'; Protege = $false; Avertissement = "Les sauvegardes locales peuvent être supprimées (celles synchronisées dans le cloud sont conservées)." }
    }
    if ($Editeur -match 'Microsoft' -or $nomPaquet -match '^Microsoft(Windows|CorporationII)?\.') {
        return [pscustomobject]@{ Categorie = 'Système'; Description = 'Composant ou application Microsoft.'; Protege = $false; Avertissement = "Composant Microsoft : vérifie qu'il n'est pas utilisé par un autre logiciel." }
    }
    return [pscustomobject]@{ Categorie = 'Autre'; Description = "Pas de description connue : clique sur « En savoir plus »."; Protege = $false; Avertissement = '' }
}

function New-ElementLogiciel {
    <# Objet uniforme pour toutes les sources #>
    param([string]$Nom, [string]$Editeur = '', [string]$Version = '', [int64]$Octets = 0, [string]$Date = '',
        [string]$Source, [string]$Cle, [string]$Dossier = '', [switch]$EstJeu, [string]$Detail = '')
    $identifiant = if ($Source -in @('Store', 'Xbox')) { $Cle } else { '' }
    $info = Get-DescriptionLogiciel -Nom $Nom -Editeur $Editeur -Dossier $Dossier -Identifiant $identifiant -EstJeu:$EstJeu
    # Taille déclarée manifestement fausse pour un jeu (ex. 2 Mo) : on préfère ne rien afficher
    if ($info.Categorie -eq 'Jeu' -and $Octets -lt 50MB) { $Octets = 0 }
    if ($info.Categorie -eq 'Jeu') {
        $plateforme = @{ Steam = 'Steam'; Epic = 'Epic Games'; Xbox = 'Xbox / PC Game Pass' }[$Source]
        $info.Description = if ($plateforme) { "Jeu vidéo ($plateforme)." } else { 'Jeu vidéo.' }
        if ($Source -eq 'Steam') { $info.Description += ' « En savoir plus » affiche sa présentation officielle.' }
    }
    [pscustomobject]@{
        Nom = $Nom; Categorie = $info.Categorie; Description = $info.Description; Editeur = $Editeur; Version = $Version
        Octets = $Octets; Date = $Date; Source = $Source; Cle = $Cle; Dossier = $Dossier
        Protege = $info.Protege; Avertissement = $info.Avertissement; Detail = $Detail
    }
}

# ---------------------------------------------------------------------
#  Lecture des sources
# ---------------------------------------------------------------------
function Get-LogicielsRegistre {
    <# Programmes classiques déclarés dans « Programmes et fonctionnalités » #>
    $cles = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')
    $entrees = Get-ItemProperty -Path $cles -ErrorAction SilentlyContinue | Where-Object {
        $_.DisplayName -and $_.UninstallString -and $_.SystemComponent -ne 1 -and -not $_.ParentKeyName -and
        $_.ReleaseType -notmatch 'Update|Hotfix' -and $_.UninstallString -notmatch 'steam://'   # jeux Steam : lus via Steam
    }
    foreach ($e in $entrees) {
        $date = if ($e.InstallDate -match '^(\d{4})(\d{2})(\d{2})$') { "$($Matches[3])/$($Matches[2])/$($Matches[1])" } else { '' }
        $octets = if ($e.EstimatedSize -as [int64]) { [int64]$e.EstimatedSize * 1KB } else { 0 }
        New-ElementLogiciel -Nom $e.DisplayName -Editeur ([string]$e.Publisher) -Version ([string]$e.DisplayVersion) -Octets $octets `
            -Date $date -Source 'Registre' -Cle $e.PSPath -Dossier ([string]$e.InstallLocation)
    }
}

function Get-JeuxSteam {
    <# Jeux de toutes les bibliothèques Steam #>
    $racine = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $racine) { return }
    $racine = $racine -replace '/', '\'
    $bibliotheques = @($racine)
    $vdf = Join-Path $racine 'steamapps\libraryfolders.vdf'
    if (Test-Path -LiteralPath $vdf) {
        foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw -Encoding UTF8), '"path"\s+"([^"]+)"')) {
            $bibliotheques += ($m.Groups[1].Value -replace '\\\\', '\')
        }
    }
    foreach ($bibliotheque in ($bibliotheques | Select-Object -Unique)) {
        foreach ($manifeste in (Get-ChildItem -LiteralPath (Join-Path $bibliotheque 'steamapps') -Filter 'appmanifest_*.acf' -ErrorAction SilentlyContinue)) {
            $texte = Get-Content -LiteralPath $manifeste.FullName -Raw -Encoding UTF8
            $valeurs = @{}
            foreach ($m in [regex]::Matches($texte, '"(appid|name|installdir|SizeOnDisk|LastPlayed|LastUpdated)"\s+"([^"]*)"')) {
                if (-not $valeurs.ContainsKey($m.Groups[1].Value)) { $valeurs[$m.Groups[1].Value] = $m.Groups[2].Value }
            }
            if (-not $valeurs.appid) { continue }
            $dernierJeu = ''
            if ([int64]$valeurs.LastPlayed -gt 0) {
                $jouele = [DateTimeOffset]::FromUnixTimeSeconds([int64]$valeurs.LastPlayed).LocalDateTime
                $jours = [int]((Get-Date) - $jouele).TotalDays
                $dernierJeu = "Dernière partie : $($jouele.ToString('dd/MM/yyyy')) (il y a $jours jours)"
            }
            elseif ($valeurs.appid -ne '228980') { $dernierJeu = 'Jamais lancé' }
            New-ElementLogiciel -Nom $valeurs.name -Editeur 'Steam' -Octets ([int64]$valeurs.SizeOnDisk) -Source 'Steam' -Cle $valeurs.appid `
                -Dossier (Join-Path $bibliotheque "steamapps\common\$($valeurs.installdir)") -EstJeu -Detail $dernierJeu
        }
    }
}

# Fichiers d'Epic Games Launcher
$script:EpicManifestes = "$env:ProgramData\Epic\EpicGamesLauncher\Data\Manifests"

function Get-ManifestesEpic {
    <# Manifestes .item d'Epic (un par jeu, moteur ou module installé) #>
    foreach ($fichier in (Get-ChildItem -LiteralPath $script:EpicManifestes -Filter '*.item' -ErrorAction SilentlyContinue)) {
        try {
            $j = Get-Content -LiteralPath $fichier.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            if (-not $j.InstallLocation) { continue }
            # Chemin invalide (caractères interdits) : on ignore ce manifeste seul
            $dossierComplet = [IO.Path]::GetFullPath(([string]$j.InstallLocation).TrimEnd('\', '/'))
        }
        catch { continue }
        [pscustomobject]@{
            Fichier  = $fichier.FullName
            Nom      = $j.DisplayName
            AppName  = $j.AppName
            Dossier  = $dossierComplet
            Octets   = [int64]$j.InstallSize
            Version  = [string]$j.AppVersionString
            Masque   = (@($j.AppCategories) -contains 'hidden')
            Incomplet = [bool]$j.bIsIncompleteInstall
            EstJeu   = (@($j.AppCategories) -contains 'games')
        }
    }
}

function Get-JeuxEpic {
    <# Jeux et outils installés par Epic Games Launcher.
       Plusieurs éléments peuvent partager un dossier (moteur + modules Fab / Quixel,
       jeu + contenu additionnel) : le plus volumineux est le « propriétaire » du dossier. #>
    $manifestes = @(Get-ManifestesEpic)
    foreach ($m in ($manifestes | Where-Object { -not $_.Masque -and -not $_.Incomplet })) {
        $memeDossier = @($manifestes | Where-Object { $_.Dossier -eq $m.Dossier })
        $proprietaire = $memeDossier | Sort-Object Octets -Descending | Select-Object -First 1
        $element = New-ElementLogiciel -Nom $m.Nom -Editeur 'Epic Games' -Version $m.Version -Octets $m.Octets `
            -Source 'Epic' -Cle $m.AppName -Dossier $m.Dossier -EstJeu:$m.EstJeu
        if ($proprietaire.AppName -eq $m.AppName) {
            $modules = @($memeDossier | Where-Object { $_.AppName -ne $m.AppName -and -not $_.Masque } | ForEach-Object { $_.Nom })
            if ($modules.Count -gt 0) { $element.Detail = "Contient aussi : $($modules -join ', ') (supprimés avec lui)" }
            $element.Avertissement = (@($element.Avertissement, "Suppression définitive du dossier $($m.Dossier), sans passer par la corbeille. Epic Games Launcher doit être fermé.") | Where-Object { $_ }) -join ' '
        }
        else {
            $element.Detail = "Module installé dans le dossier de « $($proprietaire.Nom) »"
        }
        $element
    }
}

function Get-ApplisStore {
    <# Jeux Xbox / PC Game Pass et applis du Microsoft Store (celles visibles dans le menu Démarrer) #>
    $noms = @{}
    foreach ($app in (Get-StartApps -ErrorAction SilentlyContinue)) {
        $famille = ($app.AppID -split '!')[0]
        if ($famille -match '_' -and -not $noms.ContainsKey($famille)) { $noms[$famille] = $app.Name }
    }
    foreach ($p in (Get-AppxPackage -PackageTypeFilter Main -ErrorAction SilentlyContinue | Where-Object { -not $_.IsFramework -and -not $_.NonRemovable })) {
        # Jeu Xbox / PC Game Pass : le paquet contient MicrosoftGame.config
        $xbox = $p.InstallLocation -and (Test-Path -LiteralPath (Join-Path $p.InstallLocation 'MicrosoftGame.config') -ErrorAction SilentlyContinue)
        if ($xbox) {
            $nom = if ($noms.ContainsKey($p.PackageFamilyName)) { $noms[$p.PackageFamilyName] } else { $p.Name }
            New-ElementLogiciel -Nom $nom -Editeur ([string]$p.PublisherDisplayName) -Version ([string]$p.Version) -Source 'Xbox' `
                -Cle $p.PackageFullName -Dossier $p.InstallLocation -EstJeu
        }
        elseif ($p.SignatureKind -eq 'Store' -and $noms.ContainsKey($p.PackageFamilyName)) {
            New-ElementLogiciel -Nom $noms[$p.PackageFamilyName] -Editeur ([string]$p.PublisherDisplayName) -Version ([string]$p.Version) `
                -Source 'Store' -Cle $p.PackageFullName -Dossier $p.InstallLocation
        }
    }
}

function Get-LogicielsInstalles {
    <# Inventaire complet (toutes sources), sans doublons de nom #>
    $tous = New-Object System.Collections.ArrayList
    foreach ($source in @({ Get-JeuxSteam }, { Get-JeuxEpic }, { Get-ApplisStore }, { Get-LogicielsRegistre })) {
        try { foreach ($e in @(& $source)) { if ($e) { [void]$tous.Add($e) } } }
        catch { Write-Journal "Inventaire logiciels ($source) : $($_.Exception.Message)" 'ATTENTION' }
        Update-Interface
    }
    # Un même programme vu par deux sources : on masque l'entrée du REGISTRE
    # quand un lanceur (Steam/Epic/Xbox) l'a déjà listée. Deux installations
    # réelles du même jeu (Steam ET Epic) restent visibles toutes les deux,
    # sinon la seconde deviendrait impossible à désinstaller.
    $nomsLanceurs = @{}
    foreach ($e in $tous) { if ($e.Source -ne 'Registre') { $nomsLanceurs[$e.Nom.ToLowerInvariant()] = $true } }
    $vusRegistre = @{}
    return @($tous | Where-Object {
            if ($_.Source -ne 'Registre') { return $true }
            $cle = $_.Nom.ToLowerInvariant()
            if ($nomsLanceurs.ContainsKey($cle) -or $vusRegistre.ContainsKey($cle)) { return $false }
            $vusRegistre[$cle] = $true
            return $true
        })
}

# ---------------------------------------------------------------------
#  « En savoir plus » : description en ligne
# ---------------------------------------------------------------------
function Get-DescriptionEnLigne {
    <# Steam : description officielle de la boutique (en français).
       Autres : description du paquet winget.
       La partie winget passe par Invoke-ProgrammeTexte (et non par un runspace)
       car elle doit lire la sortie en UTF-8 sans console : Optimeo.exe n'en a pas. #>
    param([Parameter(Mandatory)]$Element)
    if ($Element.Source -eq 'Steam') {
        return Invoke-EnArrierePlan -DelaiSecondes 30 -Arguments @($Element.Cle) -Script {
            param($cle)
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $reponse = Invoke-RestMethod -Uri "https://store.steampowered.com/api/appdetails?appids=$cle&l=french&filters=basic" -TimeoutSec 15
            $donnees = $reponse.$cle.data
            if ($donnees.short_description) { return ([System.Net.WebUtility]::HtmlDecode(($donnees.short_description -replace '<[^>]+>', ''))) }
            return ''
        }
    }
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { return '' }

    # 1. Identifiant winget du programme installé (le nom seul est souvent ambigu)
    $nom = $Element.Nom
    $liste = @((Invoke-ProgrammeTexte -Programme 'winget' -Arguments "list --name `"$nom`" --accept-source-agreements --disable-interactivity" -DelaiSecondes 120).Lignes)
    $id = $null
    for ($i = 1; $i -lt $liste.Count -and -not $id; $i++) {
        if ($liste[$i] -notmatch '^-{10,}') { continue }
        $colonnes = @([regex]::Matches($liste[$i - 1], '\S+'))
        if ($colonnes.Count -lt 3) { continue }
        $debutId = $colonnes[1].Index      # 2e colonne = ID
        $finId = $colonnes[2].Index
        if ($i + 1 -lt $liste.Count -and $liste[$i + 1].Length -gt $finId) { $id = $liste[$i + 1].Substring($debutId, $finId - $debutId).Trim() }
    }
    if (-not $id -or $id -match '…' -or $id -match '^(ARP|MSIX)\\') { return '' }

    # 2. Description du paquet (champ « Description », en anglais le plus souvent)
    $lignes = @((Invoke-ProgrammeTexte -Programme 'winget' -Arguments "show --id `"$id`" --exact --accept-source-agreements --disable-interactivity" -DelaiSecondes 120).Lignes)
    $description = New-Object System.Collections.ArrayList
    $dedans = $false
    foreach ($ligne in $lignes) {
        if ($ligne -match '^Description\s*:\s*(.*)$') { $dedans = $true; if ($Matches[1]) { [void]$description.Add($Matches[1].Trim()) }; continue }
        if ($dedans) {
            if ($ligne -match '^\S') { break }     # champ suivant (non indenté)
            if ($ligne.Trim()) { [void]$description.Add($ligne.Trim()) }
        }
    }
    return ($description -join ' ')
}

# ---------------------------------------------------------------------
#  Désinstallation vérifiée
# ---------------------------------------------------------------------
function Wait-Condition {
    <# Attend qu'une condition soit vraie (interface réactive). Renvoie $true si atteinte. #>
    param([scriptblock]$Condition, [int]$DelaiMaxSecondes, [scriptblock]$Prolonger = { $false })
    $chrono = [Diagnostics.Stopwatch]::StartNew()
    while ($chrono.Elapsed.TotalSeconds -lt $DelaiMaxSecondes) {
        if (& $Condition) { return $true }
        Update-Interface
        Start-Sleep -Milliseconds 500
    }
    # Délai dépassé : on continue d'attendre tant qu'un désinstalleur tourne encore (max 15 min)
    while ((& $Prolonger) -and $chrono.Elapsed.TotalMinutes -lt 15) {
        if (& $Condition) { return $true }
        Update-Interface
        Start-Sleep -Milliseconds 500
    }
    return [bool](& $Condition)
}

function Test-DesinstalleurActif {
    <# Un programme de désinstallation classique est-il encore ouvert ? #>
    # _iu14D2N.tmp : copie temporaire créée par Inno Setup (le nom contient un point)
    return [bool](Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^(unins\d*|Au_|Un_A|_iu[\w\.]*|.*uninst.*|.*uninstall.*)$' })
}

function Split-LigneCommande {
    <# Sépare « "C:\chemin\prog.exe" /args » en programme + arguments #>
    param([string]$Commande)
    $Commande = $Commande.Trim()
    if ($Commande -match '^"([^"]+)"\s*(.*)$') { return @($Matches[1], $Matches[2]) }
    if ($Commande -match '^(.+?\.exe)\s*(.*)$') { return @($Matches[1], $Matches[2]) }
    return @($Commande, '')
}

function Uninstall-Element {
    <# Désinstalle un élément selon sa source puis VÉRIFIE qu'il a disparu.
       Renvoie un texte de résultat ; lève une erreur si non confirmé.
       Renvoie un texte commençant par « MANUEL: » si l'utilisateur doit finir. #>
    param([Parameter(Mandatory)]$Element)
    switch ($Element.Source) {
        'Steam' {
            $manifeste = Get-ChildItem -LiteralPath (Split-Path (Split-Path $Element.Dossier)) -Filter "appmanifest_$($Element.Cle).acf" -ErrorAction SilentlyContinue | Select-Object -First 1
            # Passe par explorer.exe : sinon Steam démarrerait en administrateur
            Start-Process 'explorer.exe' "steam://uninstall/$($Element.Cle)"
            Write-Journal "Désinstallation Steam demandée : $($Element.Nom)"
            if (-not $manifeste) { return "MANUEL: confirme la désinstallation dans Steam" }
            if (Wait-Condition -Condition { -not (Test-Path -LiteralPath $manifeste.FullName) } -DelaiMaxSecondes 180) { return 'Désinstallé par Steam (vérifié)' }
            throw "Pas de confirmation de Steam au bout de 3 minutes (désinstallation annulée ?)"
        }
        'Epic' {
            return "MANUEL: ouvre Epic Games Launcher, puis Bibliothèque. Choisis « Désinstaller » dans le menu de $($Element.Nom)."
        }
        { $_ -in @('Store', 'Xbox') } {
            Invoke-EnArrierePlan -Arguments @($Element.Cle) -Script { param($paquet) Remove-AppxPackage -Package $paquet -ErrorAction Stop } | Out-Null
            if (Get-AppxPackage | Where-Object { $_.PackageFullName -eq $Element.Cle }) { throw 'Le paquet est toujours installé' }
            return 'Désinstallé (vérifié)'
        }
        'Registre' {
            if ($Element.Cle -notmatch '^Microsoft\.PowerShell\.Core\\Registry::HKEY_LOCAL_MACHINE\\SOFTWARE\\(WOW6432Node\\)?Microsoft\\Windows\\CurrentVersion\\Uninstall\\[^\\]+$') {
                return "MANUEL: ouvre Paramètres Windows > Applications et désinstalle $($Element.Nom) depuis ta session."
            }
            $proprietes = Get-ItemProperty -Path $Element.Cle -ErrorAction Stop
            $commande = [string]$proprietes.UninstallString
            if ($commande -match 'msiexec' -and $commande -match '\{[0-9A-Fa-f\-]{36}\}') {
                # MSI : désinstallation sans question, avec barre de progression
                $code = Start-ProcessAvecInterface 'msiexec.exe' "/x $($Matches[0]) /passive /norestart" -DelaiSecondes 1800
                if ($code -notin @(0, 1605, 3010)) { throw "msiexec a échoué (code $code)" }
            }
            else {
                $silencieux = [string]$proprietes.QuietUninstallString
                $programme, $arguments = Split-LigneCommande $(if ($silencieux) { $silencieux } else { $commande })
                if (-not (Test-Path -LiteralPath $programme)) {
                    # Programme sans chemin complet (ex. rundll32.exe) : recherche dans le PATH
                    $trouve = Get-Command $programme -ErrorAction SilentlyContinue | Select-Object -First 1
                    if (-not $trouve) { throw "Désinstalleur introuvable : $programme" }
                    $programme = $trouve.Source
                }
                # Fenêtre visible : certains désinstalleurs posent une question
                Start-ProcessAvecInterface $programme $arguments -Style Normal -DelaiSecondes 1800 | Out-Null
            }
            Write-Journal "Désinstallation lancée : $($Element.Nom)"
            $cleRegistre = $Element.Cle
            if (Wait-Condition -Condition { -not (Test-Path -LiteralPath $cleRegistre) } -DelaiMaxSecondes 30 -Prolonger { Test-DesinstalleurActif }) {
                return 'Désinstallé (vérifié)'
            }
            throw "Toujours installé : désinstallation annulée ou refusée par le programme"
        }
        default { throw "Source inconnue : $($Element.Source)" }
    }
}
